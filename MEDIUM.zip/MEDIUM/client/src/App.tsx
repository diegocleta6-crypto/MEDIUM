import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "@/components/theme-provider";
import { PWAInstallPrompt } from "@/components/pwa-install-prompt";
import { useAuth } from "@/hooks/use-auth";
import NotFound from "@/pages/not-found";
import LandingPage from "@/pages/landing";
import HomePage from "@/pages/home";
import SearchPage from "@/pages/search";
import BusinessProfilePage from "@/pages/business-profile";
import ServiceRequestPage from "@/pages/service-request";
import RequestDetailPage from "@/pages/request-detail";
import MyRequestsPage from "@/pages/my-requests";
import RegisterBusinessPage from "@/pages/register-business";
import DashboardPage from "@/pages/dashboard";
import AdminPage from "@/pages/admin";
import ClientProfilePage from "@/pages/client-profile";
import ChatsPage from "@/pages/chats";
import PricingPage from "@/pages/pricing";

function AppRouter() {
  const { isAuthenticated, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="h-8 w-8 border-4 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <Switch>
      <Route path="/" component={isAuthenticated ? HomePage : LandingPage} />
      <Route path="/search" component={SearchPage} />
      <Route path="/business/:slug" component={BusinessProfilePage} />
      <Route path="/request/:businessId" component={ServiceRequestPage} />
      <Route path="/requests" component={MyRequestsPage} />
      <Route path="/requests/:id" component={RequestDetailPage} />
      <Route path="/register-business" component={RegisterBusinessPage} />
      <Route path="/dashboard" component={DashboardPage} />
      <Route path="/dashboard/:section" component={DashboardPage} />
      <Route path="/admin" component={AdminPage} />
      <Route path="/profile" component={ClientProfilePage} />
      <Route path="/chats" component={ChatsPage} />
      <Route path="/pricing" component={PricingPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider defaultTheme="light" storageKey="medium-ui-theme">
        <TooltipProvider>
          <Toaster />
          <AppRouter />
          <PWAInstallPrompt />
        </TooltipProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
