import { Link } from "wouter";
import { MapPin, Phone, BadgeCheck, MessageSquare, ArrowRight, Star, Crown } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { StarRating } from "@/components/star-rating";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import type { Business, Category } from "@shared/schema";

interface BusinessCardProps {
  business: Business & { category?: Category; plan?: string };
  distance?: number;
}

export function BusinessCard({ business, distance }: BusinessCardProps) {
  const initials = business.name
    .split(" ")
    .map((n) => n[0])
    .join("")
    .toUpperCase()
    .slice(0, 2);

  const rating = Number(business.rating) || 0;

  return (
    <Card className="hover-elevate overflow-visible group relative" data-testid={`card-business-${business.id}`}>
      <div className="absolute top-0 left-0 right-0 h-1 rounded-t-md bg-gradient-to-r from-primary/60 via-primary to-primary/60" />
      <CardContent className="p-5">
        <div className="flex gap-4">
          <Avatar className="h-14 w-14 rounded-md flex-shrink-0">
            <AvatarImage src={business.coverImage || ""} alt={business.name} className="object-cover" />
            <AvatarFallback className="rounded-md bg-primary/10 text-primary text-base font-semibold">
              {initials}
            </AvatarFallback>
          </Avatar>
          
          <div className="flex-1 min-w-0">
            <div className="flex items-start justify-between gap-2">
              <div className="min-w-0">
                <div className="flex items-center gap-1.5 flex-wrap">
                  <h3 className="font-semibold text-foreground truncate leading-tight">
                    {business.name}
                  </h3>
                  {business.isVerified && (
                    <BadgeCheck className="h-4 w-4 text-primary flex-shrink-0" />
                  )}
                  {business.plan === "premium" && (
                    <Badge className="bg-amber-500 hover:bg-amber-500 text-white text-[10px] px-1.5 py-0 h-4 no-default-hover-elevate" data-testid={`badge-premium-${business.id}`}>
                      <Crown className="h-2.5 w-2.5 mr-0.5" />
                      Premium
                    </Badge>
                  )}
                  {business.plan === "pro" && (
                    <Badge className="bg-blue-500 hover:bg-blue-500 text-white text-[10px] px-1.5 py-0 h-4 no-default-hover-elevate" data-testid={`badge-pro-${business.id}`}>
                      <Star className="h-2.5 w-2.5 mr-0.5" />
                      Pro
                    </Badge>
                  )}
                </div>
                {business.category?.name && (
                  <p className="text-xs text-muted-foreground mt-0.5 truncate">
                    {business.category.name}
                  </p>
                )}
              </div>
              {distance !== undefined && (
                <Badge variant="secondary" className="flex-shrink-0 text-xs">
                  {distance < 1 ? `${Math.round(distance * 1000)}m` : `${distance.toFixed(1)}km`}
                </Badge>
              )}
            </div>

            <div className="mt-2.5 flex items-center gap-2">
              <div className="flex items-center gap-1.5 bg-muted/50 dark:bg-muted/30 rounded-md px-2 py-1">
                <StarRating rating={rating} size="sm" showValue />
                <span className="text-xs text-muted-foreground">
                  ({business.reviewCount})
                </span>
              </div>
            </div>

            {business.address && (
              <div className="mt-2 flex items-center gap-1.5 text-xs text-muted-foreground">
                <MapPin className="h-3 w-3 flex-shrink-0" />
                <span className="truncate">{business.address}</span>
              </div>
            )}

            <div className="mt-3 flex items-center gap-2 flex-wrap">
              <Link href={`/business/${business.slug}`}>
                <Button size="sm" data-testid={`button-view-${business.id}`}>
                  Ver perfil
                  <ArrowRight className="h-3.5 w-3.5 ml-1" />
                </Button>
              </Link>
              <Link href={`/request/${business.id}`}>
                <Button size="sm" variant="outline" data-testid={`button-contact-${business.id}`}>
                  <MessageSquare className="h-3.5 w-3.5 mr-1" />
                  Solicitar
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
