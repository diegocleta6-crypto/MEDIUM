import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { 
  Wrench, 
  Zap, 
  Sparkles, 
  Paintbrush, 
  Car, 
  Home, 
  Scissors, 
  Truck,
  UtensilsCrossed,
  Camera,
  Briefcase,
  Heart,
  LucideIcon
} from "lucide-react";
import type { Category } from "@shared/schema";

const iconMap: Record<string, LucideIcon> = {
  wrench: Wrench,
  zap: Zap,
  sparkles: Sparkles,
  paintbrush: Paintbrush,
  car: Car,
  home: Home,
  scissors: Scissors,
  truck: Truck,
  utensils: UtensilsCrossed,
  camera: Camera,
  briefcase: Briefcase,
  heart: Heart,
};

interface CategoryCardProps {
  category: Category;
  count?: number;
}

export function CategoryCard({ category, count }: CategoryCardProps) {
  const Icon = iconMap[category.icon] || Briefcase;

  return (
    <Link href={`/search?category=${category.slug}`}>
      <Card 
        className="group hover-elevate active-elevate-2 cursor-pointer overflow-visible transition-transform hover:scale-[1.02]"
        data-testid={`card-category-${category.slug}`}
      >
        <CardContent className="p-4 flex flex-col items-center text-center">
          <div className="h-14 w-14 rounded-lg bg-primary/8 group-hover:bg-primary/15 transition-colors flex items-center justify-center mb-3">
            <Icon className="h-6 w-6 text-primary" />
          </div>
          <h3 className="text-sm font-semibold text-foreground">{category.name}</h3>
          {count !== undefined && (
            <p className="text-[11px] text-muted-foreground mt-1">
              {count} negocios
            </p>
          )}
        </CardContent>
      </Card>
    </Link>
  );
}
