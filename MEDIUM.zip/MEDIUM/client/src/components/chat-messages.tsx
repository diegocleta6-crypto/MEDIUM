import { useState, useRef, useEffect, useCallback } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Send, Loader2, ImagePlus, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Skeleton } from "@/components/ui/skeleton";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useAuth } from "@/hooks/use-auth";
import { useWebSocket } from "@/hooks/use-websocket";
import { cn } from "@/lib/utils";
import type { Message, User } from "@shared/schema";

interface ChatMessagesProps {
  serviceRequestId: string;
  otherPartyName: string;
  otherPartyImage?: string;
  isBlocked?: boolean;
  blockedMessage?: string;
}

interface MessageWithSender extends Omit<Message, 'images'> {
  sender?: User;
  images?: string[] | null;
}

export function ChatMessages({
  serviceRequestId,
  otherPartyName,
  otherPartyImage,
  isBlocked = false,
  blockedMessage = "El chat no esta disponible en este momento.",
}: ChatMessagesProps) {
  const { user } = useAuth();
  const { send, subscribe, isConnected } = useWebSocket();
  const [newMessage, setNewMessage] = useState("");
  const [selectedImages, setSelectedImages] = useState<string[]>([]);
  const [isOtherTyping, setIsOtherTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const typingTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  const { data: messages, isLoading } = useQuery<MessageWithSender[]>({
    queryKey: ["/api/messages", serviceRequestId],
    refetchInterval: isConnected ? false : 5000,
  });

  // Subscribe to WebSocket events for this chat
  useEffect(() => {
    const unsubMessage = subscribe("new_message", (data) => {
      if (data.requestId === serviceRequestId) {
        queryClient.invalidateQueries({ queryKey: ["/api/messages", serviceRequestId] });
      }
    });

    const unsubTyping = subscribe("typing", (data) => {
      if (data.requestId === serviceRequestId && data.userId !== user?.id) {
        setIsOtherTyping(true);
        if (typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current);
        typingTimeoutRef.current = setTimeout(() => setIsOtherTyping(false), 3000);
      }
    });

    const unsubStopTyping = subscribe("stop_typing", (data) => {
      if (data.requestId === serviceRequestId && data.userId !== user?.id) {
        setIsOtherTyping(false);
      }
    });

    return () => {
      unsubMessage();
      unsubTyping();
      unsubStopTyping();
      if (typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current);
    };
  }, [serviceRequestId, subscribe, user?.id]);

  // Send typing indicator
  const handleTyping = useCallback(() => {
    if (isConnected) {
      send({ type: "typing", requestId: serviceRequestId });
    }
  }, [isConnected, send, serviceRequestId]);

  const sendMessageMutation = useMutation({
    mutationFn: async ({ content, images }: { content: string; images?: string[] }) => {
      const res = await apiRequest("POST", "/api/messages", {
        serviceRequestId,
        content,
        images: images && images.length > 0 ? images : undefined,
      });
      return res.json();
    },
    onSuccess: () => {
      setNewMessage("");
      setSelectedImages([]);
      queryClient.invalidateQueries({ queryKey: ["/api/messages", serviceRequestId] });
    },
  });

  const handleImageSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    const newImages: string[] = [];
    for (let i = 0; i < Math.min(files.length, 3 - selectedImages.length); i++) {
      const file = files[i];
      if (!file.type.startsWith("image/") || file.size > 5 * 1024 * 1024) continue;
      
      const base64 = await new Promise<string>((resolve) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result as string);
        reader.readAsDataURL(file);
      });
      newImages.push(base64);
    }
    setSelectedImages([...selectedImages, ...newImages]);
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  const removeImage = (index: number) => {
    setSelectedImages(selectedImages.filter((_, i) => i !== index));
  };

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSend = () => {
    if (!newMessage.trim() && selectedImages.length === 0) return;
    sendMessageMutation.mutate({ content: newMessage.trim() || " ", images: selectedImages });
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
      .slice(0, 2);
  };

  if (isLoading) {
    return (
      <div className="space-y-4 p-4">
        {Array.from({ length: 3 }).map((_, i) => (
          <div key={i} className={cn("flex gap-2", i % 2 === 0 ? "" : "justify-end")}>
            <Skeleton className="h-8 w-8 rounded-full" />
            <Skeleton className="h-16 w-48 rounded-lg" />
          </div>
        ))}
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full">
      <div className="flex-1 overflow-y-auto p-4 space-y-4 min-h-0">
        {(!messages || messages.length === 0) && (
          <div className="text-center text-muted-foreground py-8">
            <p>No hay mensajes aún.</p>
            <p className="text-sm">Inicia la conversación enviando un mensaje.</p>
          </div>
        )}

        {messages?.map((message) => {
          const isOwnMessage = message.senderId === user?.id;

          return (
            <div
              key={message.id}
              className={cn("flex gap-2", isOwnMessage ? "justify-end" : "")}
            >
              {!isOwnMessage && (
                <Avatar className="h-8 w-8 flex-shrink-0">
                  <AvatarImage src={otherPartyImage} />
                  <AvatarFallback className="text-xs">
                    {getInitials(otherPartyName)}
                  </AvatarFallback>
                </Avatar>
              )}

              <div
                className={cn(
                  "max-w-[70%] rounded-lg px-3 py-2",
                  isOwnMessage
                    ? "bg-primary text-primary-foreground"
                    : "bg-muted"
                )}
              >
                <p className="text-sm whitespace-pre-wrap break-words">
                  {message.content}
                </p>
                {message.images && message.images.length > 0 && (
                  <div className="flex flex-wrap gap-1 mt-2">
                    {message.images
                      .filter((img) => typeof img === 'string' && img.startsWith('data:image/') && !img.includes('svg'))
                      .map((img, idx) => (
                        <img 
                          key={idx} 
                          src={img} 
                          alt="" 
                          className="max-w-32 max-h-32 rounded object-cover cursor-pointer hover:opacity-90"
                          onClick={() => {
                            const newWindow = window.open('', '_blank');
                            if (newWindow) {
                              newWindow.document.write(`<html><body style="margin:0;display:flex;justify-content:center;align-items:center;min-height:100vh;background:#000;"><img src="${img}" style="max-width:100%;max-height:100vh;object-fit:contain;"/></body></html>`);
                              newWindow.document.close();
                            }
                          }}
                        />
                      ))}
                  </div>
                )}
                <p
                  className={cn(
                    "text-xs mt-1",
                    isOwnMessage ? "text-primary-foreground/70" : "text-muted-foreground"
                  )}
                >
                  {new Date(message.createdAt!).toLocaleTimeString("es-MX", {
                    hour: "2-digit",
                    minute: "2-digit",
                  })}
                </p>
              </div>

              {isOwnMessage && (
                <Avatar className="h-8 w-8 flex-shrink-0">
                  <AvatarImage src={user?.profileImageUrl || ""} />
                  <AvatarFallback className="text-xs">
                    {user?.firstName?.[0] || "T"}
                  </AvatarFallback>
                </Avatar>
              )}
            </div>
          );
        })}

        {isOtherTyping && (
          <div className="flex items-center gap-2 text-muted-foreground text-sm">
            <Avatar className="h-6 w-6">
              <AvatarImage src={otherPartyImage} />
              <AvatarFallback className="text-xs">
                {otherPartyName[0]}
              </AvatarFallback>
            </Avatar>
            <span className="flex items-center gap-1">
              {otherPartyName} esta escribiendo
              <span className="inline-flex gap-0.5">
                <span className="h-1.5 w-1.5 bg-muted-foreground rounded-full animate-bounce" style={{ animationDelay: "0ms" }} />
                <span className="h-1.5 w-1.5 bg-muted-foreground rounded-full animate-bounce" style={{ animationDelay: "150ms" }} />
                <span className="h-1.5 w-1.5 bg-muted-foreground rounded-full animate-bounce" style={{ animationDelay: "300ms" }} />
              </span>
            </span>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      <div className="border-t p-4">
        {isBlocked ? (
          <Alert>
            <AlertDescription>{blockedMessage}</AlertDescription>
          </Alert>
        ) : (
          <>
            {selectedImages.length > 0 && (
              <div className="flex flex-wrap gap-2 mb-2">
                {selectedImages.map((img, idx) => (
                  <div key={idx} className="relative">
                    <img src={img} alt="" className="h-16 w-16 object-cover rounded" />
                    <Button 
                      size="icon" 
                      variant="destructive" 
                      className="absolute -top-1 -right-1 h-5 w-5"
                      onClick={() => removeImage(idx)}
                    >
                      <X className="h-3 w-3" />
                    </Button>
                  </div>
                ))}
              </div>
            )}
            <div className="flex gap-2">
              <input
                type="file"
                ref={fileInputRef}
                onChange={handleImageSelect}
                accept="image/*"
                multiple
                className="hidden"
              />
              <Button
                type="button"
                variant="outline"
                size="icon"
                onClick={() => fileInputRef.current?.click()}
                disabled={selectedImages.length >= 3 || sendMessageMutation.isPending}
                data-testid="button-attach-image"
              >
                <ImagePlus className="h-4 w-4" />
              </Button>
              <Textarea
                value={newMessage}
                onChange={(e) => {
                  setNewMessage(e.target.value);
                  handleTyping();
                }}
                onKeyDown={handleKeyDown}
                placeholder="Escribe un mensaje..."
                className="resize-none min-h-[44px] max-h-32"
                rows={1}
                disabled={sendMessageMutation.isPending}
                data-testid="textarea-message"
              />
              <Button
                onClick={handleSend}
                disabled={(!newMessage.trim() && selectedImages.length === 0) || sendMessageMutation.isPending}
                size="icon"
                data-testid="button-send-message"
              >
                {sendMessageMutation.isPending ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <Send className="h-4 w-4" />
                )}
              </Button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
