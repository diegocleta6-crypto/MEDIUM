import { useState, useEffect } from "react";
import { MapPin, Navigation, AlertCircle, Loader2, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";

interface GeolocationModalProps {
  open: boolean;
  onLocationObtained: (coords: { latitude: number; longitude: number }) => void;
}

export function GeolocationModal({ open, onLocationObtained }: GeolocationModalProps) {
  const [status, setStatus] = useState<"prompt" | "requesting" | "denied" | "manual">("prompt");
  const [manualAddress, setManualAddress] = useState({
    street: "",
    neighborhood: "",
    city: "",
  });
  const [isGeocoding, setIsGeocoding] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    const storedCoords = sessionStorage.getItem("user_coords");
    if (storedCoords) {
      try {
        const coords = JSON.parse(storedCoords);
        if (coords.latitude && coords.longitude) {
          onLocationObtained(coords);
        }
      } catch {
        // ignore
      }
    }
  }, [onLocationObtained]);

  const requestLocation = () => {
    if (!navigator.geolocation) {
      setStatus("manual");
      return;
    }

    setStatus("requesting");

    navigator.geolocation.getCurrentPosition(
      (position) => {
        const coords = {
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
        };
        sessionStorage.setItem("user_coords", JSON.stringify(coords));
        onLocationObtained(coords);
      },
      (error) => {
        console.error("Geolocation error:", error);
        if (error.code === error.PERMISSION_DENIED) {
          setStatus("denied");
        } else {
          setStatus("manual");
        }
      },
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 300000 }
    );
  };

  const geocodeAddress = async () => {
    const { street, neighborhood, city } = manualAddress;
    
    if (!street.trim() || !city.trim()) {
      toast({
        title: "Direccion incompleta",
        description: "Por favor ingresa al menos la calle y la ciudad.",
        variant: "destructive",
      });
      return;
    }

    setIsGeocoding(true);

    try {
      const fullAddress = `${street}, ${neighborhood}, ${city}, Mexico`;
      const response = await fetch(
        `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(fullAddress)}&limit=1`
      );
      const results = await response.json();

      if (results && results.length > 0) {
        const coords = {
          latitude: parseFloat(results[0].lat),
          longitude: parseFloat(results[0].lon),
        };
        sessionStorage.setItem("user_coords", JSON.stringify(coords));
        onLocationObtained(coords);
        toast({
          title: "Ubicacion encontrada",
          description: "Tu ubicacion ha sido configurada correctamente.",
        });
      } else {
        toast({
          title: "No encontramos la direccion",
          description: "Verifica que la direccion sea correcta e intenta de nuevo.",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error("Geocoding error:", error);
      toast({
        title: "Error de conexion",
        description: "No pudimos buscar la direccion. Intenta de nuevo.",
        variant: "destructive",
      });
    } finally {
      setIsGeocoding(false);
    }
  };

  return (
    <Dialog open={open}>
      <DialogContent className="sm:max-w-md" onPointerDownOutside={(e) => e.preventDefault()}>
        <DialogHeader>
          <div className="mx-auto h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center mb-2">
            <MapPin className="h-6 w-6 text-primary" />
          </div>
          <DialogTitle className="text-center">
            {status === "manual" || status === "denied" 
              ? "Ingresa tu ubicacion" 
              : "Activa tu ubicacion"}
          </DialogTitle>
          <DialogDescription className="text-center">
            {status === "manual" || status === "denied"
              ? "Escribe tu direccion para mostrarte negocios cercanos"
              : "MEDIUM necesita tu ubicacion para mostrarte los proveedores de servicios mas cercanos a ti."}
          </DialogDescription>
        </DialogHeader>

        {status === "prompt" && (
          <div className="space-y-4 pt-4">
            <Button 
              className="w-full" 
              onClick={requestLocation}
              data-testid="button-enable-gps"
            >
              <Navigation className="h-4 w-4 mr-2" />
              Activar GPS
            </Button>
            <Button 
              variant="outline" 
              className="w-full"
              onClick={() => setStatus("manual")}
              data-testid="button-manual-location"
            >
              Ingresar direccion manualmente
            </Button>
          </div>
        )}

        {status === "requesting" && (
          <div className="flex flex-col items-center gap-4 py-8">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
            <p className="text-sm text-muted-foreground text-center">
              Acepta el permiso de ubicacion en tu navegador...
            </p>
          </div>
        )}

        {status === "denied" && (
          <div className="space-y-4 pt-4">
            <div className="flex items-start gap-3 p-3 rounded-lg bg-destructive/10 text-sm">
              <AlertCircle className="h-5 w-5 text-destructive flex-shrink-0 mt-0.5" />
              <div>
                <p className="font-medium text-destructive">Permiso denegado</p>
                <p className="text-muted-foreground text-xs mt-1">
                  Sin ubicacion no podemos mostrarte negocios cercanos. Puedes ingresar tu direccion manualmente.
                </p>
              </div>
            </div>
            
            <div className="space-y-3">
              <div className="space-y-2">
                <Label htmlFor="street">Calle y numero</Label>
                <Input
                  id="street"
                  placeholder="Av. Insurgentes Sur 1234"
                  value={manualAddress.street}
                  onChange={(e) => setManualAddress({ ...manualAddress, street: e.target.value })}
                  data-testid="input-street"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="neighborhood">Colonia</Label>
                <Input
                  id="neighborhood"
                  placeholder="Del Valle"
                  value={manualAddress.neighborhood}
                  onChange={(e) => setManualAddress({ ...manualAddress, neighborhood: e.target.value })}
                  data-testid="input-neighborhood"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="city">Ciudad</Label>
                <Input
                  id="city"
                  placeholder="Ciudad de Mexico"
                  value={manualAddress.city}
                  onChange={(e) => setManualAddress({ ...manualAddress, city: e.target.value })}
                  data-testid="input-city"
                />
              </div>
            </div>

            <Button 
              className="w-full" 
              onClick={geocodeAddress}
              disabled={isGeocoding}
              data-testid="button-search-address"
            >
              {isGeocoding ? (
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              ) : (
                <Search className="h-4 w-4 mr-2" />
              )}
              Buscar direccion
            </Button>
          </div>
        )}

        {status === "manual" && (
          <div className="space-y-4 pt-2">
            <div className="space-y-3">
              <div className="space-y-2">
                <Label htmlFor="street">Calle y numero</Label>
                <Input
                  id="street"
                  placeholder="Av. Insurgentes Sur 1234"
                  value={manualAddress.street}
                  onChange={(e) => setManualAddress({ ...manualAddress, street: e.target.value })}
                  data-testid="input-street-manual"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="neighborhood">Colonia</Label>
                <Input
                  id="neighborhood"
                  placeholder="Del Valle"
                  value={manualAddress.neighborhood}
                  onChange={(e) => setManualAddress({ ...manualAddress, neighborhood: e.target.value })}
                  data-testid="input-neighborhood-manual"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="city">Ciudad</Label>
                <Input
                  id="city"
                  placeholder="Ciudad de Mexico"
                  value={manualAddress.city}
                  onChange={(e) => setManualAddress({ ...manualAddress, city: e.target.value })}
                  data-testid="input-city-manual"
                />
              </div>
            </div>

            <div className="flex gap-2">
              <Button 
                variant="outline"
                className="flex-1"
                onClick={() => setStatus("prompt")}
                data-testid="button-back-to-gps"
              >
                Usar GPS
              </Button>
              <Button 
                className="flex-1" 
                onClick={geocodeAddress}
                disabled={isGeocoding}
                data-testid="button-confirm-address"
              >
                {isGeocoding ? (
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                ) : (
                  <Search className="h-4 w-4 mr-2" />
                )}
                Confirmar
              </Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
