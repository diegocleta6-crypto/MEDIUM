import { useState, useEffect } from "react";
import { MapPin, X, Navigation, AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

interface GeolocationPromptProps {
  onLocationGranted: (coords: { latitude: number; longitude: number }) => void;
  onDismiss?: () => void;
}

export function GeolocationPrompt({ onLocationGranted, onDismiss }: GeolocationPromptProps) {
  const [status, setStatus] = useState<"prompt" | "requesting" | "denied" | "error">("prompt");
  const [dismissed, setDismissed] = useState(false);

  useEffect(() => {
    const stored = sessionStorage.getItem("geo_dismissed");
    if (stored) setDismissed(true);
    
    const storedCoords = sessionStorage.getItem("user_coords");
    if (storedCoords) {
      try {
        const coords = JSON.parse(storedCoords);
        onLocationGranted(coords);
        setDismissed(true);
      } catch {
        // ignore
      }
    }
  }, [onLocationGranted]);

  const requestLocation = () => {
    if (!navigator.geolocation) {
      setStatus("error");
      return;
    }

    setStatus("requesting");

    navigator.geolocation.getCurrentPosition(
      (position) => {
        const coords = {
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
        };
        sessionStorage.setItem("user_coords", JSON.stringify(coords));
        onLocationGranted(coords);
        setDismissed(true);
      },
      (error) => {
        console.error("Geolocation error:", error);
        if (error.code === error.PERMISSION_DENIED) {
          setStatus("denied");
        } else {
          setStatus("error");
        }
      },
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 300000 }
    );
  };

  const handleDismiss = () => {
    sessionStorage.setItem("geo_dismissed", "true");
    setDismissed(true);
    onDismiss?.();
  };

  if (dismissed) return null;

  return (
    <Card className="border-primary/20 bg-primary/5 overflow-visible">
      <CardContent className="p-4">
        <div className="flex items-start gap-3">
          <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
            {status === "denied" || status === "error" ? (
              <AlertCircle className="h-5 w-5 text-destructive" />
            ) : (
              <MapPin className="h-5 w-5 text-primary" />
            )}
          </div>

          <div className="flex-1 min-w-0">
            {status === "prompt" && (
              <>
                <h3 className="font-medium text-sm mb-1">
                  Encuentra negocios cercanos
                </h3>
                <p className="text-xs text-muted-foreground mb-3">
                  Permite el acceso a tu ubicación para mostrar los negocios más cercanos a ti.
                </p>
                <div className="flex items-center gap-2">
                  <Button size="sm" onClick={requestLocation} data-testid="button-allow-location">
                    <Navigation className="h-3 w-3 mr-1" />
                    Permitir ubicación
                  </Button>
                  <Button size="sm" variant="ghost" onClick={handleDismiss} data-testid="button-dismiss-location">
                    Ahora no
                  </Button>
                </div>
              </>
            )}

            {status === "requesting" && (
              <>
                <h3 className="font-medium text-sm mb-1">Obteniendo ubicación...</h3>
                <p className="text-xs text-muted-foreground">
                  Por favor acepta el permiso en tu navegador.
                </p>
              </>
            )}

            {status === "denied" && (
              <>
                <h3 className="font-medium text-sm mb-1 text-destructive">
                  Acceso denegado
                </h3>
                <p className="text-xs text-muted-foreground mb-2">
                  Sin tu ubicación no podemos mostrarte negocios cercanos. Puedes cambiar esto en la configuración de tu navegador.
                </p>
                <Button size="sm" variant="outline" onClick={handleDismiss}>
                  Entendido
                </Button>
              </>
            )}

            {status === "error" && (
              <>
                <h3 className="font-medium text-sm mb-1 text-destructive">
                  Error de ubicación
                </h3>
                <p className="text-xs text-muted-foreground mb-2">
                  No pudimos obtener tu ubicación. Verifica que tu dispositivo tenga GPS activado.
                </p>
                <div className="flex items-center gap-2">
                  <Button size="sm" variant="outline" onClick={requestLocation}>
                    Reintentar
                  </Button>
                  <Button size="sm" variant="ghost" onClick={handleDismiss}>
                    Cerrar
                  </Button>
                </div>
              </>
            )}
          </div>

          {(status === "prompt" || status === "requesting") && (
            <Button
              size="icon"
              variant="ghost"
              className="h-6 w-6 flex-shrink-0"
              onClick={handleDismiss}
              data-testid="button-close-prompt"
            >
              <X className="h-4 w-4" />
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
