import { Link, useLocation } from "wouter";
import { Menu, Search, User, LogOut, Building2, LayoutDashboard, Shield, MessageSquare, Heart, Home } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ThemeToggle } from "@/components/theme-toggle";
import { NotificationBell } from "@/components/notification-bell";
import { useAuth } from "@/hooks/use-auth";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Sheet,
  SheetContent,
  SheetTrigger,
} from "@/components/ui/sheet";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useState } from "react";

interface HeaderProps {
  userRole?: string;
}

export function Header({ userRole }: HeaderProps) {
  const { user, isAuthenticated, logout } = useAuth();
  const [, navigate] = useLocation();
  const [searchQuery, setSearchQuery] = useState("");
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/search?q=${encodeURIComponent(searchQuery.trim())}`);
    }
  };

  const initials = user?.firstName 
    ? `${user.firstName[0]}${user.lastName?.[0] || ""}`.toUpperCase()
    : "U";

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-14 items-center gap-3 px-4">
        <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
          <SheetTrigger asChild>
            <Button variant="ghost" size="icon" className="md:hidden" data-testid="button-mobile-menu">
              <Menu className="h-5 w-5" />
            </Button>
          </SheetTrigger>
          <SheetContent side="left" className="w-72 p-0">
            <div className="flex items-center gap-2 px-5 pt-6 pb-4 border-b">
              <div className="h-8 w-8 rounded-md bg-primary flex items-center justify-center">
                <span className="text-primary-foreground font-bold text-lg">M</span>
              </div>
              <span className="font-semibold text-lg tracking-tight gradient-text">
                MEDIUM
              </span>
            </div>
            <nav className="flex flex-col gap-1 px-3 py-3">
              <Link href="/" onClick={() => setMobileMenuOpen(false)}>
                <Button variant="ghost" className="w-full justify-start gap-3">
                  <Home className="h-4 w-4" />
                  Inicio
                </Button>
              </Link>
              <Link href="/search" onClick={() => setMobileMenuOpen(false)}>
                <Button variant="ghost" className="w-full justify-start gap-3">
                  <Search className="h-4 w-4" />
                  Buscar servicios
                </Button>
              </Link>
              {isAuthenticated && (
                <Link href="/chats" onClick={() => setMobileMenuOpen(false)}>
                  <Button variant="ghost" className="w-full justify-start gap-3" data-testid="nav-chats-mobile">
                    <MessageSquare className="h-4 w-4" />
                    Mis chats
                  </Button>
                </Link>
              )}

              {isAuthenticated && userRole === "client" && (
                <>
                  <div className="my-2 border-t" />
                  <p className="px-3 py-1 text-xs font-medium text-muted-foreground uppercase tracking-wider">
                    Mi cuenta
                  </p>
                  <Link href="/profile" onClick={() => setMobileMenuOpen(false)}>
                    <Button variant="ghost" className="w-full justify-start gap-3">
                      <User className="h-4 w-4" />
                      Mi perfil
                    </Button>
                  </Link>
                  <Link href="/profile?tab=favorites" onClick={() => setMobileMenuOpen(false)}>
                    <Button variant="ghost" className="w-full justify-start gap-3" data-testid="nav-favorites-mobile">
                      <Heart className="h-4 w-4" />
                      Mis favoritos
                    </Button>
                  </Link>
                  <Link href="/register-business" onClick={() => setMobileMenuOpen(false)}>
                    <Button variant="ghost" className="w-full justify-start gap-3" data-testid="nav-register-business-mobile">
                      <Building2 className="h-4 w-4" />
                      Promocionar mi servicio
                    </Button>
                  </Link>
                </>
              )}
              {isAuthenticated && userRole === "business" && (
                <>
                  <div className="my-2 border-t" />
                  <p className="px-3 py-1 text-xs font-medium text-muted-foreground uppercase tracking-wider">
                    Mi cuenta
                  </p>
                  <Link href="/dashboard/edit" onClick={() => setMobileMenuOpen(false)}>
                    <Button variant="ghost" className="w-full justify-start gap-3">
                      <User className="h-4 w-4" />
                      Mi perfil
                    </Button>
                  </Link>
                  <Link href="/dashboard" onClick={() => setMobileMenuOpen(false)}>
                    <Button variant="ghost" className="w-full justify-start gap-3">
                      <LayoutDashboard className="h-4 w-4" />
                      Mi negocio
                    </Button>
                  </Link>
                </>
              )}
              {isAuthenticated && userRole === "admin" && (
                <>
                  <div className="my-2 border-t" />
                  <Link href="/admin" onClick={() => setMobileMenuOpen(false)}>
                    <Button variant="ghost" className="w-full justify-start gap-3">
                      <Shield className="h-4 w-4" />
                      Administración
                    </Button>
                  </Link>
                </>
              )}
            </nav>
          </SheetContent>
        </Sheet>

        <Link href="/">
          <div className="flex items-center gap-2" data-testid="logo">
            <div className="h-8 w-8 rounded-md bg-primary flex items-center justify-center">
              <span className="text-primary-foreground font-bold text-lg">M</span>
            </div>
            <span className="font-semibold text-xl hidden sm:inline-block tracking-tight gradient-text">
              MEDIUM
            </span>
          </div>
        </Link>

        <form onSubmit={handleSearch} className="flex-1 max-w-sm hidden md:flex">
          <div className="relative w-full">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Buscar servicios..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 w-full bg-muted/50 border-transparent focus:border-primary/30 focus:bg-background transition-colors"
              data-testid="input-search"
            />
          </div>
        </form>

        <nav className="hidden md:flex items-center gap-1 ml-auto">
          <Link href="/search">
            <Button variant="ghost" size="sm" data-testid="nav-search">
              <Search className="h-4 w-4 mr-1.5" />
              Servicios
            </Button>
          </Link>
          {(!isAuthenticated || userRole === "client") && (
            <Link href="/register-business">
              <Button variant="ghost" size="sm" data-testid="nav-register-business">
                <Building2 className="h-4 w-4 mr-1.5" />
                Promocionar servicio
              </Button>
            </Link>
          )}
        </nav>

        <div className="flex items-center gap-1.5 md:ml-2 ml-auto">
          <ThemeToggle />
          
          {isAuthenticated && <NotificationBell />}

          {isAuthenticated ? (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="relative h-9 w-9 rounded-full" data-testid="button-user-menu">
                  <Avatar className="h-9 w-9">
                    <AvatarImage src={user?.profileImageUrl || ""} alt={user?.firstName || ""} />
                    <AvatarFallback className="bg-primary/10 text-primary">
                      {initials}
                    </AvatarFallback>
                  </Avatar>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <div className="flex items-center gap-3 p-3">
                  <Avatar className="h-9 w-9">
                    <AvatarImage src={user?.profileImageUrl || ""} />
                    <AvatarFallback className="bg-primary/10 text-primary text-sm">
                      {initials}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex flex-col min-w-0">
                    <span className="text-sm font-medium truncate">
                      {user?.firstName} {user?.lastName}
                    </span>
                    <span className="text-xs text-muted-foreground truncate">
                      {user?.email}
                    </span>
                  </div>
                </div>
                <DropdownMenuSeparator />
                <DropdownMenuItem asChild>
                  <Link href={userRole === "business" ? "/dashboard/edit" : "/profile"} className="cursor-pointer">
                    <User className="h-4 w-4 mr-2" />
                    Mi perfil
                  </Link>
                </DropdownMenuItem>
                {isAuthenticated && (
                  <DropdownMenuItem asChild>
                    <Link href="/chats" className="cursor-pointer">
                      <MessageSquare className="h-4 w-4 mr-2" />
                      Mis chats
                    </Link>
                  </DropdownMenuItem>
                )}
                {userRole === "business" && (
                  <DropdownMenuItem asChild>
                    <Link href="/dashboard" className="cursor-pointer">
                      <LayoutDashboard className="h-4 w-4 mr-2" />
                      Mi negocio
                    </Link>
                  </DropdownMenuItem>
                )}
                {userRole === "admin" && (
                  <DropdownMenuItem asChild>
                    <Link href="/admin" className="cursor-pointer">
                      <Shield className="h-4 w-4 mr-2" />
                      Administración
                    </Link>
                  </DropdownMenuItem>
                )}
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => logout()} className="cursor-pointer text-destructive">
                  <LogOut className="h-4 w-4 mr-2" />
                  Cerrar sesión
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          ) : (
            <a href="/api/login">
              <Button data-testid="button-login">
                Iniciar sesión
              </Button>
            </a>
          )}
        </div>
      </div>
    </header>
  );
}
