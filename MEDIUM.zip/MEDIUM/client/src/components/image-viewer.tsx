import { useState, useCallback, useEffect } from "react";
import { X, ZoomIn, ZoomOut, ChevronLeft, ChevronRight, RotateCcw } from "lucide-react";
import { Button } from "@/components/ui/button";

interface ImageViewerProps {
  images: string[];
  initialIndex: number;
  isOpen: boolean;
  onClose: () => void;
}

export function ImageViewer({ images, initialIndex, isOpen, onClose }: ImageViewerProps) {
  const [currentIndex, setCurrentIndex] = useState(initialIndex);
  const [scale, setScale] = useState(1);
  const [position, setPosition] = useState({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });

  useEffect(() => {
    setCurrentIndex(initialIndex);
    setScale(1);
    setPosition({ x: 0, y: 0 });
  }, [initialIndex, isOpen]);

  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "";
    }
    return () => {
      document.body.style.overflow = "";
    };
  }, [isOpen]);

  const handleKeyDown = useCallback((e: KeyboardEvent) => {
    if (!isOpen) return;
    
    switch (e.key) {
      case "Escape":
        onClose();
        break;
      case "ArrowLeft":
        if (images.length > 1) {
          setCurrentIndex((prev) => (prev - 1 + images.length) % images.length);
          setScale(1);
          setPosition({ x: 0, y: 0 });
        }
        break;
      case "ArrowRight":
        if (images.length > 1) {
          setCurrentIndex((prev) => (prev + 1) % images.length);
          setScale(1);
          setPosition({ x: 0, y: 0 });
        }
        break;
      case "+":
      case "=":
        setScale((prev) => Math.min(prev + 0.5, 5));
        break;
      case "-":
        setScale((prev) => Math.max(prev - 0.5, 0.5));
        break;
    }
  }, [isOpen, images.length, onClose]);

  useEffect(() => {
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [handleKeyDown]);

  const handleZoomIn = () => setScale((prev) => Math.min(prev + 0.5, 5));
  const handleZoomOut = () => setScale((prev) => Math.max(prev - 0.5, 0.5));
  const handleReset = () => {
    setScale(1);
    setPosition({ x: 0, y: 0 });
  };

  const handlePrev = () => {
    setCurrentIndex((prev) => (prev - 1 + images.length) % images.length);
    setScale(1);
    setPosition({ x: 0, y: 0 });
  };

  const handleNext = () => {
    setCurrentIndex((prev) => (prev + 1) % images.length);
    setScale(1);
    setPosition({ x: 0, y: 0 });
  };

  const handleMouseDown = (e: React.MouseEvent) => {
    if (scale > 1) {
      setIsDragging(true);
      setDragStart({ x: e.clientX - position.x, y: e.clientY - position.y });
    }
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (isDragging && scale > 1) {
      setPosition({
        x: e.clientX - dragStart.x,
        y: e.clientY - dragStart.y,
      });
    }
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  const handleWheel = (e: React.WheelEvent) => {
    e.preventDefault();
    const delta = e.deltaY > 0 ? -0.2 : 0.2;
    setScale((prev) => Math.max(0.5, Math.min(5, prev + delta)));
  };

  const handleBackdropClick = (e: React.MouseEvent) => {
    if (e.target === e.currentTarget) {
      onClose();
    }
  };

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 bg-black/90 flex items-center justify-center"
      onClick={handleBackdropClick}
      data-testid="image-viewer-backdrop"
    >
      <div className="absolute top-4 right-4 flex gap-2 z-10">
        <Button
          size="icon"
          variant="outline"
          onClick={handleZoomOut}
          className="bg-black/50 border-white/20 text-white hover:bg-black/70"
          data-testid="button-zoom-out"
        >
          <ZoomOut className="h-5 w-5" />
        </Button>
        <Button
          size="icon"
          variant="outline"
          onClick={handleZoomIn}
          className="bg-black/50 border-white/20 text-white hover:bg-black/70"
          data-testid="button-zoom-in"
        >
          <ZoomIn className="h-5 w-5" />
        </Button>
        <Button
          size="icon"
          variant="outline"
          onClick={handleReset}
          className="bg-black/50 border-white/20 text-white hover:bg-black/70"
          data-testid="button-zoom-reset"
        >
          <RotateCcw className="h-5 w-5" />
        </Button>
        <Button
          size="icon"
          variant="outline"
          onClick={onClose}
          className="bg-black/50 border-white/20 text-white hover:bg-black/70"
          data-testid="button-close-viewer"
        >
          <X className="h-5 w-5" />
        </Button>
      </div>

      {images.length > 1 && (
        <>
          <Button
            size="icon"
            variant="outline"
            onClick={handlePrev}
            className="absolute left-4 top-1/2 -translate-y-1/2 bg-black/50 border-white/20 text-white hover:bg-black/70 z-10"
            data-testid="button-prev-image"
          >
            <ChevronLeft className="h-6 w-6" />
          </Button>
          <Button
            size="icon"
            variant="outline"
            onClick={handleNext}
            className="absolute right-4 top-1/2 -translate-y-1/2 bg-black/50 border-white/20 text-white hover:bg-black/70 z-10"
            data-testid="button-next-image"
          >
            <ChevronRight className="h-6 w-6" />
          </Button>
        </>
      )}

      <div
        className="relative max-w-[90vw] max-h-[90vh] overflow-hidden cursor-grab active:cursor-grabbing"
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
        onWheel={handleWheel}
      >
        <img
          src={images[currentIndex]}
          alt={`Imagen ${currentIndex + 1} de ${images.length}`}
          className="max-w-[90vw] max-h-[90vh] object-contain select-none transition-transform duration-100"
          style={{
            transform: `scale(${scale}) translate(${position.x / scale}px, ${position.y / scale}px)`,
          }}
          draggable={false}
          data-testid="viewer-image"
        />
      </div>

      {images.length > 1 && (
        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2 z-10">
          {images.map((_, index) => (
            <button
              key={index}
              onClick={() => {
                setCurrentIndex(index);
                setScale(1);
                setPosition({ x: 0, y: 0 });
              }}
              className={`w-2 h-2 rounded-full transition-colors ${
                index === currentIndex ? "bg-white" : "bg-white/40"
              }`}
              data-testid={`indicator-${index}`}
            />
          ))}
        </div>
      )}

      <div className="absolute bottom-4 right-4 text-white/70 text-sm z-10">
        {currentIndex + 1} / {images.length} • Zoom: {Math.round(scale * 100)}%
      </div>
    </div>
  );
}
