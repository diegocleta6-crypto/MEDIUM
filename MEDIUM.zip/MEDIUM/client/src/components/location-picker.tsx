import { useEffect, useRef, useState, useCallback } from "react";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Navigation, Loader2, Search, MapPin, Move } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface LocationPickerProps {
  value?: { latitude: number; longitude: number; displayName?: string };
  onChange: (location: { latitude: number; longitude: number; displayName: string }) => void;
  className?: string;
}

const defaultCenter: [number, number] = [19.4326, -99.1332];
const defaultZoom = 13;

const markerIcon = L.divIcon({
  className: "location-marker",
  html: `<div style="background-color: #2a9d8f; width: 40px; height: 40px; border-radius: 50% 50% 50% 0; transform: rotate(-45deg); border: 3px solid white; box-shadow: 0 3px 6px rgba(0,0,0,0.4); display: flex; align-items: center; justify-content: center;"><svg style="transform: rotate(45deg); width: 20px; height: 20px; color: white;" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"/></svg></div>`,
  iconSize: [40, 40],
  iconAnchor: [20, 40],
});

const userIcon = L.divIcon({
  className: "user-location",
  html: `<div style="background-color: #3b82f6; width: 16px; height: 16px; border-radius: 50%; border: 3px solid white; box-shadow: 0 2px 4px rgba(0,0,0,0.3); animation: pulse 2s infinite;"></div>`,
  iconSize: [16, 16],
  iconAnchor: [8, 8],
});

export function LocationPicker({ value, onChange, className = "" }: LocationPickerProps) {
  const mapRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const markerRef = useRef<L.Marker | null>(null);
  const userMarkerRef = useRef<L.Marker | null>(null);
  const [isLocating, setIsLocating] = useState(false);
  const [isSearching, setIsSearching] = useState(false);
  const [searchAddress, setSearchAddress] = useState("");
  const [selectedAddress, setSelectedAddress] = useState(value?.displayName || "");
  const { toast } = useToast();

  const reverseGeocode = useCallback(async (lat: number, lng: number): Promise<string> => {
    try {
      const response = await fetch(
        `https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}&zoom=18&addressdetails=1`
      );
      const data = await response.json();
      if (data.display_name) {
        return data.display_name;
      }
    } catch (error) {
      console.error("Reverse geocoding error:", error);
    }
    return `${lat.toFixed(6)}, ${lng.toFixed(6)}`;
  }, []);

  const updateMarkerPosition = useCallback(async (lat: number, lng: number) => {
    if (markerRef.current && mapInstanceRef.current) {
      markerRef.current.setLatLng([lat, lng]);
    }
    const address = await reverseGeocode(lat, lng);
    setSelectedAddress(address);
    onChange({ latitude: lat, longitude: lng, displayName: address });
  }, [onChange, reverseGeocode]);

  useEffect(() => {
    if (!mapRef.current || mapInstanceRef.current) return;

    const initialCenter: [number, number] = value?.latitude && value?.longitude
      ? [value.latitude, value.longitude]
      : defaultCenter;

    const map = L.map(mapRef.current, {
      center: initialCenter,
      zoom: value?.latitude ? 16 : defaultZoom,
      zoomControl: false,
    });

    L.control.zoom({ position: "bottomright" }).addTo(map);

    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
      maxZoom: 19,
    }).addTo(map);

    const marker = L.marker(initialCenter, {
      icon: markerIcon,
      draggable: true,
    }).addTo(map);

    marker.on("dragend", async () => {
      const position = marker.getLatLng();
      await updateMarkerPosition(position.lat, position.lng);
    });

    map.on("click", async (e: L.LeafletMouseEvent) => {
      await updateMarkerPosition(e.latlng.lat, e.latlng.lng);
      map.panTo(e.latlng);
    });

    mapInstanceRef.current = map;
    markerRef.current = marker;

    if (value?.latitude && value?.longitude) {
      reverseGeocode(value.latitude, value.longitude).then(address => {
        setSelectedAddress(address);
      });
    }

    return () => {
      map.remove();
      mapInstanceRef.current = null;
      markerRef.current = null;
    };
  }, []);

  useEffect(() => {
    if (!mapInstanceRef.current || !markerRef.current) return;
    if (!value?.latitude || !value?.longitude) return;
    
    const currentPos = markerRef.current.getLatLng();
    if (Math.abs(currentPos.lat - value.latitude) > 0.0001 || 
        Math.abs(currentPos.lng - value.longitude) > 0.0001) {
      markerRef.current.setLatLng([value.latitude, value.longitude]);
      mapInstanceRef.current.setView([value.latitude, value.longitude], 16);
      if (value.displayName) {
        setSelectedAddress(value.displayName);
      }
    }
  }, [value?.latitude, value?.longitude, value?.displayName]);

  const handleLocateUser = useCallback(async () => {
    if (!navigator.geolocation) {
      toast({
        title: "GPS no disponible",
        description: "Tu navegador no soporta geolocalizacion.",
        variant: "destructive",
      });
      return;
    }

    setIsLocating(true);

    navigator.geolocation.getCurrentPosition(
      async (position) => {
        const { latitude, longitude } = position.coords;

        if (mapInstanceRef.current) {
          mapInstanceRef.current.setView([latitude, longitude], 17);
        }

        if (userMarkerRef.current) {
          userMarkerRef.current.setLatLng([latitude, longitude]);
        } else if (mapInstanceRef.current) {
          userMarkerRef.current = L.marker([latitude, longitude], { icon: userIcon })
            .addTo(mapInstanceRef.current)
            .bindPopup("Tu ubicacion actual");
        }

        await updateMarkerPosition(latitude, longitude);
        setIsLocating(false);

        toast({
          title: "Ubicacion encontrada",
          description: "Puedes ajustar el marcador si es necesario.",
        });
      },
      (error) => {
        console.error("Error getting location:", error);
        setIsLocating(false);
        toast({
          title: "No pudimos obtener tu ubicacion",
          description: "Verifica los permisos de ubicacion o busca la direccion manualmente.",
          variant: "destructive",
        });
      },
      { enableHighAccuracy: true, timeout: 15000, maximumAge: 0 }
    );
  }, [updateMarkerPosition, toast]);

  const handleSearchAddress = async () => {
    if (!searchAddress.trim()) {
      toast({
        title: "Direccion vacia",
        description: "Escribe una direccion para buscar.",
        variant: "destructive",
      });
      return;
    }

    setIsSearching(true);

    try {
      const query = `${searchAddress}, Mexico`;
      const response = await fetch(
        `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(query)}&limit=1`
      );
      const results = await response.json();

      if (results && results.length > 0) {
        const { lat, lon, display_name } = results[0];
        const latitude = parseFloat(lat);
        const longitude = parseFloat(lon);

        if (mapInstanceRef.current) {
          mapInstanceRef.current.setView([latitude, longitude], 17);
        }

        if (markerRef.current) {
          markerRef.current.setLatLng([latitude, longitude]);
        }

        setSelectedAddress(display_name);
        onChange({ latitude, longitude, displayName: display_name });

        toast({
          title: "Direccion encontrada",
          description: "Puedes ajustar el marcador arrastrándolo.",
        });
      } else {
        toast({
          title: "No encontramos la direccion",
          description: "Intenta con una direccion mas especifica o coloca el marcador manualmente.",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error("Search error:", error);
      toast({
        title: "Error de busqueda",
        description: "No pudimos buscar la direccion. Intenta de nuevo.",
        variant: "destructive",
      });
    } finally {
      setIsSearching(false);
    }
  };

  return (
    <div className={`space-y-3 ${className}`}>
      <div className="flex gap-2">
        <div className="flex-1 relative">
          <Input
            placeholder="Buscar direccion..."
            value={searchAddress}
            onChange={(e) => setSearchAddress(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter") {
                e.preventDefault();
                handleSearchAddress();
              }
            }}
            className="pr-10"
            data-testid="input-search-address"
          />
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        </div>
        <Button
          type="button"
          variant="outline"
          onClick={handleSearchAddress}
          disabled={isSearching}
          data-testid="button-search-location"
        >
          {isSearching ? <Loader2 className="h-4 w-4 animate-spin" /> : "Buscar"}
        </Button>
        <Button
          type="button"
          variant="default"
          onClick={handleLocateUser}
          disabled={isLocating}
          data-testid="button-gps-location"
        >
          {isLocating ? (
            <Loader2 className="h-4 w-4 animate-spin" />
          ) : (
            <Navigation className="h-4 w-4" />
          )}
        </Button>
      </div>

      <div className="relative rounded-lg overflow-hidden border">
        <div
          ref={mapRef}
          className="w-full h-64 md:h-80"
          data-testid="location-picker-map"
        />
        <div className="absolute bottom-3 left-3 right-14 z-[1000]">
          <div className="bg-background/95 backdrop-blur-sm rounded-md px-3 py-2 shadow-lg border text-xs">
            <div className="flex items-center gap-2 text-muted-foreground">
              <Move className="h-3 w-3 flex-shrink-0" />
              <span>Arrastra el marcador o haz clic en el mapa para ajustar</span>
            </div>
          </div>
        </div>
      </div>

      {selectedAddress && (
        <div className="flex items-start gap-2 p-3 bg-primary/5 rounded-lg border border-primary/20">
          <MapPin className="h-4 w-4 text-primary flex-shrink-0 mt-0.5" />
          <div className="flex-1 min-w-0">
            <Label className="text-xs text-muted-foreground">Ubicacion seleccionada</Label>
            <p className="text-sm font-medium truncate" data-testid="text-selected-address">
              {selectedAddress}
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
