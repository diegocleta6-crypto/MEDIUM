import { type ReactNode, useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { AlertTriangle } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

const REASON_OPTIONS = [
  "Contenido inapropiado",
  "Información falsa",
  "Spam",
  "Acoso",
  "Otro",
];

interface ReportDialogProps {
  type: "business" | "chat" | "message";
  targetId: string;
  trigger: ReactNode;
}

export function ReportDialog({ type, targetId, trigger }: ReportDialogProps) {
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [reason, setReason] = useState("");
  const [details, setDetails] = useState("");

  const reportMutation = useMutation({
    mutationFn: async (data: { type: string; reason: string; details: string; [key: string]: string }) => {
      const res = await apiRequest("POST", "/api/reports", data);
      return res.json();
    },
    onSuccess: () => {
      toast({ title: "Reporte enviado", description: "Gracias por tu reporte. Lo revisaremos pronto." });
      setOpen(false);
      setReason("");
      setDetails("");
    },
    onError: () => {
      toast({ title: "Error", description: "No se pudo enviar el reporte.", variant: "destructive" });
    },
  });

  const handleSubmit = () => {
    if (!reason) return;

    const payload: { type: string; reason: string; details: string; businessId?: string; serviceRequestId?: string; messageId?: string } = {
      type,
      reason,
      details,
    };

    if (type === "business") {
      payload.businessId = targetId;
    } else if (type === "chat") {
      payload.serviceRequestId = targetId;
    } else if (type === "message") {
      payload.messageId = targetId;
    }

    reportMutation.mutate(payload as any);
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {trigger}
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <AlertTriangle className="h-5 w-5" />
            Reportar contenido
          </DialogTitle>
          <DialogDescription>
            Cuéntanos por qué deseas reportar este contenido. Revisaremos tu reporte lo antes posible.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="report-reason">Razón del reporte</Label>
            <Select value={reason} onValueChange={setReason}>
              <SelectTrigger data-testid="select-report-reason">
                <SelectValue placeholder="Selecciona una razón" />
              </SelectTrigger>
              <SelectContent>
                {REASON_OPTIONS.map((option) => (
                  <SelectItem key={option} value={option} data-testid={`option-reason-${option}`}>
                    {option}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="report-details">Detalles adicionales</Label>
            <Textarea
              id="report-details"
              placeholder="Proporciona más detalles sobre tu reporte..."
              value={details}
              onChange={(e) => setDetails(e.target.value)}
              data-testid="input-report-details"
            />
          </div>
        </div>

        <DialogFooter>
          <Button
            variant="outline"
            onClick={() => setOpen(false)}
            data-testid="button-cancel-report"
          >
            Cancelar
          </Button>
          <Button
            onClick={handleSubmit}
            disabled={!reason || reportMutation.isPending}
            data-testid="button-submit-report"
          >
            Enviar reporte
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
