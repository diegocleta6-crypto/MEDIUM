import { useEffect, useRef, useCallback, useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { queryClient } from "@/lib/queryClient";

type MessageHandler = (data: any) => void;

interface WebSocketHook {
  isConnected: boolean;
  send: (data: any) => void;
  subscribe: (type: string, handler: MessageHandler) => () => void;
}

let globalSocket: WebSocket | null = null;
let globalHandlers = new Map<string, Set<MessageHandler>>();
let reconnectAttempts = 0;
const MAX_RECONNECT_ATTEMPTS = 5;
const RECONNECT_DELAY = 3000;

export function useWebSocket(): WebSocketHook {
  const { user } = useAuth();
  const [isConnected, setIsConnected] = useState(false);
  const handlersRef = useRef<Map<string, MessageHandler>>(new Map());

  const connect = useCallback(() => {
    if (!user?.id) return;
    if (globalSocket?.readyState === WebSocket.OPEN) return;

    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws?userId=${user.id}`;

    try {
      globalSocket = new WebSocket(wsUrl);

      globalSocket.onopen = () => {
        console.log("WebSocket connected");
        setIsConnected(true);
        reconnectAttempts = 0;
      };

      globalSocket.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          const handlers = globalHandlers.get(data.type);
          if (handlers) {
            handlers.forEach((handler) => handler(data));
          }

          if (data.type === "notification") {
            queryClient.invalidateQueries({ queryKey: ["/api/notifications"] });
          }
          if (data.type === "new_message") {
            queryClient.invalidateQueries({ queryKey: ["/api/messages", data.requestId] });
          }
          if (data.type === "new_request") {
            queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
            queryClient.invalidateQueries({ queryKey: ["/api/notifications"] });
          }
          if (data.type === "request_status") {
            queryClient.invalidateQueries({ queryKey: ["/api/requests/my"] });
            queryClient.invalidateQueries({ queryKey: ["/api/notifications"] });
          }
        } catch (error) {
          console.error("WebSocket message parse error:", error);
        }
      };

      globalSocket.onclose = () => {
        console.log("WebSocket disconnected");
        setIsConnected(false);
        globalSocket = null;

        if (reconnectAttempts < MAX_RECONNECT_ATTEMPTS) {
          reconnectAttempts++;
          setTimeout(connect, RECONNECT_DELAY * reconnectAttempts);
        }
      };

      globalSocket.onerror = (error) => {
        console.error("WebSocket error:", error);
      };
    } catch (error) {
      console.error("WebSocket connection error:", error);
    }
  }, [user?.id]);

  useEffect(() => {
    if (user?.id) {
      connect();
    }

    return () => {
      handlersRef.current.forEach((handler, type) => {
        const handlers = globalHandlers.get(type);
        if (handlers) {
          handlers.delete(handler);
        }
      });
    };
  }, [user?.id, connect]);

  const send = useCallback((data: any) => {
    if (globalSocket?.readyState === WebSocket.OPEN) {
      globalSocket.send(JSON.stringify(data));
    }
  }, []);

  const subscribe = useCallback((type: string, handler: MessageHandler) => {
    if (!globalHandlers.has(type)) {
      globalHandlers.set(type, new Set());
    }
    globalHandlers.get(type)!.add(handler);
    handlersRef.current.set(type, handler);

    return () => {
      const handlers = globalHandlers.get(type);
      if (handlers) {
        handlers.delete(handler);
      }
      handlersRef.current.delete(type);
    };
  }, []);

  return { isConnected, send, subscribe };
}
