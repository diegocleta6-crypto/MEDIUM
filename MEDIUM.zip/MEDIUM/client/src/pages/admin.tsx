import { useQuery, useMutation } from "@tanstack/react-query";
import { useState } from "react";
import { 
  Users, 
  Building2, 
  MessageSquare, 
  DollarSign,
  BadgeCheck,
  Clock,
  Shield,
  ChevronRight,
  Check,
  X,
  UserCog,
  Wallet,
  TrendingUp,
  Plus,
  Loader2,
  Flag,
  Star,
  Trash2,
  AlertTriangle,
} from "lucide-react";
import { Header } from "@/components/header";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { Business, Verification, User, WalletTransaction, Wallet as WalletType, Review } from "@shared/schema";

interface AdminUser extends User {
  role?: string;
  isBlocked?: boolean;
}

interface ReportedReview extends Review {
  business?: Business;
  client?: User;
}

interface TransactionWithDetails extends WalletTransaction {
  wallet?: WalletType;
  business?: Business;
}

interface AdminStats {
  totalUsers: number;
  totalBusinesses: number;
  totalRequests: number;
  totalRevenue: number;
  pendingVerifications: number;
}

interface VerificationWithBusiness extends Verification {
  business?: Business;
}

export default function AdminPage() {
  const { toast } = useToast();
  const [rechargeDialogOpen, setRechargeDialogOpen] = useState(false);
  const [selectedBusiness, setSelectedBusiness] = useState<Business | null>(null);
  const [rechargeAmount, setRechargeAmount] = useState("");

  const { data: stats, isLoading: statsLoading } = useQuery<AdminStats>({
    queryKey: ["/api/admin/stats"],
  });

  const { data: verifications, isLoading: verificationsLoading } = useQuery<VerificationWithBusiness[]>({
    queryKey: ["/api/admin/verifications"],
  });

  const { data: businesses, isLoading: businessesLoading } = useQuery<Business[]>({
    queryKey: ["/api/admin/businesses"],
  });

  const { data: users, isLoading: usersLoading } = useQuery<AdminUser[]>({
    queryKey: ["/api/admin/users"],
  });

  const { data: transactions, isLoading: transactionsLoading } = useQuery<TransactionWithDetails[]>({
    queryKey: ["/api/admin/transactions"],
  });

  const { data: reportedReviews, isLoading: reviewsLoading } = useQuery<ReportedReview[]>({
    queryKey: ["/api/admin/reviews/reported"],
  });

  const { data: suspiciousReviews, isLoading: suspiciousLoading } = useQuery<ReportedReview[]>({
    queryKey: ["/api/admin/reviews/suspicious"],
  });

  const { data: reports, isLoading: reportsLoading } = useQuery<any[]>({
    queryKey: ["/api/admin/reports"],
  });

  const verificationMutation = useMutation({
    mutationFn: async ({ id, status, note }: { id: string; status: string; note?: string }) => {
      const res = await apiRequest("PATCH", `/api/admin/verifications/${id}`, { status, reviewNote: note });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/verifications"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/stats"] });
      toast({
        title: "Verificación actualizada",
        description: "El estado de verificación ha sido actualizado.",
      });
    },
  });

  const toggleBusinessMutation = useMutation({
    mutationFn: async ({ id, isActive }: { id: string; isActive: boolean }) => {
      const res = await apiRequest("PATCH", `/api/admin/businesses/${id}`, { isActive });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/businesses"] });
      toast({
        title: "Negocio actualizado",
        description: "El estado del negocio ha sido actualizado.",
      });
    },
  });

  const rechargeMutation = useMutation({
    mutationFn: async ({ businessId, amount }: { businessId: string; amount: number }) => {
      const res = await apiRequest("POST", "/api/admin/wallet/recharge", {
        businessId,
        amount,
        description: `Recarga manual por admin - $${amount} MXN`,
      });
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/transactions"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/businesses"] });
      setRechargeDialogOpen(false);
      setSelectedBusiness(null);
      setRechargeAmount("");
      toast({
        title: "Recarga exitosa",
        description: data.newBalance != null 
          ? `Nuevo saldo: $${data.newBalance} MXN` 
          : "Recarga procesada correctamente",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "No se pudo procesar la recarga.",
        variant: "destructive",
      });
    },
  });

  const blockBusinessMutation = useMutation({
    mutationFn: async ({ id, isBlocked }: { id: string; isBlocked: boolean }) => {
      const endpoint = isBlocked 
        ? `/api/admin/businesses/${id}/block` 
        : `/api/admin/businesses/${id}/unblock`;
      const res = await apiRequest("POST", endpoint, {});
      return res.json();
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/businesses"] });
      toast({
        title: variables.isBlocked ? "Negocio bloqueado" : "Negocio desbloqueado",
        description: variables.isBlocked 
          ? "El negocio ya no aparecerá en búsquedas y no podrá recibir solicitudes."
          : "El negocio ha sido desbloqueado.",
      });
    },
  });

  const blockUserMutation = useMutation({
    mutationFn: async ({ userId, isBlocked }: { userId: string; isBlocked: boolean }) => {
      const endpoint = isBlocked 
        ? `/api/admin/users/${userId}/block` 
        : `/api/admin/users/${userId}/unblock`;
      const res = await apiRequest("POST", endpoint, {});
      return res.json();
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      toast({
        title: variables.isBlocked ? "Usuario bloqueado" : "Usuario desbloqueado",
        description: variables.isBlocked 
          ? "El usuario ya no podrá acceder a la plataforma."
          : "El usuario ha sido desbloqueado.",
      });
    },
  });

  const updateReportMutation = useMutation({
    mutationFn: async ({ id, status }: { id: string; status: string }) => {
      const res = await apiRequest("PATCH", `/api/admin/reports/${id}`, { status });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/reports"] });
      toast({ title: "Reporte actualizado" });
    },
  });

  const deleteReviewMutation = useMutation({
    mutationFn: async (reviewId: string) => {
      const res = await apiRequest("DELETE", `/api/admin/reviews/${reviewId}`, {});
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/reviews/reported"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/reviews/suspicious"] });
      toast({
        title: "Reseña eliminada",
        description: "La reseña ha sido eliminada.",
      });
    },
  });

  const handleRecharge = () => {
    const amount = parseFloat(rechargeAmount);
    if (!selectedBusiness || isNaN(amount) || amount <= 0) return;
    rechargeMutation.mutate({ businessId: selectedBusiness.id, amount });
  };

  const openRechargeDialog = (business: Business) => {
    setSelectedBusiness(business);
    setRechargeAmount("");
    setRechargeDialogOpen(true);
  };

  return (
    <div className="min-h-screen bg-background">
      <Header userRole="admin" />

      <main className="container px-4 py-6">
        <div className="flex items-center gap-3 mb-6">
          <div className="h-10 w-10 rounded-lg bg-gradient-to-br from-primary/20 to-primary/5 flex items-center justify-center">
            <Shield className="h-5 w-5 text-primary" />
          </div>
          <div>
            <h1 className="text-2xl font-bold tracking-tight">Panel de administración</h1>
            <p className="text-muted-foreground">Gestiona usuarios, negocios y verificaciones</p>
          </div>
        </div>

        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-5 mb-6">
          {statsLoading ? (
            Array.from({ length: 5 }).map((_, i) => (
              <Skeleton key={i} className="h-24 rounded-lg" />
            ))
          ) : (
            <>
              <Card className="overflow-visible">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between gap-3">
                    <div>
                      <p className="text-sm text-muted-foreground">Usuarios</p>
                      <p className="text-2xl font-bold">{stats?.totalUsers || 0}</p>
                    </div>
                    <div className="h-10 w-10 rounded-lg bg-blue-500/10 dark:bg-blue-400/10 flex items-center justify-center">
                      <Users className="h-5 w-5 text-blue-600 dark:text-blue-400" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="overflow-visible">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between gap-3">
                    <div>
                      <p className="text-sm text-muted-foreground">Negocios</p>
                      <p className="text-2xl font-bold">{stats?.totalBusinesses || 0}</p>
                    </div>
                    <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
                      <Building2 className="h-5 w-5 text-primary" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="overflow-visible">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between gap-3">
                    <div>
                      <p className="text-sm text-muted-foreground">Solicitudes</p>
                      <p className="text-2xl font-bold">{stats?.totalRequests || 0}</p>
                    </div>
                    <div className="h-10 w-10 rounded-lg bg-indigo-500/10 dark:bg-indigo-400/10 flex items-center justify-center">
                      <MessageSquare className="h-5 w-5 text-indigo-600 dark:text-indigo-400" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="overflow-visible">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between gap-3">
                    <div>
                      <p className="text-sm text-muted-foreground">Ingresos</p>
                      <p className="text-2xl font-bold">${stats?.totalRevenue?.toFixed(2) || "0.00"}</p>
                    </div>
                    <div className="h-10 w-10 rounded-lg bg-green-500/10 dark:bg-green-400/10 flex items-center justify-center">
                      <DollarSign className="h-5 w-5 text-green-600 dark:text-green-400" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="overflow-visible">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between gap-3">
                    <div>
                      <p className="text-sm text-muted-foreground">Verificaciones</p>
                      <p className="text-2xl font-bold">{stats?.pendingVerifications || 0}</p>
                    </div>
                    <div className="h-10 w-10 rounded-lg bg-amber-500/10 dark:bg-amber-400/10 flex items-center justify-center">
                      <BadgeCheck className="h-5 w-5 text-amber-600 dark:text-amber-400" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </>
          )}
        </div>

        <Tabs defaultValue="verifications" className="space-y-4">
          <TabsList>
            <TabsTrigger value="verifications" data-testid="tab-verifications">
              Verificaciones
              {stats?.pendingVerifications ? (
                <Badge variant="destructive" className="ml-2 h-5 w-5 p-0 justify-center">
                  {stats.pendingVerifications}
                </Badge>
              ) : null}
            </TabsTrigger>
            <TabsTrigger value="businesses" data-testid="tab-businesses">
              Negocios
            </TabsTrigger>
            <TabsTrigger value="users" data-testid="tab-users">
              Usuarios
            </TabsTrigger>
            <TabsTrigger value="transactions" data-testid="tab-transactions">
              Movimientos
            </TabsTrigger>
            <TabsTrigger value="reviews" data-testid="tab-reviews">
              Reseñas
              {reportedReviews && reportedReviews.length > 0 && (
                <Badge variant="destructive" className="ml-2 h-5 w-5 p-0 justify-center">
                  {reportedReviews.length}
                </Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="reports" data-testid="tab-reports">
              Reportes
              {reports && reports.filter((r: any) => r.status === "pending").length > 0 && (
                <Badge variant="destructive" className="ml-2 h-5 w-5 p-0 justify-center">
                  {reports.filter((r: any) => r.status === "pending").length}
                </Badge>
              )}
            </TabsTrigger>
          </TabsList>

          <TabsContent value="verifications">
            <Card className="overflow-visible">
              <CardHeader className="pb-4">
                <CardTitle className="text-lg">Verificaciones pendientes</CardTitle>
                <CardDescription>
                  Revisa los documentos enviados por los negocios
                </CardDescription>
              </CardHeader>
              <CardContent>
                {verificationsLoading ? (
                  <div className="space-y-2">
                    {Array.from({ length: 3 }).map((_, i) => (
                      <Skeleton key={i} className="h-16 rounded-lg" />
                    ))}
                  </div>
                ) : verifications && verifications.filter(v => v.status === "pending").length > 0 ? (
                  <div className="space-y-3">
                    {verifications.filter(v => v.status === "pending").map((verification) => (
                      <div key={verification.id} className="flex items-center justify-between gap-3 p-4 border rounded-lg">
                        <div className="flex items-center gap-3">
                          <div className="h-10 w-10 rounded-md bg-primary/10 flex items-center justify-center">
                            <Building2 className="h-5 w-5 text-primary" />
                          </div>
                          <div>
                            <p className="font-medium">{verification.business?.name}</p>
                            <p className="text-sm text-muted-foreground">
                              {verification.documentType === "ine" ? "INE" : "Comprobante de domicilio"}
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <a
                            href={verification.documentUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                          >
                            <Button variant="outline" size="sm">
                              Ver documento
                            </Button>
                          </a>
                          <Button
                            size="sm"
                            onClick={() => verificationMutation.mutate({
                              id: verification.id,
                              status: "approved",
                            })}
                            disabled={verificationMutation.isPending}
                            data-testid={`button-approve-${verification.id}`}
                          >
                            <Check className="h-4 w-4" />
                          </Button>
                          <Button
                            size="sm"
                            variant="destructive"
                            onClick={() => verificationMutation.mutate({
                              id: verification.id,
                              status: "rejected",
                              note: "Documento no válido",
                            })}
                            disabled={verificationMutation.isPending}
                            data-testid={`button-reject-${verification.id}`}
                          >
                            <X className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="py-12 text-center text-muted-foreground">
                    <BadgeCheck className="h-12 w-12 mx-auto mb-3 opacity-40" />
                    <p className="text-sm">No hay verificaciones pendientes</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="businesses">
            <Card className="overflow-visible">
              <CardHeader className="pb-4">
                <CardTitle className="text-lg">Negocios registrados</CardTitle>
                <CardDescription>
                  Gestiona los negocios de la plataforma
                </CardDescription>
              </CardHeader>
              <CardContent>
                {businessesLoading ? (
                  <Skeleton className="h-64 rounded-lg" />
                ) : businesses && businesses.length > 0 ? (
                  <Table className="text-sm">
                    <TableHeader>
                      <TableRow className="border-b-muted">
                        <TableHead className="text-xs font-semibold uppercase text-muted-foreground">Negocio</TableHead>
                        <TableHead className="text-xs font-semibold uppercase text-muted-foreground">Estado</TableHead>
                        <TableHead className="text-xs font-semibold uppercase text-muted-foreground">Verificado</TableHead>
                        <TableHead className="text-xs font-semibold uppercase text-muted-foreground">Bloqueado</TableHead>
                        <TableHead className="text-xs font-semibold uppercase text-muted-foreground text-right">Acciones</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {businesses.map((business) => (
                        <TableRow key={business.id}>
                          <TableCell>
                            <div className="flex items-center gap-3">
                              <Avatar className="h-8 w-8 rounded-md">
                                <AvatarImage src={business.coverImage || ""} />
                                <AvatarFallback className="rounded-md bg-primary/10 text-primary text-sm">
                                  {business.name.slice(0, 2).toUpperCase()}
                                </AvatarFallback>
                              </Avatar>
                              <div>
                                <p className="font-medium">{business.name}</p>
                                <p className="text-xs text-muted-foreground">{business.address}</p>
                              </div>
                            </div>
                          </TableCell>
                          <TableCell>
                            <Badge variant={business.isActive ? "default" : "secondary"}>
                              {business.isActive ? "Activo" : "Inactivo"}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            {business.isVerified ? (
                              <BadgeCheck className="h-5 w-5 text-primary" />
                            ) : (
                              <Clock className="h-5 w-5 text-muted-foreground" />
                            )}
                          </TableCell>
                          <TableCell>
                            {business.isBlocked ? (
                              <Badge variant="destructive">Bloqueado</Badge>
                            ) : (
                              <Badge variant="outline">Normal</Badge>
                            )}
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="flex items-center justify-end gap-2">
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => openRechargeDialog(business)}
                                data-testid={`button-recharge-${business.id}`}
                              >
                                <Plus className="h-3 w-3 mr-1" />
                                Recargar
                              </Button>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => toggleBusinessMutation.mutate({
                                  id: business.id,
                                  isActive: !business.isActive,
                                })}
                                data-testid={`button-toggle-${business.id}`}
                              >
                                {business.isActive ? "Desactivar" : "Activar"}
                              </Button>
                              <Button
                                variant={business.isBlocked ? "outline" : "destructive"}
                                size="sm"
                                onClick={() => blockBusinessMutation.mutate({
                                  id: business.id,
                                  isBlocked: !business.isBlocked,
                                })}
                                data-testid={`button-block-business-${business.id}`}
                              >
                                {business.isBlocked ? "Desbloquear" : "Bloquear"}
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                ) : (
                  <div className="py-12 text-center text-muted-foreground">
                    <Building2 className="h-12 w-12 mx-auto mb-3 opacity-40" />
                    <p className="text-sm">No hay negocios registrados</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="users">
            <Card className="overflow-visible">
              <CardHeader className="pb-4">
                <CardTitle className="text-lg">Usuarios registrados</CardTitle>
                <CardDescription>
                  Lista de todos los usuarios de la plataforma
                </CardDescription>
              </CardHeader>
              <CardContent>
                {usersLoading ? (
                  <Skeleton className="h-64 rounded-lg" />
                ) : users && users.length > 0 ? (
                  <Table className="text-sm">
                    <TableHeader>
                      <TableRow className="border-b-muted">
                        <TableHead className="text-xs font-semibold uppercase text-muted-foreground">Usuario</TableHead>
                        <TableHead className="text-xs font-semibold uppercase text-muted-foreground">Email</TableHead>
                        <TableHead className="text-xs font-semibold uppercase text-muted-foreground">Rol</TableHead>
                        <TableHead className="text-xs font-semibold uppercase text-muted-foreground">Estado</TableHead>
                        <TableHead className="text-xs font-semibold uppercase text-muted-foreground">Registro</TableHead>
                        <TableHead className="text-xs font-semibold uppercase text-muted-foreground text-right">Acciones</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {users.map((user) => (
                        <TableRow key={user.id}>
                          <TableCell>
                            <div className="flex items-center gap-3">
                              <Avatar className="h-8 w-8">
                                <AvatarImage src={user.profileImageUrl || ""} />
                                <AvatarFallback className="bg-primary/10 text-primary text-sm">
                                  {user.firstName?.[0] || "U"}
                                </AvatarFallback>
                              </Avatar>
                              <span className="font-medium">
                                {user.firstName} {user.lastName}
                              </span>
                            </div>
                          </TableCell>
                          <TableCell className="text-muted-foreground">
                            {user.email}
                          </TableCell>
                          <TableCell>
                            <Badge variant="outline">
                              {user.role === "admin" ? "Admin" : user.role === "business" ? "Negocio" : "Cliente"}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            {user.isBlocked ? (
                              <Badge variant="destructive">Bloqueado</Badge>
                            ) : (
                              <Badge variant="outline">Activo</Badge>
                            )}
                          </TableCell>
                          <TableCell className="text-muted-foreground">
                            {user.createdAt ? new Date(user.createdAt).toLocaleDateString("es-MX") : "-"}
                          </TableCell>
                          <TableCell className="text-right">
                            {user.role !== "admin" && (
                              <Button
                                variant={user.isBlocked ? "outline" : "destructive"}
                                size="sm"
                                onClick={() => blockUserMutation.mutate({
                                  userId: user.id,
                                  isBlocked: !user.isBlocked,
                                })}
                                data-testid={`button-block-user-${user.id}`}
                              >
                                {user.isBlocked ? "Desbloquear" : "Bloquear"}
                              </Button>
                            )}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                ) : (
                  <div className="py-12 text-center text-muted-foreground">
                    <Users className="h-12 w-12 mx-auto mb-3 opacity-40" />
                    <p className="text-sm">No hay usuarios registrados</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="transactions">
            <Card className="overflow-visible">
              <CardHeader className="pb-4">
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Wallet className="h-5 w-5" />
                  Historial de movimientos
                </CardTitle>
                <CardDescription>
                  Últimos 100 movimientos de saldo en la plataforma
                </CardDescription>
              </CardHeader>
              <CardContent>
                {transactionsLoading ? (
                  <div className="space-y-3">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <Skeleton key={i} className="h-12 rounded" />
                    ))}
                  </div>
                ) : transactions && transactions.length > 0 ? (
                  <Table className="text-sm">
                    <TableHeader>
                      <TableRow className="border-b-muted">
                        <TableHead className="text-xs font-semibold uppercase text-muted-foreground">Fecha</TableHead>
                        <TableHead className="text-xs font-semibold uppercase text-muted-foreground">Negocio</TableHead>
                        <TableHead className="text-xs font-semibold uppercase text-muted-foreground">Tipo</TableHead>
                        <TableHead className="text-xs font-semibold uppercase text-muted-foreground">Descripción</TableHead>
                        <TableHead className="text-xs font-semibold uppercase text-muted-foreground text-right">Monto</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {transactions.map((tx) => (
                        <TableRow key={tx.id}>
                          <TableCell className="text-muted-foreground">
                            {tx.createdAt ? new Date(tx.createdAt).toLocaleString("es-MX", { 
                              dateStyle: "short", 
                              timeStyle: "short" 
                            }) : "-"}
                          </TableCell>
                          <TableCell className="font-medium">
                            {tx.business?.name || "N/A"}
                          </TableCell>
                          <TableCell>
                            <Badge variant={tx.type === "credit" ? "default" : tx.type === "debit" ? "secondary" : "outline"}>
                              {tx.type === "credit" ? "Recarga" : tx.type === "debit" ? "Lead" : "Reembolso"}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-muted-foreground max-w-[200px] truncate">
                            {tx.description}
                          </TableCell>
                          <TableCell className={`text-right font-medium ${tx.type === "credit" ? "text-green-600" : "text-red-600"}`}>
                            {tx.type === "credit" ? "+" : "-"}${Number(tx.amount).toFixed(2)}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                ) : (
                  <div className="py-12 text-center text-muted-foreground">
                    <Wallet className="h-12 w-12 mx-auto mb-3 opacity-40" />
                    <p className="text-sm">No hay movimientos registrados</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="reviews">
            <Card className="overflow-visible">
              <CardHeader className="pb-4">
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Flag className="h-5 w-5" />
                  Reseñas reportadas
                </CardTitle>
                <CardDescription>
                  Revisa las reseñas que han sido reportadas
                </CardDescription>
              </CardHeader>
              <CardContent>
                {reviewsLoading ? (
                  <div className="space-y-3">
                    {Array.from({ length: 3 }).map((_, i) => (
                      <Skeleton key={i} className="h-16 rounded" />
                    ))}
                  </div>
                ) : reportedReviews && reportedReviews.length > 0 ? (
                  <Table className="text-sm">
                    <TableHeader>
                      <TableRow className="border-b-muted">
                        <TableHead className="text-xs font-semibold uppercase text-muted-foreground">Negocio</TableHead>
                        <TableHead className="text-xs font-semibold uppercase text-muted-foreground">Cliente</TableHead>
                        <TableHead className="text-xs font-semibold uppercase text-muted-foreground">Calificación</TableHead>
                        <TableHead className="text-xs font-semibold uppercase text-muted-foreground">Comentario</TableHead>
                        <TableHead className="text-xs font-semibold uppercase text-muted-foreground">Motivo del reporte</TableHead>
                        <TableHead className="text-xs font-semibold uppercase text-muted-foreground text-right">Acciones</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {reportedReviews.map((review) => (
                        <TableRow key={review.id} data-testid={`row-review-${review.id}`}>
                          <TableCell className="font-medium" data-testid={`text-business-name-${review.id}`}>
                            {review.business?.name || "N/A"}
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <Avatar className="h-6 w-6">
                                <AvatarImage src={review.client?.profileImageUrl || ""} />
                                <AvatarFallback className="text-xs">
                                  {review.client?.firstName?.[0] || "U"}
                                </AvatarFallback>
                              </Avatar>
                              <span className="text-sm" data-testid={`text-client-name-${review.id}`}>
                                {review.client?.firstName} {review.client?.lastName}
                              </span>
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-1" data-testid={`text-rating-${review.id}`}>
                              <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                              <span className="font-medium">{review.rating}</span>
                            </div>
                          </TableCell>
                          <TableCell className="max-w-[200px] truncate text-muted-foreground" data-testid={`text-comment-${review.id}`}>
                            {review.comment || "-"}
                          </TableCell>
                          <TableCell className="max-w-[150px] truncate text-muted-foreground" data-testid={`text-report-reason-${review.id}`}>
                            {review.reportReason || "-"}
                          </TableCell>
                          <TableCell className="text-right">
                            <Button
                              variant="destructive"
                              size="sm"
                              onClick={() => deleteReviewMutation.mutate(review.id)}
                              disabled={deleteReviewMutation.isPending}
                              data-testid={`button-delete-review-${review.id}`}
                            >
                              <Trash2 className="h-4 w-4 mr-1" />
                              Eliminar
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                ) : (
                  <div className="py-12 text-center text-muted-foreground" data-testid="status-no-reviews">
                    <Flag className="h-12 w-12 mx-auto mb-3 opacity-40" />
                    <p className="text-sm" data-testid="text-no-reviews-message">No hay reseñas reportadas</p>
                  </div>
                )}
              </CardContent>
            </Card>

            <Card className="mt-6 overflow-visible">
              <CardHeader className="pb-4">
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Shield className="h-5 w-5 text-orange-500" />
                  Reseñas sospechosas
                </CardTitle>
                <CardDescription>
                  Reseñas detectadas como potencialmente fraudulentas
                </CardDescription>
              </CardHeader>
              <CardContent>
                {suspiciousLoading ? (
                  <div className="space-y-3">
                    {Array.from({ length: 3 }).map((_, i) => (
                      <Skeleton key={i} className="h-16 rounded" />
                    ))}
                  </div>
                ) : suspiciousReviews && suspiciousReviews.length > 0 ? (
                  <Table className="text-sm">
                    <TableHeader>
                      <TableRow className="border-b-muted">
                        <TableHead className="text-xs font-semibold uppercase text-muted-foreground">Negocio</TableHead>
                        <TableHead className="text-xs font-semibold uppercase text-muted-foreground">Cliente</TableHead>
                        <TableHead className="text-xs font-semibold uppercase text-muted-foreground">Calificación</TableHead>
                        <TableHead className="text-xs font-semibold uppercase text-muted-foreground">Comentario</TableHead>
                        <TableHead className="text-xs font-semibold uppercase text-muted-foreground">Razón</TableHead>
                        <TableHead className="text-xs font-semibold uppercase text-muted-foreground text-right">Acciones</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {suspiciousReviews.map((review) => (
                        <TableRow key={review.id} data-testid={`row-suspicious-${review.id}`}>
                          <TableCell className="font-medium" data-testid={`text-suspicious-business-${review.id}`}>
                            {review.business?.name || "N/A"}
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <Avatar className="h-6 w-6">
                                <AvatarImage src={review.client?.profileImageUrl || ""} />
                                <AvatarFallback className="text-xs">
                                  {review.client?.firstName?.[0] || "U"}
                                </AvatarFallback>
                              </Avatar>
                              <span className="text-sm" data-testid={`text-suspicious-client-${review.id}`}>
                                {review.client?.firstName} {review.client?.lastName}
                              </span>
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-1" data-testid={`text-suspicious-rating-${review.id}`}>
                              <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                              <span className="font-medium">{review.rating}</span>
                            </div>
                          </TableCell>
                          <TableCell className="max-w-[200px] truncate text-muted-foreground" data-testid={`text-suspicious-comment-${review.id}`}>
                            {review.comment || "-"}
                          </TableCell>
                          <TableCell className="max-w-[150px] truncate text-orange-600" data-testid={`text-suspicious-reason-${review.id}`}>
                            {(review as any).suspiciousReason || "Actividad sospechosa"}
                          </TableCell>
                          <TableCell className="text-right">
                            <Button
                              variant="destructive"
                              size="sm"
                              onClick={() => deleteReviewMutation.mutate(review.id)}
                              disabled={deleteReviewMutation.isPending}
                              data-testid={`button-delete-suspicious-${review.id}`}
                            >
                              <Trash2 className="h-4 w-4 mr-1" />
                              Eliminar
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                ) : (
                  <div className="py-12 text-center text-muted-foreground" data-testid="status-no-suspicious">
                    <Shield className="h-12 w-12 mx-auto mb-3 opacity-40" />
                    <p className="text-sm" data-testid="text-no-suspicious-message">No hay reseñas sospechosas</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="reports">
            <Card className="overflow-visible">
              <CardHeader className="pb-4">
                <CardTitle className="flex items-center gap-2 text-lg">
                  <AlertTriangle className="h-5 w-5" />
                  Reportes de contenido
                </CardTitle>
                <CardDescription>
                  Revisa los reportes enviados por los usuarios
                </CardDescription>
              </CardHeader>
              <CardContent>
                {reportsLoading ? (
                  <div className="space-y-3">
                    {Array.from({ length: 3 }).map((_, i) => (
                      <Skeleton key={i} className="h-16 rounded" />
                    ))}
                  </div>
                ) : reports && reports.length > 0 ? (
                  <Table className="text-sm">
                    <TableHeader>
                      <TableRow className="border-b-muted">
                        <TableHead className="text-xs font-semibold uppercase text-muted-foreground">Tipo</TableHead>
                        <TableHead className="text-xs font-semibold uppercase text-muted-foreground">Razón</TableHead>
                        <TableHead className="text-xs font-semibold uppercase text-muted-foreground">Detalles</TableHead>
                        <TableHead className="text-xs font-semibold uppercase text-muted-foreground">Reportado por</TableHead>
                        <TableHead className="text-xs font-semibold uppercase text-muted-foreground">Estado</TableHead>
                        <TableHead className="text-xs font-semibold uppercase text-muted-foreground text-right">Acciones</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {reports.map((report: any) => (
                        <TableRow key={report.id} data-testid={`row-report-${report.id}`}>
                          <TableCell data-testid={`text-report-type-${report.id}`}>
                            <Badge variant="outline">
                              {report.type === "business" ? "Negocio" : report.type === "chat" ? "Chat" : "Mensaje"}
                            </Badge>
                          </TableCell>
                          <TableCell className="font-medium" data-testid={`text-report-reason-${report.id}`}>
                            {report.reason}
                          </TableCell>
                          <TableCell className="max-w-[200px] truncate text-muted-foreground" data-testid={`text-report-details-${report.id}`}>
                            {report.details || "-"}
                          </TableCell>
                          <TableCell className="text-muted-foreground" data-testid={`text-report-reporter-${report.id}`}>
                            {report.reporter?.email || report.reporterEmail || "-"}
                          </TableCell>
                          <TableCell data-testid={`text-report-status-${report.id}`}>
                            <Badge variant={
                              report.status === "pending" ? "destructive" :
                              report.status === "reviewed" ? "default" : "secondary"
                            }>
                              {report.status === "pending" ? "Pendiente" :
                               report.status === "reviewed" ? "Revisado" : "Descartado"}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="flex items-center justify-end gap-2">
                              {report.status === "pending" && (
                                <>
                                  <Button
                                    size="sm"
                                    onClick={() => updateReportMutation.mutate({
                                      id: report.id,
                                      status: "reviewed",
                                    })}
                                    disabled={updateReportMutation.isPending}
                                    data-testid={`button-review-report-${report.id}`}
                                  >
                                    <Check className="h-4 w-4 mr-1" />
                                    Revisar
                                  </Button>
                                  <Button
                                    variant="outline"
                                    size="sm"
                                    onClick={() => updateReportMutation.mutate({
                                      id: report.id,
                                      status: "dismissed",
                                    })}
                                    disabled={updateReportMutation.isPending}
                                    data-testid={`button-dismiss-report-${report.id}`}
                                  >
                                    <X className="h-4 w-4 mr-1" />
                                    Descartar
                                  </Button>
                                </>
                              )}
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                ) : (
                  <div className="py-12 text-center text-muted-foreground" data-testid="status-no-reports">
                    <AlertTriangle className="h-12 w-12 mx-auto mb-3 opacity-40" />
                    <p className="text-sm" data-testid="text-no-reports-message">No hay reportes</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>

      <Dialog open={rechargeDialogOpen} onOpenChange={setRechargeDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Recarga manual de billetera</DialogTitle>
            <DialogDescription>
              Agregar saldo a la billetera de {selectedBusiness?.name}
            </DialogDescription>
          </DialogHeader>
          <div className="py-4 space-y-4">
            <div className="space-y-2">
              <Label htmlFor="amount">Monto a recargar (MXN)</Label>
              <Input
                id="amount"
                type="number"
                min="1"
                step="1"
                placeholder="100"
                value={rechargeAmount}
                onChange={(e) => setRechargeAmount(e.target.value)}
                data-testid="input-recharge-amount"
              />
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setRechargeDialogOpen(false)}
              data-testid="button-cancel-recharge"
            >
              Cancelar
            </Button>
            <Button
              onClick={handleRecharge}
              disabled={rechargeMutation.isPending || !rechargeAmount || parseFloat(rechargeAmount) <= 0}
              data-testid="button-confirm-recharge"
            >
              {rechargeMutation.isPending ? (
                <Loader2 className="h-4 w-4 animate-spin mr-2" />
              ) : null}
              Recargar ${rechargeAmount || "0"} MXN
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
