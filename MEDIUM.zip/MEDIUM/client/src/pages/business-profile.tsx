import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useRoute, Link } from "wouter";
import { 
  MapPin, 
  Phone, 
  MessageSquare, 
  BadgeCheck, 
  Clock, 
  Star,
  ChevronLeft,
  Share2,
  ExternalLink,
  ZoomIn,
  Flag,
  Heart,
  Crown,
} from "lucide-react";
import { SiWhatsapp } from "react-icons/si";
import { Header } from "@/components/header";
import { StarRating } from "@/components/star-rating";
import { ImageViewer } from "@/components/image-viewer";
import { ReportDialog } from "@/components/report-dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import { useAuth } from "@/hooks/use-auth";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { Business, Category, Review } from "@shared/schema";
import type { User } from "@shared/models/auth";

interface BusinessWithDetails extends Business {
  category?: Category;
  reviews?: (Review & { client?: User })[];
}

export default function BusinessProfilePage() {
  const [, params] = useRoute("/business/:slug");
  const slug = params?.slug;
  const { isAuthenticated } = useAuth();
  const { toast } = useToast();
  
  const [viewerOpen, setViewerOpen] = useState(false);
  const [viewerIndex, setViewerIndex] = useState(0);

  const { data: business, isLoading } = useQuery<BusinessWithDetails>({
    queryKey: [`/api/businesses/${slug}`],
    enabled: !!slug,
  });

  const { data: profile } = useQuery<{ role: string }>({
    queryKey: ["/api/profile"],
  });

  const { data: favoriteStatus } = useQuery<{ isFavorite: boolean }>({
    queryKey: ["/api/favorites/check", business?.id],
    enabled: isAuthenticated && !!business?.id,
  });

  const toggleFavoriteMutation = useMutation({
    mutationFn: async () => {
      if (favoriteStatus?.isFavorite) {
        await apiRequest("DELETE", `/api/favorites/${business!.id}`);
      } else {
        await apiRequest("POST", `/api/favorites/${business!.id}`);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/favorites/check", business?.id] });
      queryClient.invalidateQueries({ queryKey: ["/api/favorites"] });
      toast({
        title: favoriteStatus?.isFavorite ? "Eliminado de favoritos" : "Agregado a favoritos",
      });
    },
    onError: () => {
      toast({ title: "Error", description: "No se pudo actualizar favoritos.", variant: "destructive" });
    },
  });

  const openImageViewer = (index: number) => {
    setViewerIndex(index);
    setViewerOpen(true);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Header userRole={profile?.role} />
        <main className="container px-4 py-8">
          <Skeleton className="h-64 rounded-lg mb-6" />
          <Skeleton className="h-8 w-48 mb-2" />
          <Skeleton className="h-4 w-32 mb-6" />
          <div className="grid gap-6 md:grid-cols-3">
            <Skeleton className="h-32 rounded-lg md:col-span-2" />
            <Skeleton className="h-32 rounded-lg" />
          </div>
        </main>
      </div>
    );
  }

  if (!business) {
    return (
      <div className="min-h-screen bg-background">
        <Header userRole={profile?.role} />
        <main className="container px-4 py-12 text-center">
          <h1 className="text-2xl font-bold mb-2">Negocio no encontrado</h1>
          <p className="text-muted-foreground mb-6">
            El negocio que buscas no existe o ha sido desactivado.
          </p>
          <Link href="/search">
            <Button>Buscar negocios</Button>
          </Link>
        </main>
      </div>
    );
  }

  const initials = business.name
    .split(" ")
    .map((n) => n[0])
    .join("")
    .toUpperCase()
    .slice(0, 2);

  return (
    <div className="min-h-screen bg-background">
      <Header userRole={profile?.role} />

      <main className="container px-4 py-8 animate-fade-in">
        <Link href="/search">
          <Button variant="ghost" size="sm" className="mb-6 -ml-2 text-muted-foreground" data-testid="button-back">
            <ChevronLeft className="h-4 w-4 mr-1" />
            Volver a busqueda
          </Button>
        </Link>

        <div className="grid gap-8 lg:grid-cols-3">
          <div className="lg:col-span-2 space-y-8">
            <Card className="overflow-visible relative">
              <div className="absolute inset-0 rounded-md bg-gradient-to-br from-primary/5 via-transparent to-primary/3 pointer-events-none" />
              <CardContent className="p-6 sm:p-8 relative">
                <div className="flex flex-col sm:flex-row gap-6">
                  <Avatar className="h-24 w-24 md:h-28 md:w-28 rounded-lg flex-shrink-0">
                    <AvatarImage 
                      src={business.coverImage || ""} 
                      alt={business.name} 
                      className="object-cover"
                    />
                    <AvatarFallback className="rounded-lg bg-primary/10 text-primary text-2xl md:text-3xl font-bold">
                      {initials}
                    </AvatarFallback>
                  </Avatar>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-3 flex-wrap">
                      <div>
                        <div className="flex items-center gap-2 flex-wrap">
                          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">{business.name}</h1>
                          {business.isVerified && (
                            <Badge variant="secondary" className="no-default-active-elevate no-default-hover-elevate gap-1 text-primary">
                              <BadgeCheck className="h-3.5 w-3.5" />
                              Verificado
                            </Badge>
                          )}
                          {(business as any).plan === "premium" && (
                            <Badge className="bg-amber-500 hover:bg-amber-500 text-white gap-1 no-default-active-elevate no-default-hover-elevate">
                              <Crown className="h-3.5 w-3.5" />
                              Premium
                            </Badge>
                          )}
                          {(business as any).plan === "pro" && (
                            <Badge className="bg-blue-500 hover:bg-blue-500 text-white gap-1 no-default-active-elevate no-default-hover-elevate">
                              <Star className="h-3.5 w-3.5" />
                              Pro
                            </Badge>
                          )}
                        </div>
                        <p className="text-muted-foreground mt-1">
                          {business.category?.name}
                        </p>
                      </div>
                      <div className="flex items-center gap-1 rounded-md border border-border/50 p-0.5">
                        {isAuthenticated && (
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => toggleFavoriteMutation.mutate()}
                            disabled={toggleFavoriteMutation.isPending}
                            data-testid="button-toggle-favorite"
                          >
                            <Heart className={`h-4 w-4 ${favoriteStatus?.isFavorite ? "fill-current text-destructive" : ""}`} />
                          </Button>
                        )}
                        <Button variant="ghost" size="icon" data-testid="button-share">
                          <Share2 className="h-4 w-4" />
                        </Button>
                        <ReportDialog
                          type="business"
                          targetId={business.id}
                          trigger={
                            <Button variant="ghost" size="icon" data-testid="button-report-business">
                              <Flag className="h-4 w-4" />
                            </Button>
                          }
                        />
                      </div>
                    </div>

                    <div className="flex items-center gap-4 mt-4 flex-wrap">
                      <div className="inline-flex items-center gap-2 bg-muted/60 dark:bg-muted/30 rounded-full px-3 py-1.5">
                        <StarRating rating={Number(business.rating) || 0} size="md" />
                        <span className="font-semibold text-sm">
                          {Number(business.rating).toFixed(1)}
                        </span>
                        <span className="text-xs text-muted-foreground">
                          ({business.reviewCount})
                        </span>
                      </div>
                    </div>

                    {business.address && (
                      <div className="flex items-center gap-2 mt-4 text-sm text-muted-foreground">
                        <MapPin className="h-4 w-4 flex-shrink-0" />
                        <span>{business.address}</span>
                      </div>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>

            {business.description && (
              <Card className="overflow-visible">
                <CardHeader>
                  <CardTitle>Acerca de</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground whitespace-pre-line leading-relaxed">
                    {business.description}
                  </p>
                </CardContent>
              </Card>
            )}

            {business.services && business.services.length > 0 && (
              <Card className="overflow-visible">
                <CardHeader>
                  <CardTitle>Servicios</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-2.5">
                    {business.services.map((service, index) => (
                      <Badge key={index} variant="secondary" className="no-default-active-elevate no-default-hover-elevate px-3 py-1 text-sm">
                        {service}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            {business.gallery && business.gallery.length > 0 && (
              <Card className="overflow-visible">
                <CardHeader>
                  <CardTitle>Galeria de trabajos</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                    {business.gallery.map((image, index) => (
                      <button
                        key={index}
                        onClick={() => openImageViewer(index)}
                        className="aspect-square rounded-lg bg-muted relative group cursor-pointer focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2 shadow-sm hover:shadow-md transition-shadow duration-300"
                        data-testid={`gallery-image-${index}`}
                      >
                        <img
                          src={image}
                          alt={`Trabajo ${index + 1}`}
                          className="w-full h-full object-cover rounded-lg transition-transform duration-300 group-hover:scale-[1.03]"
                        />
                        <div className="absolute inset-0 rounded-lg bg-black/0 group-hover:bg-black/30 transition-colors duration-300 flex items-center justify-center">
                          <ZoomIn className="h-8 w-8 text-white opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                        </div>
                      </button>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            <Card className="overflow-visible">
              <CardHeader>
                <CardTitle>Opiniones ({business.reviewCount})</CardTitle>
              </CardHeader>
              <CardContent>
                {business.reviews && business.reviews.length > 0 ? (
                  <div className="space-y-0">
                    {business.reviews.map((review, idx) => (
                      <div key={review.id} className={`py-5 ${idx !== 0 ? "border-t border-border/50" : ""}`}>
                        <div className="flex items-start gap-4">
                          <Avatar className="h-10 w-10 flex-shrink-0">
                            <AvatarImage src={review.client?.profileImageUrl || ""} />
                            <AvatarFallback className="bg-primary/10 text-primary text-sm">
                              {review.client?.firstName?.[0] || "U"}
                            </AvatarFallback>
                          </Avatar>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center justify-between gap-2 flex-wrap">
                              <div className="flex items-center gap-2 flex-wrap">
                                <span className="font-medium">
                                  {review.client?.firstName} {review.client?.lastName?.[0]}.
                                </span>
                                {(review as any).isVerified && (
                                  <span className="inline-flex items-center gap-1 text-xs text-green-600 dark:text-green-400 bg-green-50 dark:bg-green-950/30 px-2 py-0.5 rounded-full" data-testid={`badge-verified-${review.id}`}>
                                    <BadgeCheck className="h-3 w-3" />
                                    Verificada
                                  </span>
                                )}
                              </div>
                              <span className="text-xs text-muted-foreground">
                                {new Date(review.createdAt!).toLocaleDateString("es-MX", {
                                  day: "numeric",
                                  month: "short",
                                  year: "numeric",
                                })}
                              </span>
                            </div>
                            <div className="mt-1.5">
                              <StarRating rating={review.rating} size="sm" />
                            </div>
                            {review.comment && (
                              <p className="text-sm text-muted-foreground mt-2 leading-relaxed">
                                {review.comment}
                              </p>
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-muted-foreground text-center py-8">
                    Este negocio aun no tiene opiniones
                  </p>
                )}
              </CardContent>
            </Card>
          </div>

          <div className="space-y-6">
            <Card className="sticky top-24 overflow-visible z-10">
              <CardHeader>
                <CardTitle>Contactar</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Link href={`/request/${business.id}`}>
                  <Button className="w-full" size="lg" data-testid="button-request-service">
                    <MessageSquare className="h-4 w-4 mr-2" />
                    Solicitar servicio
                  </Button>
                </Link>

                <div className="space-y-2 pt-1">
                  {business.whatsapp && (
                    <a
                      href={`https://wa.me/${business.whatsapp.replace(/\D/g, "")}`}
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      <Button variant="outline" className="w-full" size="lg">
                        <SiWhatsapp className="h-4 w-4 mr-2 text-green-500" />
                        WhatsApp
                      </Button>
                    </a>
                  )}

                  {business.phone && (
                    <a href={`tel:${business.phone}`}>
                      <Button variant="outline" className="w-full" size="lg">
                        <Phone className="h-4 w-4 mr-2" />
                        Llamar
                      </Button>
                    </a>
                  )}
                </div>

                {business.estimatedPrices && (
                  <>
                    <Separator className="my-4" />
                    <div>
                      <h4 className="font-medium text-sm mb-2">Precios estimados</h4>
                      <p className="text-sm text-muted-foreground whitespace-pre-line leading-relaxed">
                        {business.estimatedPrices}
                      </p>
                    </div>
                  </>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      {business.gallery && business.gallery.length > 0 && (
        <ImageViewer
          images={business.gallery}
          initialIndex={viewerIndex}
          isOpen={viewerOpen}
          onClose={() => setViewerOpen(false)}
        />
      )}
    </div>
  );
}
