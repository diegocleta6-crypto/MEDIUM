import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { 
  MessageSquare, 
  Clock, 
  CheckCircle, 
  ChevronRight,
  Inbox
} from "lucide-react";
import { Header } from "@/components/header";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Skeleton } from "@/components/ui/skeleton";
import type { ServiceRequest, Business, Message } from "@shared/schema";
import type { User } from "@shared/models/auth";

interface RequestWithDetails extends ServiceRequest {
  business?: Business;
  client?: User;
  messages?: Message[];
  lastMessage?: Message;
}

export default function ChatsPage() {
  const { isAuthenticated, isLoading: authLoading } = useAuth();
  
  const { data: profile } = useQuery<{ role: string }>({
    queryKey: ["/api/profile"],
    enabled: isAuthenticated,
  });

  const { data: requests, isLoading } = useQuery<RequestWithDetails[]>({
    queryKey: ["/api/chats"],
    enabled: isAuthenticated,
  });

  // Show loading while checking auth
  if (authLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="h-8 w-8 border-4 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  // Redirect to login if not authenticated
  if (!isAuthenticated) {
    window.location.href = "/api/login";
    return null;
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pending":
        return <Badge variant="secondary" className="text-xs"><Clock className="h-3 w-3 mr-1" />Pendiente</Badge>;
      case "accepted":
        return <Badge variant="default" className="text-xs"><MessageSquare className="h-3 w-3 mr-1" />En proceso</Badge>;
      case "completed":
        return <Badge variant="default" className="text-xs bg-primary"><CheckCircle className="h-3 w-3 mr-1" />Completado</Badge>;
      default:
        return <Badge variant="secondary" className="text-xs">{status}</Badge>;
    }
  };

  const initials = (name: string) =>
    name?.split(" ").map((n) => n[0]).join("").toUpperCase().slice(0, 2) || "?";

  const formatDate = (date: Date | string | null) => {
    if (!date) return "";
    const d = new Date(date);
    const now = new Date();
    const diff = now.getTime() - d.getTime();
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    
    if (hours < 1) return "Hace un momento";
    if (hours < 24) return `Hace ${hours}h`;
    if (days < 7) return `Hace ${days}d`;
    return d.toLocaleDateString("es-MX", { day: "numeric", month: "short" });
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Header userRole={profile?.role} />
        <main className="container px-4 py-6 max-w-2xl">
          <h1 className="text-2xl font-bold tracking-tight mb-6">Mis chats</h1>
          <div className="space-y-3">
            {Array.from({ length: 5 }).map((_, i) => (
              <Skeleton key={i} className="h-20 rounded-lg" />
            ))}
          </div>
        </main>
      </div>
    );
  }

  const activeChats = requests?.filter(r => r.status !== "cancelled") || [];

  return (
    <div className="min-h-screen bg-background">
      <Header userRole={profile?.role} />

      <main className="container px-4 py-8 max-w-2xl animate-fade-in">
        <div className="flex items-center gap-3 mb-8">
          <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
            <MessageSquare className="h-5 w-5 text-primary" />
          </div>
          <h1 className="text-2xl font-bold tracking-tight">Mis chats</h1>
        </div>

        {activeChats.length === 0 ? (
          <Card className="overflow-visible">
            <CardContent className="py-16 text-center">
              <div className="mx-auto mb-5 h-16 w-16 rounded-full bg-muted/50 flex items-center justify-center">
                <Inbox className="h-8 w-8 text-muted-foreground/60" />
              </div>
              <h3 className="font-medium mb-2">Sin conversaciones</h3>
              <p className="text-muted-foreground">
                Cuando solicites un servicio o recibas una solicitud, tus chats aparecerán aquí.
              </p>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-2">
            {activeChats.map((request) => {
              const otherParty = profile?.role === "business" 
                ? request.client 
                : request.business;
              const otherName = profile?.role === "business"
                ? `${request.client?.firstName || ""} ${request.client?.lastName || ""}`.trim() || "Cliente"
                : request.business?.name || "Negocio";
              const otherImage = profile?.role === "business"
                ? request.client?.profileImageUrl
                : request.business?.coverImage;

              return (
                <Link key={request.id} href={`/requests/${request.id}`}>
                  <Card className="hover-elevate cursor-pointer transition-colors overflow-visible" data-testid={`chat-item-${request.id}`}>
                    <CardContent className="p-4">
                      <div className="flex items-center gap-3">
                        <Avatar className="h-12 w-12 flex-shrink-0">
                          <AvatarImage src={otherImage || ""} />
                          <AvatarFallback className="bg-primary/10 text-primary">
                            {initials(otherName)}
                          </AvatarFallback>
                        </Avatar>

                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between gap-2">
                            <h3 className="font-medium truncate" data-testid={`chat-name-${request.id}`}>
                              {otherName}
                            </h3>
                            <span className="text-xs text-muted-foreground flex-shrink-0">
                              {formatDate(request.lastMessage?.createdAt || request.createdAt)}
                            </span>
                          </div>
                          
                          <p className="text-sm text-muted-foreground truncate mt-1" data-testid={`chat-preview-${request.id}`}>
                            {request.lastMessage?.content || request.description?.slice(0, 50) || "Sin mensajes"}
                          </p>
                          
                          <div className="flex items-center justify-between gap-2 mt-2">
                            {getStatusBadge(request.status)}
                          </div>
                        </div>

                        <ChevronRight className="h-5 w-5 text-muted-foreground flex-shrink-0" />
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              );
            })}
          </div>
        )}
      </main>
    </div>
  );
}
