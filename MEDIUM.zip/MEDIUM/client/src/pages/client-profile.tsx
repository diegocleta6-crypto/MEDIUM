import { useQuery, useMutation } from "@tanstack/react-query";
import { Link, useSearch } from "wouter";
import { 
  User, 
  History, 
  Star, 
  Share2, 
  CheckCircle, 
  Clock, 
  MessageSquare,
  ChevronRight,
  Copy,
  Check,
  Edit2,
  Trash2,
  MoreVertical,
  Heart,
  Camera,
  X,
  Phone,
  MapPin,
  Save,
} from "lucide-react";
import { SiFacebook, SiWhatsapp } from "react-icons/si";
import { Header } from "@/components/header";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { StarRating } from "@/components/star-rating";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useState, useRef } from "react";
import type { ServiceRequest, Business, Review, Category, Favorite } from "@shared/schema";

interface RequestWithDetails extends ServiceRequest {
  business?: Business;
  review?: Review;
}

interface UserProfile {
  id: string;
  userId: string;
  role: string;
  displayName?: string | null;
  avatarUrl?: string | null;
  phone?: string | null;
  whatsapp?: string | null;
  address?: string | null;
}

interface FavoriteWithBusiness extends Favorite {
  business?: Business & { category?: Category };
}

export default function ClientProfilePage() {
  const { user, isAuthenticated, isLoading: authLoading } = useAuth();
  const { toast } = useToast();
  const searchParams = useSearch();
  const tabParam = new URLSearchParams(searchParams).get("tab");
  const [reviewingId, setReviewingId] = useState<string | null>(null);
  const [editingReviewId, setEditingReviewId] = useState<string | null>(null);
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState("");
  const [copiedLink, setCopiedLink] = useState<string | null>(null);
  const [isEditingProfile, setIsEditingProfile] = useState(false);
  const [editDisplayName, setEditDisplayName] = useState("");
  const [editPhone, setEditPhone] = useState("");
  const [editWhatsapp, setEditWhatsapp] = useState("");
  const [editAddress, setEditAddress] = useState("");
  const [editAvatarUrl, setEditAvatarUrl] = useState("");
  const fileInputRef = useRef<HTMLInputElement>(null);

  const { data: profile, isLoading: profileLoading } = useQuery<UserProfile>({
    queryKey: ["/api/profile"],
    enabled: isAuthenticated,
  });

  // Show loading while checking auth
  if (authLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="h-8 w-8 border-4 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  // Redirect to login if not authenticated
  if (!isAuthenticated) {
    window.location.href = "/api/login";
    return null;
  }

  // Redirect businesses to their profile in dashboard
  if (!profileLoading && profile?.role === "business") {
    window.location.href = "/dashboard/edit";
    return null;
  }
  
  // Redirect admins to admin panel
  if (!profileLoading && profile?.role === "admin") {
    window.location.href = "/admin";
    return null;
  }

  const { data: requests, isLoading } = useQuery<RequestWithDetails[]>({
    queryKey: ["/api/requests/my"],
  });

  const { data: favorites, isLoading: favoritesLoading } = useQuery<FavoriteWithBusiness[]>({
    queryKey: ["/api/favorites"],
    enabled: isAuthenticated,
  });

  const updateProfileMutation = useMutation({
    mutationFn: async (data: { displayName?: string; avatarUrl?: string; phone?: string; whatsapp?: string; address?: string }) => {
      const res = await apiRequest("PATCH", "/api/profile", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/profile"] });
      toast({ title: "Perfil actualizado", description: "Tu perfil ha sido actualizado correctamente." });
      setIsEditingProfile(false);
    },
    onError: () => {
      toast({ title: "Error", description: "No se pudo actualizar el perfil.", variant: "destructive" });
    },
  });

  const removeFavoriteMutation = useMutation({
    mutationFn: async (businessId: string) => {
      await apiRequest("DELETE", `/api/favorites/${businessId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/favorites"] });
      toast({ title: "Favorito eliminado", description: "El negocio ha sido eliminado de tus favoritos." });
    },
    onError: () => {
      toast({ title: "Error", description: "No se pudo eliminar el favorito.", variant: "destructive" });
    },
  });

  const cancelRequestMutation = useMutation({
    mutationFn: async (requestId: string) => {
      const res = await apiRequest("PATCH", `/api/requests/${requestId}/status`, { status: "cancelled" });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/requests/my"] });
      toast({ title: "Solicitud cancelada", description: "Tu solicitud ha sido cancelada." });
    },
    onError: () => {
      toast({ title: "Error", description: "No se pudo cancelar la solicitud.", variant: "destructive" });
    },
  });

  const submitReviewMutation = useMutation({
    mutationFn: async ({ serviceRequestId, businessId }: { serviceRequestId: string; businessId: string }) => {
      const res = await apiRequest("POST", "/api/reviews", {
        serviceRequestId,
        businessId,
        rating,
        comment,
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/requests/my"] });
      toast({ title: "Reseña enviada", description: "Gracias por tu opinión." });
      setReviewingId(null);
      setRating(5);
      setComment("");
    },
    onError: () => {
      toast({ title: "Error", description: "No se pudo enviar la reseña.", variant: "destructive" });
    },
  });

  const updateReviewMutation = useMutation({
    mutationFn: async ({ reviewId }: { reviewId: string }) => {
      const res = await apiRequest("PATCH", `/api/reviews/${reviewId}`, {
        rating,
        comment,
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/requests/my"] });
      toast({ title: "Reseña actualizada", description: "Tu reseña ha sido actualizada." });
      setEditingReviewId(null);
      setRating(5);
      setComment("");
    },
    onError: () => {
      toast({ title: "Error", description: "No se pudo actualizar la reseña.", variant: "destructive" });
    },
  });

  const deleteReviewMutation = useMutation({
    mutationFn: async (reviewId: string) => {
      await apiRequest("DELETE", `/api/reviews/${reviewId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/requests/my"] });
      toast({ title: "Reseña eliminada", description: "Tu reseña ha sido eliminada." });
    },
    onError: () => {
      toast({ title: "Error", description: "No se pudo eliminar la reseña.", variant: "destructive" });
    },
  });

  const startEditReview = (review: Review) => {
    setEditingReviewId(review.id);
    setRating(review.rating);
    setComment(review.comment || "");
  };

  const startEditProfile = () => {
    setEditDisplayName(profile?.displayName || user?.firstName || "");
    setEditPhone(profile?.phone || "");
    setEditWhatsapp(profile?.whatsapp || "");
    setEditAddress(profile?.address || "");
    setEditAvatarUrl(profile?.avatarUrl || "");
    setIsEditingProfile(true);
  };

  const handleAvatarUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) {
      toast({ title: "Error", description: "La imagen no debe superar los 5MB.", variant: "destructive" });
      return;
    }
    const reader = new FileReader();
    reader.onloadend = () => {
      setEditAvatarUrl(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleSaveProfile = () => {
    updateProfileMutation.mutate({
      displayName: editDisplayName || undefined,
      avatarUrl: editAvatarUrl || undefined,
      phone: editPhone || undefined,
      whatsapp: editWhatsapp || undefined,
      address: editAddress || undefined,
    });
  };

  const completedRequests = requests?.filter((r) => r.status === "completed") || [];
  const pendingRequests = requests?.filter((r) => r.status !== "completed" && r.status !== "cancelled") || [];

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pending":
        return <Badge variant="secondary"><Clock className="h-3 w-3 mr-1" />Pendiente</Badge>;
      case "accepted":
        return <Badge variant="default"><MessageSquare className="h-3 w-3 mr-1" />En proceso</Badge>;
      case "completed":
        return <Badge variant="default" className="bg-primary"><CheckCircle className="h-3 w-3 mr-1" />Completado</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  const shareOnWhatsApp = (business: Business) => {
    const url = `${window.location.origin}/business/${business.slug}`;
    const text = `¡Te recomiendo ${business.name}! Mira su perfil: ${url}`;
    window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, "_blank");
  };

  const shareOnFacebook = (business: Business) => {
    const url = `${window.location.origin}/business/${business.slug}`;
    window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`, "_blank");
  };

  const copyLink = async (business: Business) => {
    const url = `${window.location.origin}/business/${business.slug}`;
    await navigator.clipboard.writeText(url);
    setCopiedLink(business.id);
    toast({ title: "Enlace copiado", description: "El enlace ha sido copiado al portapapeles." });
    setTimeout(() => setCopiedLink(null), 2000);
  };

  const initials = (name: string) =>
    name.split(" ").map((n) => n[0]).join("").toUpperCase().slice(0, 2);

  const displayAvatar = profile?.avatarUrl || user?.profileImageUrl || "";
  const displayName = profile?.displayName || `${user?.firstName || ""} ${user?.lastName || ""}`.trim();

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Header userRole={profile?.role} />
        <main className="container px-4 py-6 max-w-4xl">
          <Skeleton className="h-10 w-48 mb-6" />
          <Skeleton className="h-64 rounded-lg" />
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header userRole={profile?.role} />

      <main className="container px-4 py-8 max-w-4xl animate-fade-in">
        {isEditingProfile ? (
          <Card className="overflow-visible mb-6">
            <CardHeader>
              <div className="flex items-center justify-between gap-2 flex-wrap">
                <CardTitle className="tracking-tight">Editar perfil</CardTitle>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setIsEditingProfile(false)}
                  data-testid="button-cancel-edit-profile"
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center gap-4">
                <div className="relative">
                  <Avatar className="h-20 w-20">
                    <AvatarImage src={editAvatarUrl || ""} />
                    <AvatarFallback className="bg-primary/10 text-primary text-2xl">
                      {initials(editDisplayName || user?.firstName || "U")}
                    </AvatarFallback>
                  </Avatar>
                  <Button
                    variant="secondary"
                    size="icon"
                    className="absolute -bottom-1 -right-1 rounded-full"
                    onClick={() => fileInputRef.current?.click()}
                    data-testid="button-upload-avatar"
                  >
                    <Camera className="h-4 w-4" />
                  </Button>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={handleAvatarUpload}
                    data-testid="input-avatar-file"
                  />
                </div>
                <div className="flex-1">
                  <p className="text-sm text-muted-foreground">
                    Sube una foto de perfil (máx. 5MB)
                  </p>
                </div>
              </div>

              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="displayName">Nombre para mostrar</Label>
                  <Input
                    id="displayName"
                    value={editDisplayName}
                    onChange={(e) => setEditDisplayName(e.target.value)}
                    placeholder="Tu nombre"
                    data-testid="input-display-name"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="phone">Teléfono</Label>
                  <Input
                    id="phone"
                    value={editPhone}
                    onChange={(e) => setEditPhone(e.target.value)}
                    placeholder="+52 123 456 7890"
                    data-testid="input-phone"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="whatsapp">WhatsApp</Label>
                  <Input
                    id="whatsapp"
                    value={editWhatsapp}
                    onChange={(e) => setEditWhatsapp(e.target.value)}
                    placeholder="+52 123 456 7890"
                    data-testid="input-whatsapp"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="address">Dirección</Label>
                  <Input
                    id="address"
                    value={editAddress}
                    onChange={(e) => setEditAddress(e.target.value)}
                    placeholder="Tu dirección"
                    data-testid="input-address"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2">
                <Button
                  variant="outline"
                  onClick={() => setIsEditingProfile(false)}
                  data-testid="button-cancel-profile"
                >
                  Cancelar
                </Button>
                <Button
                  onClick={handleSaveProfile}
                  disabled={updateProfileMutation.isPending}
                  data-testid="button-save-profile"
                >
                  <Save className="h-4 w-4 mr-2" />
                  {updateProfileMutation.isPending ? "Guardando..." : "Guardar"}
                </Button>
              </div>
            </CardContent>
          </Card>
        ) : (
          <div className="flex items-center gap-4 mb-6">
            <Avatar className="h-16 w-16">
              <AvatarImage src={displayAvatar} />
              <AvatarFallback className="bg-primary/10 text-primary text-xl">
                {initials(user?.firstName || "U")}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <h1 className="text-2xl font-bold tracking-tight" data-testid="text-display-name">{displayName}</h1>
              <p className="text-muted-foreground" data-testid="text-email">{user?.email}</p>
              {profile?.phone && (
                <p className="text-sm text-muted-foreground flex items-center gap-1 mt-1" data-testid="text-phone">
                  <Phone className="h-3 w-3" /> {profile.phone}
                </p>
              )}
              {profile?.address && (
                <p className="text-sm text-muted-foreground flex items-center gap-1" data-testid="text-address">
                  <MapPin className="h-3 w-3" /> {profile.address}
                </p>
              )}
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={startEditProfile}
              data-testid="button-edit-profile"
            >
              <Edit2 className="h-4 w-4 mr-2" />
              Editar
            </Button>
          </div>
        )}

        <Tabs defaultValue={tabParam === "favorites" ? "favorites" : "completed"} className="space-y-4">
          <TabsList>
            <TabsTrigger value="completed" data-testid="tab-completed">
              <CheckCircle className="h-4 w-4 mr-2" />
              Completados ({completedRequests.length})
            </TabsTrigger>
            <TabsTrigger value="active" data-testid="tab-active">
              <Clock className="h-4 w-4 mr-2" />
              Activos ({pendingRequests.length})
            </TabsTrigger>
            <TabsTrigger value="favorites" data-testid="tab-favorites">
              <Heart className="h-4 w-4 mr-2" />
              Favoritos ({favorites?.length || 0})
            </TabsTrigger>
          </TabsList>

          <TabsContent value="completed" className="space-y-4">
            {completedRequests.length === 0 ? (
              <Card className="overflow-visible">
                <CardContent className="py-16 text-center">
                  <div className="mx-auto mb-5 h-16 w-16 rounded-full bg-muted/50 flex items-center justify-center">
                    <History className="h-8 w-8 text-muted-foreground/60" />
                  </div>
                  <h3 className="font-semibold mb-2">Sin servicios completados</h3>
                  <p className="text-muted-foreground mb-4">
                    Cuando completes un servicio, aparecerá aquí
                  </p>
                  <Link href="/search">
                    <Button data-testid="button-search-services">Buscar servicios</Button>
                  </Link>
                </CardContent>
              </Card>
            ) : (
              completedRequests.map((request) => (
                <Card key={request.id} className="overflow-visible">
                  <CardContent className="p-4">
                    <div className="flex items-start gap-4">
                      <Avatar className="h-12 w-12 rounded-md flex-shrink-0">
                        <AvatarImage src={request.business?.coverImage || ""} />
                        <AvatarFallback className="rounded-md bg-primary/10 text-primary">
                          {initials(request.business?.name || "N")}
                        </AvatarFallback>
                      </Avatar>

                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between gap-2 flex-wrap mb-2">
                          <Link href={`/business/${request.business?.slug}`}>
                            <h3 className="font-medium hover:text-primary transition-colors" data-testid={`link-business-${request.id}`}>
                              {request.business?.name}
                            </h3>
                          </Link>
                          {getStatusBadge(request.status)}
                        </div>

                        <p className="text-sm text-muted-foreground mb-2 line-clamp-2">
                          {request.description}
                        </p>

                        <div className="flex items-center gap-3 text-xs text-muted-foreground mb-3">
                          <span>
                            {new Date(request.createdAt!).toLocaleDateString("es-MX", {
                              year: "numeric",
                              month: "long",
                              day: "numeric",
                            })}
                          </span>
                          {request.leadCost && (
                            <Badge variant="outline" className="text-xs">
                              Costo de lead: ${Number(request.leadCost).toFixed(0)} MXN
                            </Badge>
                          )}
                        </div>

                        {request.review && editingReviewId !== request.review.id ? (
                          <div className="bg-muted/50 rounded-lg p-3">
                            <div className="flex items-center justify-between gap-2 mb-1">
                              <div className="flex items-center gap-2">
                                <StarRating rating={request.review.rating} size="sm" />
                                <span className="text-sm text-muted-foreground">Tu reseña</span>
                              </div>
                              <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                  <Button variant="ghost" size="icon" data-testid={`button-review-menu-${request.review.id}`}>
                                    <MoreVertical className="h-4 w-4" />
                                  </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="end">
                                  <DropdownMenuItem onClick={() => startEditReview(request.review!)} data-testid="edit-review">
                                    <Edit2 className="h-4 w-4 mr-2" />
                                    Editar
                                  </DropdownMenuItem>
                                  <DropdownMenuItem 
                                    onClick={() => deleteReviewMutation.mutate(request.review!.id)}
                                    className="text-destructive"
                                    data-testid="delete-review"
                                  >
                                    <Trash2 className="h-4 w-4 mr-2" />
                                    Eliminar
                                  </DropdownMenuItem>
                                </DropdownMenuContent>
                              </DropdownMenu>
                            </div>
                            {request.review.comment && (
                              <p className="text-sm">{request.review.comment}</p>
                            )}
                          </div>
                        ) : editingReviewId === request.review?.id ? (
                          <div className="border rounded-lg p-3 space-y-3">
                            <p className="text-sm font-medium">Editar tu reseña</p>
                            <div className="flex justify-center">
                              <StarRating
                                rating={rating}
                                size="lg"
                                interactive
                                onRate={setRating}
                              />
                            </div>
                            <Textarea
                              value={comment}
                              onChange={(e) => setComment(e.target.value)}
                              placeholder="Cuéntanos tu experiencia..."
                              className="resize-none"
                              data-testid="textarea-edit-review"
                            />
                            <div className="flex gap-2">
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => setEditingReviewId(null)}
                                data-testid="button-cancel-edit"
                              >
                                Cancelar
                              </Button>
                              <Button
                                size="sm"
                                onClick={() => updateReviewMutation.mutate({ reviewId: request.review!.id })}
                                disabled={updateReviewMutation.isPending}
                                data-testid="button-save-review"
                              >
                                Guardar cambios
                              </Button>
                            </div>
                          </div>
                        ) : reviewingId === request.id ? (
                          <div className="border rounded-lg p-3 space-y-3">
                            <p className="text-sm font-medium">Califica el servicio</p>
                            <div className="flex justify-center">
                              <StarRating
                                rating={rating}
                                size="lg"
                                interactive
                                onRate={setRating}
                              />
                            </div>
                            <Textarea
                              value={comment}
                              onChange={(e) => setComment(e.target.value)}
                              placeholder="Cuéntanos tu experiencia..."
                              className="resize-none"
                              data-testid="textarea-review"
                            />
                            <div className="flex gap-2">
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => setReviewingId(null)}
                                data-testid="button-cancel-review"
                              >
                                Cancelar
                              </Button>
                              <Button
                                size="sm"
                                onClick={() => submitReviewMutation.mutate({
                                  serviceRequestId: request.id,
                                  businessId: request.businessId,
                                })}
                                disabled={submitReviewMutation.isPending}
                                data-testid="button-submit-review"
                              >
                                Enviar reseña
                              </Button>
                            </div>
                          </div>
                        ) : (
                          <div className="flex items-center gap-2 flex-wrap">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => setReviewingId(request.id)}
                              data-testid={`button-write-review-${request.id}`}
                            >
                              <Star className="h-4 w-4 mr-1" />
                              Dejar reseña
                            </Button>

                            {request.business && (
                              <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                  <Button variant="ghost" size="sm" data-testid={`button-share-${request.id}`}>
                                    <Share2 className="h-4 w-4 mr-1" />
                                    Compartir
                                  </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="start">
                                  <DropdownMenuItem onClick={() => shareOnWhatsApp(request.business!)} data-testid="share-whatsapp">
                                    <SiWhatsapp className="h-4 w-4 mr-2 text-green-500" />
                                    WhatsApp
                                  </DropdownMenuItem>
                                  <DropdownMenuItem onClick={() => shareOnFacebook(request.business!)} data-testid="share-facebook">
                                    <SiFacebook className="h-4 w-4 mr-2 text-blue-600" />
                                    Facebook
                                  </DropdownMenuItem>
                                  <DropdownMenuItem onClick={() => copyLink(request.business!)} data-testid="share-copy">
                                    {copiedLink === request.business!.id ? (
                                      <Check className="h-4 w-4 mr-2 text-green-500" />
                                    ) : (
                                      <Copy className="h-4 w-4 mr-2" />
                                    )}
                                    Copiar enlace
                                  </DropdownMenuItem>
                                </DropdownMenuContent>
                              </DropdownMenu>
                            )}

                            <Link href={`/requests/${request.id}`}>
                              <Button variant="ghost" size="sm" data-testid={`button-view-${request.id}`}>
                                Ver detalles
                                <ChevronRight className="h-4 w-4 ml-1" />
                              </Button>
                            </Link>
                          </div>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </TabsContent>

          <TabsContent value="active" className="space-y-4">
            {pendingRequests.length === 0 ? (
              <Card className="overflow-visible">
                <CardContent className="py-16 text-center">
                  <div className="mx-auto mb-5 h-16 w-16 rounded-full bg-muted/50 flex items-center justify-center">
                    <Clock className="h-8 w-8 text-muted-foreground/60" />
                  </div>
                  <h3 className="font-semibold mb-2">Sin servicios activos</h3>
                  <p className="text-muted-foreground mb-4">
                    No tienes solicitudes pendientes o en proceso
                  </p>
                  <Link href="/search">
                    <Button data-testid="button-search-active">Buscar servicios</Button>
                  </Link>
                </CardContent>
              </Card>
            ) : (
              pendingRequests.map((request) => (
                <Card key={request.id} className="overflow-visible">
                  <CardContent className="p-4">
                    <div className="flex items-start gap-4">
                      <Avatar className="h-12 w-12 rounded-md flex-shrink-0">
                        <AvatarImage src={request.business?.coverImage || ""} />
                        <AvatarFallback className="rounded-md bg-primary/10 text-primary">
                          {initials(request.business?.name || "N")}
                        </AvatarFallback>
                      </Avatar>

                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between gap-2 flex-wrap mb-2">
                          <Link href={`/business/${request.business?.slug}`}>
                            <h3 className="font-medium hover:text-primary transition-colors">
                              {request.business?.name}
                            </h3>
                          </Link>
                          {getStatusBadge(request.status)}
                        </div>

                        <p className="text-sm text-muted-foreground mb-2 line-clamp-2">
                          {request.description}
                        </p>

                        <div className="flex items-center justify-between flex-wrap gap-2">
                          <div className="flex items-center gap-2">
                            <span className="text-xs text-muted-foreground">
                              {new Date(request.createdAt!).toLocaleDateString("es-MX")}
                            </span>
                            {request.leadCost && (
                              <Badge variant="outline" className="text-xs">
                                ${Number(request.leadCost).toFixed(0)} MXN
                              </Badge>
                            )}
                          </div>
                          <div className="flex items-center gap-2">
                            <AlertDialog>
                              <AlertDialogTrigger asChild>
                                <Button
                                  variant="outline"
                                  size="sm"
                                  className="text-destructive"
                                  data-testid={`button-cancel-request-${request.id}`}
                                >
                                  <X className="h-4 w-4 mr-1" />
                                  Cancelar
                                </Button>
                              </AlertDialogTrigger>
                              <AlertDialogContent>
                                <AlertDialogHeader>
                                  <AlertDialogTitle>Cancelar solicitud</AlertDialogTitle>
                                  <AlertDialogDescription>
                                    ¿Estás seguro de que deseas cancelar esta solicitud? Esta acción no se puede deshacer.
                                  </AlertDialogDescription>
                                </AlertDialogHeader>
                                <AlertDialogFooter>
                                  <AlertDialogCancel data-testid="button-cancel-dialog-dismiss">
                                    No, mantener
                                  </AlertDialogCancel>
                                  <AlertDialogAction
                                    onClick={() => cancelRequestMutation.mutate(request.id)}
                                    className="bg-destructive text-destructive-foreground"
                                    data-testid="button-cancel-dialog-confirm"
                                  >
                                    Sí, cancelar
                                  </AlertDialogAction>
                                </AlertDialogFooter>
                              </AlertDialogContent>
                            </AlertDialog>
                            <Link href={`/requests/${request.id}`}>
                              <Button variant="ghost" size="sm" data-testid={`button-view-active-${request.id}`}>
                                Ver detalles
                                <ChevronRight className="h-4 w-4 ml-1" />
                              </Button>
                            </Link>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </TabsContent>

          <TabsContent value="favorites" className="space-y-4">
            {favoritesLoading ? (
              <div className="space-y-4">
                <Skeleton className="h-32 rounded-lg" />
                <Skeleton className="h-32 rounded-lg" />
              </div>
            ) : !favorites || favorites.length === 0 ? (
              <Card className="overflow-visible">
                <CardContent className="py-16 text-center">
                  <div className="mx-auto mb-5 h-16 w-16 rounded-full bg-muted/50 flex items-center justify-center">
                    <Heart className="h-8 w-8 text-muted-foreground/60" />
                  </div>
                  <h3 className="font-semibold mb-2">Sin favoritos</h3>
                  <p className="text-muted-foreground mb-4">
                    Guarda tus negocios favoritos para encontrarlos rápidamente
                  </p>
                  <Link href="/search">
                    <Button data-testid="button-search-favorites">Buscar servicios</Button>
                  </Link>
                </CardContent>
              </Card>
            ) : (
              favorites.map((fav) => (
                <Card key={fav.id} className="overflow-visible" data-testid={`card-favorite-${fav.businessId}`}>
                  <CardContent className="p-4">
                    <div className="flex items-start gap-4">
                      <Avatar className="h-12 w-12 rounded-md flex-shrink-0">
                        <AvatarImage src={fav.business?.coverImage || ""} />
                        <AvatarFallback className="rounded-md bg-primary/10 text-primary">
                          {initials(fav.business?.name || "N")}
                        </AvatarFallback>
                      </Avatar>

                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between gap-2 flex-wrap mb-1">
                          <Link href={`/business/${fav.business?.slug}`}>
                            <h3 className="font-medium hover:text-primary transition-colors" data-testid={`link-favorite-business-${fav.businessId}`}>
                              {fav.business?.name}
                            </h3>
                          </Link>
                          {fav.business?.category && (
                            <Badge variant="secondary" className="text-xs">
                              {fav.business.category.name}
                            </Badge>
                          )}
                        </div>

                        {fav.business?.description && (
                          <p className="text-sm text-muted-foreground mb-2 line-clamp-2">
                            {fav.business.description}
                          </p>
                        )}

                        <div className="flex items-center justify-between flex-wrap gap-2">
                          <div className="flex items-center gap-2">
                            {fav.business?.rating && Number(fav.business.rating) > 0 && (
                              <div className="flex items-center gap-1">
                                <StarRating rating={Number(fav.business.rating)} size="sm" />
                                <span className="text-sm text-muted-foreground">
                                  ({fav.business.reviewCount})
                                </span>
                              </div>
                            )}
                            {fav.business?.isVerified && (
                              <Badge variant="outline" className="text-xs">
                                <CheckCircle className="h-3 w-3 mr-1" />
                                Verificado
                              </Badge>
                            )}
                          </div>
                          <div className="flex items-center gap-2">
                            <Button
                              variant="ghost"
                              size="sm"
                              className="text-destructive"
                              onClick={() => removeFavoriteMutation.mutate(fav.businessId)}
                              disabled={removeFavoriteMutation.isPending}
                              data-testid={`button-remove-favorite-${fav.businessId}`}
                            >
                              <Trash2 className="h-4 w-4 mr-1" />
                              Eliminar
                            </Button>
                            <Link href={`/business/${fav.business?.slug}`}>
                              <Button variant="ghost" size="sm" data-testid={`button-view-favorite-${fav.businessId}`}>
                                Ver perfil
                                <ChevronRight className="h-4 w-4 ml-1" />
                              </Button>
                            </Link>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
