import { useQuery, useMutation } from "@tanstack/react-query";
import { Link, useRoute } from "wouter";
import {
  Wallet,
  MessageSquare,
  Star,
  Clock,
  BadgeCheck,
  AlertCircle,
  TrendingUp,
  Plus,
  CreditCard,
  FileText,
  Eye,
  EyeOff,
  Loader2,
  Pause,
  Play,
  BarChart3,
  CheckCircle,
  Edit2,
  Save,
  Upload,
  X,
  Camera,
  Phone,
  MapPin,
  Building2,
  ShieldCheck,
  Image as ImageIcon,
  Crown,
  Zap,
} from "lucide-react";
import { Header } from "@/components/header";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { StarRating } from "@/components/star-rating";
import { ImageUpload } from "@/components/image-upload";
import { LocationPicker } from "@/components/location-picker";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  AreaChart,
  Area,
} from "recharts";
import { useState, useRef } from "react";
import type { Business, Wallet as WalletType, WalletTransaction, ServiceRequest, Category, Verification } from "@shared/schema";

interface DashboardData {
  business: Business & { viewCount?: number; isPaused?: boolean };
  wallet: WalletType;
  recentTransactions: WalletTransaction[];
  pendingRequests: ServiceRequest[];
  subscription: { plan: string; status: string; isTrial: boolean; currentPeriodEnd: string | null };
  stats: {
    totalRequests: number;
    completedRequests: number;
    totalRevenue: number;
  };
}

interface ChartData {
  weeklyLeads: { week: string; count: number }[];
  weeklyRevenue: { week: string; amount: number }[];
}

function formatWeekLabel(week: string): string {
  try {
    const date = new Date(week);
    return date.toLocaleDateString("es-MX", { day: "numeric", month: "short" });
  } catch {
    return week;
  }
}

const STATUS_LABELS: Record<string, string> = {
  pending: "Pendiente",
  in_progress: "En progreso",
  completed: "Completado",
  cancelled: "Cancelado",
};

const STATUS_VARIANTS: Record<string, "default" | "secondary" | "destructive" | "outline"> = {
  pending: "secondary",
  in_progress: "default",
  completed: "outline",
  cancelled: "destructive",
};

function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === "string") {
        resolve(reader.result);
      } else {
        reject(new Error("Failed to read file"));
      }
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

export default function DashboardPage() {
  const { toast } = useToast();
  const [, params] = useRoute("/dashboard/:section");
  const section = params?.section || "";

  const { data: profile } = useQuery<{ role: string }>({
    queryKey: ["/api/profile"],
  });

  const { data: dashboard, isLoading } = useQuery<DashboardData>({
    queryKey: ["/api/dashboard"],
  });

  const { data: chartData, isLoading: chartsLoading } = useQuery<ChartData>({
    queryKey: ["/api/dashboard/charts"],
    enabled: !!dashboard,
  });

  const { data: categories } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });

  const { data: verifications, isLoading: verificationsLoading } = useQuery<Verification[]>({
    queryKey: ["/api/business/verifications"],
    enabled: !!dashboard,
  });

  const defaultTab = section === "plan" ? "plan" : section === "verification" ? "verification" : section === "edit" ? "edit" : "overview";

  const updateStatusMutation = useMutation({
    mutationFn: async ({ id, status }: { id: string; status: string }) => {
      const res = await apiRequest("PATCH", `/api/requests/${id}/status`, { status });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/charts"] });
      toast({
        title: "Estado actualizado",
        description: "La solicitud ha sido actualizada correctamente",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message || "No se pudo actualizar el estado",
        variant: "destructive",
      });
    },
  });

  const toggleVisibilityMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("PATCH", "/api/business/visibility", {
        isVisible: !dashboard?.business.isVisible,
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
      toast({
        title: dashboard?.business.isVisible ? "Negocio oculto" : "Negocio visible",
        description: dashboard?.business.isVisible
          ? "Tu negocio ya no aparece en búsquedas"
          : "Tu negocio ahora aparece en búsquedas",
      });
    },
  });

  const rechargeMutation = useMutation({
    mutationFn: async (amount: number) => {
      const res = await apiRequest("POST", "/api/wallet/recharge", { amount });
      return res.json();
    },
    onSuccess: (data) => {
      if (data.url) {
        window.location.href = data.url;
      }
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message || "No se pudo procesar el pago",
        variant: "destructive",
      });
    },
  });

  const togglePauseMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("PATCH", "/api/business/pause");
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
      toast({
        title: data.isPaused ? "Negocio pausado" : "Negocio activo",
        description: data.isPaused
          ? "Tu negocio no recibirá nuevas solicitudes"
          : "Tu negocio está recibiendo solicitudes nuevamente",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message || "No se pudo cambiar el estado",
        variant: "destructive",
      });
    },
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Header userRole="business" />
        <main className="container px-4 py-6">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4 mb-6">
            {Array.from({ length: 4 }).map((_, i) => (
              <Skeleton key={i} className="h-32 rounded-lg" />
            ))}
          </div>
          <div className="grid gap-6 lg:grid-cols-2">
            <Skeleton className="h-64 rounded-lg" />
            <Skeleton className="h-64 rounded-lg" />
          </div>
        </main>
      </div>
    );
  }

  if (!dashboard) {
    return (
      <div className="min-h-screen bg-background">
        <Header userRole={profile?.role} />
        <main className="container px-4 py-12 text-center">
          <h1 className="text-2xl font-bold mb-2">No tienes un negocio registrado</h1>
          <p className="text-muted-foreground mb-6">
            Registra tu negocio para empezar a recibir clientes
          </p>
          <Link href="/register-business">
            <Button size="lg" data-testid="button-register">
              <Plus className="h-4 w-4 mr-2" />
              Registrar negocio
            </Button>
          </Link>
        </main>
      </div>
    );
  }

  const { business, wallet, recentTransactions, pendingRequests, stats } = dashboard;
  const balance = Number(wallet.balance);
  const isLowBalance = balance < 40;
  const isZeroBalance = balance <= 0;

  return (
    <div className="min-h-screen bg-background">
      <Header userRole="business" />

      <main className="container px-4 py-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
              <BarChart3 className="h-5 w-5 text-primary" />
            </div>
            <div>
              <h1 className="text-2xl font-bold tracking-tight">Dashboard</h1>
              <p className="text-sm text-muted-foreground">{business.name}</p>
            </div>
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            {business.isVerified ? (
              <Badge className="bg-primary/10 text-primary border-0">
                <BadgeCheck className="h-3 w-3 mr-1" />
                Verificado
              </Badge>
            ) : (
              <Badge variant="secondary">
                <Clock className="h-3 w-3 mr-1" />
                Pendiente de verificación
              </Badge>
            )}
            <Button
              variant="outline"
              size="sm"
              onClick={() => toggleVisibilityMutation.mutate()}
              disabled={toggleVisibilityMutation.isPending}
              data-testid="button-toggle-visibility"
            >
              {business.isVisible ? (
                <>
                  <Eye className="h-4 w-4 mr-1" />
                  Visible
                </>
              ) : (
                <>
                  <EyeOff className="h-4 w-4 mr-1" />
                  Oculto
                </>
              )}
            </Button>
            <Button
              variant={business.isPaused ? "default" : "outline"}
              size="sm"
              onClick={() => togglePauseMutation.mutate()}
              disabled={togglePauseMutation.isPending}
              data-testid="button-toggle-pause"
            >
              {togglePauseMutation.isPending ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : business.isPaused ? (
                <>
                  <Play className="h-4 w-4 mr-1" />
                  Activar
                </>
              ) : (
                <>
                  <Pause className="h-4 w-4 mr-1" />
                  Pausar
                </>
              )}
            </Button>
            <Badge variant="secondary" className="gap-1">
              <Eye className="h-3 w-3" />
              {business.viewCount || 0} vistas
            </Badge>
          </div>
        </div>

        {isZeroBalance && (
          <Card className="mb-6 border-destructive bg-destructive/5 overflow-visible">
            <CardContent className="p-4 flex items-center gap-4">
              <AlertCircle className="h-8 w-8 text-destructive flex-shrink-0" />
              <div className="flex-1">
                <h3 className="font-semibold text-destructive">Sin saldo disponible</h3>
                <p className="text-sm text-muted-foreground">
                  Tu negocio no está recibiendo solicitudes. Recarga tu saldo para continuar.
                </p>
              </div>
              <Button
                variant="destructive"
                onClick={() => rechargeMutation.mutate(200)}
                disabled={rechargeMutation.isPending}
                data-testid="button-recharge-urgent"
              >
                {rechargeMutation.isPending ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  "Recargar ahora"
                )}
              </Button>
            </CardContent>
          </Card>
        )}

        <Tabs defaultValue={defaultTab} className="space-y-8">
          <TabsList data-testid="dashboard-tabs" className="gap-1">
            <TabsTrigger value="overview" data-testid="tab-overview">
              <BarChart3 className="h-4 w-4 mr-1" />
              Resumen
            </TabsTrigger>
            <TabsTrigger value="edit" data-testid="tab-edit">
              <Edit2 className="h-4 w-4 mr-1" />
              Mi perfil
            </TabsTrigger>
            <TabsTrigger value="verification" data-testid="tab-verification">
              <ShieldCheck className="h-4 w-4 mr-1" />
              Verificación
            </TabsTrigger>
            <TabsTrigger value="plan" data-testid="tab-plan">
              <CreditCard className="h-4 w-4 mr-1" />
              Mi Plan
            </TabsTrigger>
          </TabsList>

          <TabsContent value="overview">
            <OverviewTab
              business={business}
              wallet={wallet}
              balance={balance}
              isLowBalance={isLowBalance}
              recentTransactions={recentTransactions}
              pendingRequests={pendingRequests}
              stats={stats}
              chartData={chartData}
              chartsLoading={chartsLoading}
              rechargeMutation={rechargeMutation}
              updateStatusMutation={updateStatusMutation}
            />
          </TabsContent>

          <TabsContent value="edit">
            <EditProfileTab
              business={business}
              categories={categories || []}
            />
          </TabsContent>

          <TabsContent value="verification">
            <VerificationTab
              business={business}
              verifications={verifications || []}
              verificationsLoading={verificationsLoading}
            />
          </TabsContent>

          <TabsContent value="plan">
            <PlanTab subscription={dashboard?.subscription} />
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}

function OverviewTab({
  business,
  wallet,
  balance,
  isLowBalance,
  recentTransactions,
  pendingRequests,
  stats,
  chartData,
  chartsLoading,
  rechargeMutation,
  updateStatusMutation,
}: {
  business: Business & { viewCount?: number; isPaused?: boolean };
  wallet: WalletType;
  balance: number;
  isLowBalance: boolean;
  recentTransactions: WalletTransaction[];
  pendingRequests: ServiceRequest[];
  stats: { totalRequests: number; completedRequests: number; totalRevenue: number };
  chartData?: ChartData;
  chartsLoading: boolean;
  rechargeMutation: any;
  updateStatusMutation: any;
}) {
  return (
    <>
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4 mb-8">
        <Card className={`overflow-visible ${isLowBalance ? "border-yellow-500" : ""}`}>
          <CardContent className="p-5">
            <div className="flex items-center justify-between gap-3">
              <div>
                <p className="text-sm text-muted-foreground">Saldo disponible</p>
                <p className="text-2xl font-bold">
                  ${balance.toFixed(2)}
                </p>
              </div>
              <div className={`h-10 w-10 rounded-lg flex items-center justify-center ${
                isLowBalance ? "bg-yellow-100 dark:bg-yellow-900/30" : "bg-green-100 dark:bg-green-900/20"
              }`}>
                <Wallet className={`h-5 w-5 ${isLowBalance ? "text-yellow-600" : "text-green-600 dark:text-green-400"}`} />
              </div>
            </div>
            {isLowBalance && balance > 0 && (
              <p className="text-xs text-yellow-600 mt-2 flex items-center gap-1">
                <AlertCircle className="h-3 w-3" />
                Saldo bajo
              </p>
            )}
          </CardContent>
        </Card>

        <Card className="overflow-visible">
          <CardContent className="p-5">
            <div className="flex items-center justify-between gap-3">
              <div>
                <p className="text-sm text-muted-foreground">Solicitudes pendientes</p>
                <p className="text-2xl font-bold">{pendingRequests.length}</p>
              </div>
              <div className="h-10 w-10 rounded-lg bg-blue-100 dark:bg-blue-900/20 flex items-center justify-center">
                <MessageSquare className="h-5 w-5 text-blue-600 dark:text-blue-400" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="overflow-visible">
          <CardContent className="p-5">
            <div className="flex items-center justify-between gap-3">
              <div>
                <p className="text-sm text-muted-foreground">Calificación</p>
                <div className="flex items-center gap-2">
                  <p className="text-2xl font-bold">{Number(business.rating).toFixed(1)}</p>
                  <StarRating rating={Number(business.rating)} size="sm" />
                </div>
              </div>
              <div className="h-10 w-10 rounded-lg bg-yellow-100 dark:bg-yellow-900/20 flex items-center justify-center">
                <Star className="h-5 w-5 text-yellow-600 dark:text-yellow-400" />
              </div>
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              {business.reviewCount} opiniones
            </p>
          </CardContent>
        </Card>

        <Card className="overflow-visible">
          <CardContent className="p-5">
            <div className="flex items-center justify-between gap-3">
              <div>
                <p className="text-sm text-muted-foreground">Servicios completados</p>
                <p className="text-2xl font-bold">{stats.completedRequests}</p>
              </div>
              <div className="h-10 w-10 rounded-lg bg-purple-100 dark:bg-purple-900/20 flex items-center justify-center">
                <TrendingUp className="h-5 w-5 text-purple-600 dark:text-purple-400" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card className="overflow-visible">
          <CardHeader className="flex flex-row items-center justify-between gap-2">
            <div>
              <CardTitle>Billetera</CardTitle>
              <CardDescription>Gestiona tu saldo y recargas</CardDescription>
            </div>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between gap-3 p-4 bg-muted/50 rounded-lg mb-4">
              <div>
                <p className="text-sm text-muted-foreground">Saldo actual</p>
                <p className="text-3xl font-bold">${balance.toFixed(2)} MXN</p>
              </div>
              <Button
                onClick={() => rechargeMutation.mutate(200)}
                disabled={rechargeMutation.isPending}
                data-testid="button-recharge"
              >
                {rechargeMutation.isPending ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <>
                    <CreditCard className="h-4 w-4 mr-2" />
                    Recargar
                  </>
                )}
              </Button>
            </div>

            <div className="space-y-2">
              <p className="text-sm font-medium">Movimientos recientes</p>
              {recentTransactions.length > 0 ? (
                <div className="space-y-2">
                  {recentTransactions.slice(0, 5).map((tx) => (
                    <div key={tx.id} className="flex items-center justify-between gap-2 text-sm py-2 border-b last:border-0">
                      <div>
                        <p className="font-medium">{tx.description}</p>
                        <p className="text-xs text-muted-foreground">
                          {new Date(tx.createdAt!).toLocaleDateString("es-MX")}
                        </p>
                      </div>
                      <span className={tx.type === "credit" ? "text-green-600" : "text-red-600"}>
                        {tx.type === "credit" ? "+" : "-"}${Math.abs(Number(tx.amount)).toFixed(2)}
                      </span>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-muted-foreground py-4 text-center">
                  Sin movimientos recientes
                </p>
              )}
            </div>
          </CardContent>
        </Card>

        <Card className="overflow-visible">
          <CardHeader className="flex flex-row items-center justify-between gap-2">
            <div>
              <CardTitle>Solicitudes pendientes</CardTitle>
              <CardDescription>Clientes esperando tu respuesta</CardDescription>
            </div>
          </CardHeader>
          <CardContent>
            {pendingRequests.length > 0 ? (
              <div className="space-y-3">
                {pendingRequests.slice(0, 5).map((request) => (
                  <div key={request.id} className="p-4 border rounded-lg bg-muted/30">
                    <Link href={`/requests/${request.id}`}>
                      <p className="font-medium line-clamp-1 hover-elevate cursor-pointer" data-testid={`text-request-desc-${request.id}`}>{request.description}</p>
                    </Link>
                    <div className="flex items-center justify-between gap-2 mt-2 flex-wrap">
                      <div className="flex items-center gap-2">
                        <span className="flex items-center gap-1 text-sm text-muted-foreground">
                          <Clock className="h-3 w-3" />
                          {new Date(request.createdAt!).toLocaleDateString("es-MX")}
                        </span>
                        <Badge variant={STATUS_VARIANTS[request.status] || "secondary"} data-testid={`badge-status-${request.id}`}>
                          {STATUS_LABELS[request.status] || request.status}
                        </Badge>
                      </div>
                      <div className="flex items-center gap-1">
                        {request.status === "pending" && (
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={(e) => {
                              e.stopPropagation();
                              updateStatusMutation.mutate({ id: request.id, status: "in_progress" });
                            }}
                            disabled={updateStatusMutation.isPending}
                            data-testid={`button-accept-${request.id}`}
                          >
                            {updateStatusMutation.isPending ? (
                              <Loader2 className="h-3 w-3 animate-spin" />
                            ) : (
                              <>
                                <CheckCircle className="h-3 w-3 mr-1" />
                                Aceptar
                              </>
                            )}
                          </Button>
                        )}
                        {(request.status === "pending" || request.status === "in_progress") && (
                          <Button
                            size="sm"
                            onClick={(e) => {
                              e.stopPropagation();
                              updateStatusMutation.mutate({ id: request.id, status: "completed" });
                            }}
                            disabled={updateStatusMutation.isPending}
                            data-testid={`button-complete-${request.id}`}
                          >
                            {updateStatusMutation.isPending ? (
                              <Loader2 className="h-3 w-3 animate-spin" />
                            ) : (
                              <>
                                <TrendingUp className="h-3 w-3 mr-1" />
                                Completar
                              </>
                            )}
                          </Button>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="py-8 text-center text-muted-foreground">
                <MessageSquare className="h-10 w-10 mx-auto mb-2 opacity-50" />
                <p>No tienes solicitudes pendientes</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <div className="mt-8">
        <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
          <BarChart3 className="h-5 w-5 text-muted-foreground" />
          Estadísticas
        </h2>
        <div className="grid gap-6 lg:grid-cols-2">
          <Card className="overflow-visible">
            <CardHeader>
              <CardTitle>Leads semanales</CardTitle>
              <CardDescription>Solicitudes recibidas por semana</CardDescription>
            </CardHeader>
            <CardContent>
              {chartsLoading ? (
                <Skeleton className="h-52 rounded-lg" />
              ) : chartData?.weeklyLeads && chartData.weeklyLeads.length > 0 ? (
                <ResponsiveContainer width="100%" height={240}>
                  <BarChart data={chartData.weeklyLeads} data-testid="chart-weekly-leads">
                    <XAxis
                      dataKey="week"
                      tickFormatter={formatWeekLabel}
                      tick={{ fontSize: 12 }}
                    />
                    <YAxis allowDecimals={false} tick={{ fontSize: 12 }} />
                    <Tooltip
                      labelFormatter={formatWeekLabel}
                      formatter={(value: number) => [value, "Leads"]}
                    />
                    <Bar dataKey="count" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              ) : (
                <div className="py-8 text-center text-muted-foreground">
                  <BarChart3 className="h-10 w-10 mx-auto mb-2 opacity-50" />
                  <p>Sin datos disponibles</p>
                </div>
              )}
            </CardContent>
          </Card>

          <Card className="overflow-visible">
            <CardHeader>
              <CardTitle>Ingresos semanales</CardTitle>
              <CardDescription>Movimientos por semana (MXN)</CardDescription>
            </CardHeader>
            <CardContent>
              {chartsLoading ? (
                <Skeleton className="h-52 rounded-lg" />
              ) : chartData?.weeklyRevenue && chartData.weeklyRevenue.length > 0 ? (
                <ResponsiveContainer width="100%" height={240}>
                  <AreaChart data={chartData.weeklyRevenue} data-testid="chart-weekly-revenue">
                    <XAxis
                      dataKey="week"
                      tickFormatter={formatWeekLabel}
                      tick={{ fontSize: 12 }}
                    />
                    <YAxis tick={{ fontSize: 12 }} />
                    <Tooltip
                      labelFormatter={formatWeekLabel}
                      formatter={(value: number) => [`$${Number(value).toFixed(2)}`, "Ingresos"]}
                    />
                    <Area
                      type="monotone"
                      dataKey="amount"
                      fill="hsl(var(--primary) / 0.2)"
                      stroke="hsl(var(--primary))"
                      strokeWidth={2}
                    />
                  </AreaChart>
                </ResponsiveContainer>
              ) : (
                <div className="py-8 text-center text-muted-foreground">
                  <TrendingUp className="h-10 w-10 mx-auto mb-2 opacity-50" />
                  <p>Sin datos disponibles</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </>
  );
}

function EditProfileTab({
  business,
  categories,
}: {
  business: Business;
  categories: Category[];
}) {
  const { toast } = useToast();
  const [isEditing, setIsEditing] = useState(false);
  const [editName, setEditName] = useState(business.name);
  const [editDescription, setEditDescription] = useState(business.description || "");
  const [editPhone, setEditPhone] = useState(business.phone || "");
  const [editWhatsapp, setEditWhatsapp] = useState(business.whatsapp || "");
  const [editAddress, setEditAddress] = useState(business.address || "");
  const [editCoverImage, setEditCoverImage] = useState(business.coverImage || "");
  const [editGallery, setEditGallery] = useState<string[]>(business.gallery || []);
  const [editServices, setEditServices] = useState((business.services || []).join(", "));
  const [editEstimatedPrices, setEditEstimatedPrices] = useState(business.estimatedPrices || "");
  const [editCategoryId, setEditCategoryId] = useState(business.categoryId);
  const [editLocation, setEditLocation] = useState<{ latitude: number; longitude: number; displayName: string } | null>(
    business.latitude && business.longitude
      ? { latitude: Number(business.latitude), longitude: Number(business.longitude), displayName: business.address || "" }
      : null
  );

  const updateBusinessMutation = useMutation({
    mutationFn: async (data: Record<string, any>) => {
      const res = await apiRequest("PATCH", "/api/business", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
      toast({
        title: "Perfil actualizado",
        description: "Los cambios en tu negocio han sido guardados.",
      });
      setIsEditing(false);
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message || "No se pudo actualizar el perfil",
        variant: "destructive",
      });
    },
  });

  const handleSave = () => {
    const servicesArray = editServices.split(",").map((s) => s.trim()).filter(Boolean);
    updateBusinessMutation.mutate({
      name: editName,
      description: editDescription,
      phone: editPhone,
      whatsapp: editWhatsapp,
      address: editLocation?.displayName || editAddress,
      coverImage: editCoverImage || null,
      gallery: editGallery,
      services: servicesArray,
      estimatedPrices: editEstimatedPrices,
      categoryId: editCategoryId,
      latitude: editLocation?.latitude?.toString(),
      longitude: editLocation?.longitude?.toString(),
    });
  };

  const handleCancel = () => {
    setEditName(business.name);
    setEditDescription(business.description || "");
    setEditPhone(business.phone || "");
    setEditWhatsapp(business.whatsapp || "");
    setEditAddress(business.address || "");
    setEditCoverImage(business.coverImage || "");
    setEditGallery(business.gallery || []);
    setEditServices((business.services || []).join(", "));
    setEditEstimatedPrices(business.estimatedPrices || "");
    setEditCategoryId(business.categoryId);
    setEditLocation(
      business.latitude && business.longitude
        ? { latitude: Number(business.latitude), longitude: Number(business.longitude), displayName: business.address || "" }
        : null
    );
    setIsEditing(false);
  };

  const categoryName = categories.find(c => c.id === business.categoryId)?.name;

  return (
    <div className="space-y-6 max-w-2xl">
      <div className="flex items-center justify-between gap-2 flex-wrap">
        <h2 className="text-lg font-semibold flex items-center gap-2">
          <Building2 className="h-5 w-5 text-muted-foreground" />
          Perfil de mi negocio
        </h2>
        {!isEditing ? (
          <Button onClick={() => setIsEditing(true)} data-testid="button-edit-business">
            <Edit2 className="h-4 w-4 mr-2" />
            Editar
          </Button>
        ) : (
          <div className="flex items-center gap-2">
            <Button variant="outline" onClick={handleCancel} data-testid="button-cancel-edit">
              <X className="h-4 w-4 mr-2" />
              Cancelar
            </Button>
            <Button
              onClick={handleSave}
              disabled={updateBusinessMutation.isPending}
              data-testid="button-save-business"
            >
              {updateBusinessMutation.isPending ? (
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              ) : (
                <Save className="h-4 w-4 mr-2" />
              )}
              Guardar
            </Button>
          </div>
        )}
      </div>

      <Card className="overflow-visible">
        <CardHeader>
          <CardTitle>Logo / Imagen de portada</CardTitle>
          <CardDescription>La imagen principal que identifica tu negocio</CardDescription>
        </CardHeader>
        <CardContent>
          {isEditing ? (
            <ImageUpload
              images={editCoverImage ? [editCoverImage] : []}
              onImagesChange={(images) => setEditCoverImage(images[0] || "")}
              maxImages={1}
            />
          ) : (
            <div>
              {business.coverImage ? (
                <div className="w-24 h-24 rounded-lg overflow-hidden border bg-muted">
                  <img src={business.coverImage} alt="Logo" className="w-full h-full object-cover" />
                </div>
              ) : (
                <div className="w-24 h-24 rounded-lg border border-dashed bg-muted/50 flex items-center justify-center">
                  <Camera className="h-8 w-8 text-muted-foreground" />
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      <Card className="overflow-visible">
        <CardHeader>
          <CardTitle>Galería de trabajos</CardTitle>
          <CardDescription>Muestra hasta 5 fotos de tus trabajos anteriores</CardDescription>
        </CardHeader>
        <CardContent>
          {isEditing ? (
            <ImageUpload
              images={editGallery}
              onImagesChange={setEditGallery}
              maxImages={5}
            />
          ) : (
            <div>
              {business.gallery && business.gallery.length > 0 ? (
                <div className="flex flex-wrap gap-2">
                  {business.gallery.map((img, index) => (
                    <div key={index} className="w-20 h-20 rounded-lg overflow-hidden border bg-muted">
                      <img src={img} alt={`Trabajo ${index + 1}`} className="w-full h-full object-cover" />
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-muted-foreground flex items-center gap-2">
                  <ImageIcon className="h-4 w-4" />
                  Sin fotos en la galería
                </p>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      <Card className="overflow-visible">
        <CardHeader>
          <CardTitle>Información del negocio</CardTitle>
          <CardDescription>Datos básicos de tu negocio</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label className="text-sm text-muted-foreground">Nombre del negocio</Label>
            {isEditing ? (
              <Input
                value={editName}
                onChange={(e) => setEditName(e.target.value)}
                data-testid="input-edit-name"
              />
            ) : (
              <p className="font-medium" data-testid="text-business-name">{business.name}</p>
            )}
          </div>

          <div>
            <Label className="text-sm text-muted-foreground">Categoría</Label>
            {isEditing ? (
              <Select value={editCategoryId} onValueChange={setEditCategoryId}>
                <SelectTrigger data-testid="select-edit-category">
                  <SelectValue placeholder="Selecciona categoría" />
                </SelectTrigger>
                <SelectContent>
                  {categories.map((cat) => (
                    <SelectItem key={cat.id} value={cat.id}>{cat.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            ) : (
              <p className="font-medium">{categoryName || "Sin categoría"}</p>
            )}
          </div>

          <div>
            <Label className="text-sm text-muted-foreground">Descripción</Label>
            {isEditing ? (
              <Textarea
                value={editDescription}
                onChange={(e) => setEditDescription(e.target.value)}
                className="min-h-24 resize-none"
                data-testid="textarea-edit-description"
              />
            ) : (
              <p className="text-sm" data-testid="text-business-description">{business.description || "Sin descripción"}</p>
            )}
          </div>

          <div>
            <Label className="text-sm text-muted-foreground">Servicios</Label>
            {isEditing ? (
              <div>
                <Input
                  value={editServices}
                  onChange={(e) => setEditServices(e.target.value)}
                  placeholder="Servicio 1, Servicio 2, Servicio 3"
                  data-testid="input-edit-services"
                />
                <p className="text-xs text-muted-foreground mt-1">Separa los servicios con comas</p>
              </div>
            ) : (
              <div className="flex flex-wrap gap-1">
                {business.services && business.services.length > 0 ? (
                  business.services.map((service, i) => (
                    <Badge key={i} variant="secondary">{service}</Badge>
                  ))
                ) : (
                  <p className="text-sm text-muted-foreground">Sin servicios</p>
                )}
              </div>
            )}
          </div>

          <div>
            <Label className="text-sm text-muted-foreground">Precios estimados</Label>
            {isEditing ? (
              <Textarea
                value={editEstimatedPrices}
                onChange={(e) => setEditEstimatedPrices(e.target.value)}
                className="min-h-20 resize-none"
                placeholder="Ej: Revisión: $200-$300, Reparación básica: $500-$800"
                data-testid="textarea-edit-prices"
              />
            ) : (
              <p className="text-sm">{business.estimatedPrices || "Sin precios estimados"}</p>
            )}
          </div>
        </CardContent>
      </Card>

      <Card className="overflow-visible">
        <CardHeader>
          <CardTitle>Contacto</CardTitle>
          <CardDescription>Información de contacto de tu negocio</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <Label className="text-sm text-muted-foreground">Teléfono</Label>
              {isEditing ? (
                <Input
                  value={editPhone}
                  onChange={(e) => setEditPhone(e.target.value)}
                  type="tel"
                  placeholder="55 1234 5678"
                  data-testid="input-edit-phone"
                />
              ) : (
                <p className="font-medium flex items-center gap-1">
                  <Phone className="h-4 w-4 text-muted-foreground" />
                  {business.phone || "Sin teléfono"}
                </p>
              )}
            </div>
            <div>
              <Label className="text-sm text-muted-foreground">WhatsApp</Label>
              {isEditing ? (
                <Input
                  value={editWhatsapp}
                  onChange={(e) => setEditWhatsapp(e.target.value)}
                  type="tel"
                  placeholder="55 1234 5678"
                  data-testid="input-edit-whatsapp"
                />
              ) : (
                <p className="font-medium">{business.whatsapp || "Sin WhatsApp"}</p>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="overflow-visible">
        <CardHeader>
          <CardTitle>Ubicación</CardTitle>
          <CardDescription>Ubicación de tu negocio en el mapa</CardDescription>
        </CardHeader>
        <CardContent>
          {isEditing ? (
            <LocationPicker
              value={editLocation || undefined}
              onChange={(loc) => {
                setEditLocation(loc);
                setEditAddress(loc.displayName);
              }}
            />
          ) : (
            <div>
              <p className="text-sm flex items-center gap-2">
                <MapPin className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                {business.address || "Sin dirección"}
              </p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function VerificationTab({
  business,
  verifications,
  verificationsLoading,
}: {
  business: Business;
  verifications: Verification[];
  verificationsLoading: boolean;
}) {
  const { toast } = useToast();
  const ineInputRef = useRef<HTMLInputElement>(null);
  const addressInputRef = useRef<HTMLInputElement>(null);
  const [isUploadingIne, setIsUploadingIne] = useState(false);
  const [isUploadingAddress, setIsUploadingAddress] = useState(false);

  const uploadVerificationMutation = useMutation({
    mutationFn: async ({ documentType, documentUrl }: { documentType: string; documentUrl: string }) => {
      const res = await apiRequest("POST", "/api/verifications", { documentType, documentUrl });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/business/verifications"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
      toast({
        title: "Documento enviado",
        description: "Tu documento ha sido enviado para revisión. Te notificaremos cuando sea revisado.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message || "No se pudo enviar el documento",
        variant: "destructive",
      });
    },
  });

  const handleFileUpload = async (file: File, documentType: string) => {
    if (!file.type.startsWith("image/") && file.type !== "application/pdf") {
      toast({
        title: "Formato no válido",
        description: "Solo se aceptan imágenes o PDF.",
        variant: "destructive",
      });
      return;
    }
    if (file.size > 10 * 1024 * 1024) {
      toast({
        title: "Archivo muy grande",
        description: "El archivo no debe superar los 10MB.",
        variant: "destructive",
      });
      return;
    }

    const setLoading = documentType === "ine" ? setIsUploadingIne : setIsUploadingAddress;
    setLoading(true);

    try {
      const base64 = await fileToBase64(file);
      uploadVerificationMutation.mutate({ documentType, documentUrl: base64 });
    } catch {
      toast({
        title: "Error",
        description: "No se pudo procesar el archivo.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const ineVerification = verifications.find(v => v.documentType === "ine");
  const addressVerification = verifications.find(v => v.documentType === "address_proof");

  if (business.isVerified) {
    return (
      <div className="max-w-2xl">
        <Card className="overflow-visible">
          <CardContent className="p-8 text-center">
            <div className="h-16 w-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
              <BadgeCheck className="h-8 w-8 text-primary" />
            </div>
            <h2 className="text-xl font-bold mb-2">Negocio verificado</h2>
            <p className="text-muted-foreground">
              Tu negocio ha sido verificado correctamente. El sello de verificación es visible en tu perfil público.
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="max-w-2xl space-y-6">
      <div>
        <h2 className="text-lg font-semibold flex items-center gap-2 mb-2">
          <ShieldCheck className="h-5 w-5 text-muted-foreground" />
          Verificación de negocio
        </h2>
        <p className="text-muted-foreground text-sm">
          Para obtener el sello de verificado, necesitas subir dos documentos: tu INE (identificación oficial) y un comprobante de domicilio. Un administrador revisará tus documentos.
        </p>
      </div>

      <Card className="overflow-visible">
        <CardHeader>
          <CardTitle className="flex items-center justify-between gap-2 flex-wrap">
            <span>1. INE (Identificación oficial)</span>
            {ineVerification && (
              <Badge variant={
                ineVerification.status === "approved" ? "default" :
                ineVerification.status === "rejected" ? "destructive" : "secondary"
              }>
                {ineVerification.status === "approved" ? "Aprobado" :
                 ineVerification.status === "rejected" ? "Rechazado" : "En revisión"}
              </Badge>
            )}
          </CardTitle>
          <CardDescription>
            Sube una foto clara de tu credencial de elector (INE/IFE) por ambos lados
          </CardDescription>
        </CardHeader>
        <CardContent>
          <input
            ref={ineInputRef}
            type="file"
            accept="image/*,application/pdf"
            className="hidden"
            onChange={(e) => {
              const file = e.target.files?.[0];
              if (file) handleFileUpload(file, "ine");
              if (ineInputRef.current) ineInputRef.current.value = "";
            }}
            data-testid="input-upload-ine"
          />

          {ineVerification ? (
            <div className="space-y-3">
              {ineVerification.documentUrl && (
                <div className="w-full max-w-xs rounded-lg overflow-hidden border bg-muted">
                  <img src={ineVerification.documentUrl} alt="INE" className="w-full h-auto object-contain max-h-48" />
                </div>
              )}
              {ineVerification.status === "rejected" && (
                <div className="space-y-2">
                  {ineVerification.reviewNote && (
                    <p className="text-sm text-destructive">Motivo: {ineVerification.reviewNote}</p>
                  )}
                  <Button
                    variant="outline"
                    onClick={() => ineInputRef.current?.click()}
                    disabled={isUploadingIne || uploadVerificationMutation.isPending}
                    data-testid="button-reupload-ine"
                  >
                    {isUploadingIne ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Upload className="h-4 w-4 mr-2" />}
                    Subir de nuevo
                  </Button>
                </div>
              )}
            </div>
          ) : (
            <Button
              variant="outline"
              className="w-full border-dashed py-8"
              onClick={() => ineInputRef.current?.click()}
              disabled={isUploadingIne || uploadVerificationMutation.isPending}
              data-testid="button-upload-ine"
            >
              {isUploadingIne ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Subiendo...
                </>
              ) : (
                <>
                  <Upload className="h-4 w-4 mr-2" />
                  Seleccionar archivo
                </>
              )}
            </Button>
          )}
        </CardContent>
      </Card>

      <Card className="overflow-visible">
        <CardHeader>
          <CardTitle className="flex items-center justify-between gap-2 flex-wrap">
            <span>2. Comprobante de domicilio</span>
            {addressVerification && (
              <Badge variant={
                addressVerification.status === "approved" ? "default" :
                addressVerification.status === "rejected" ? "destructive" : "secondary"
              }>
                {addressVerification.status === "approved" ? "Aprobado" :
                 addressVerification.status === "rejected" ? "Rechazado" : "En revisión"}
              </Badge>
            )}
          </CardTitle>
          <CardDescription>
            Recibo de luz, agua, teléfono o estado de cuenta (no mayor a 3 meses)
          </CardDescription>
        </CardHeader>
        <CardContent>
          <input
            ref={addressInputRef}
            type="file"
            accept="image/*,application/pdf"
            className="hidden"
            onChange={(e) => {
              const file = e.target.files?.[0];
              if (file) handleFileUpload(file, "address_proof");
              if (addressInputRef.current) addressInputRef.current.value = "";
            }}
            data-testid="input-upload-address-proof"
          />

          {addressVerification ? (
            <div className="space-y-3">
              {addressVerification.documentUrl && (
                <div className="w-full max-w-xs rounded-lg overflow-hidden border bg-muted">
                  <img src={addressVerification.documentUrl} alt="Comprobante" className="w-full h-auto object-contain max-h-48" />
                </div>
              )}
              {addressVerification.status === "rejected" && (
                <div className="space-y-2">
                  {addressVerification.reviewNote && (
                    <p className="text-sm text-destructive">Motivo: {addressVerification.reviewNote}</p>
                  )}
                  <Button
                    variant="outline"
                    onClick={() => addressInputRef.current?.click()}
                    disabled={isUploadingAddress || uploadVerificationMutation.isPending}
                    data-testid="button-reupload-address-proof"
                  >
                    {isUploadingAddress ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Upload className="h-4 w-4 mr-2" />}
                    Subir de nuevo
                  </Button>
                </div>
              )}
            </div>
          ) : (
            <Button
              variant="outline"
              className="w-full border-dashed py-8"
              onClick={() => addressInputRef.current?.click()}
              disabled={isUploadingAddress || uploadVerificationMutation.isPending}
              data-testid="button-upload-address-proof"
            >
              {isUploadingAddress ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Subiendo...
                </>
              ) : (
                <>
                  <Upload className="h-4 w-4 mr-2" />
                  Seleccionar archivo
                </>
              )}
            </Button>
          )}
        </CardContent>
      </Card>

      <Card className="overflow-visible bg-muted/30">
        <CardContent className="p-4">
          <p className="text-sm text-muted-foreground">
            <strong>¿Cómo funciona?</strong> Una vez que subas ambos documentos, un administrador los revisará.
            Si ambos son aprobados, tu negocio recibirá el sello de verificado que aumenta la confianza de los clientes.
            Tiempo estimado de revisión: 24-48 horas.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}

function PlanTab({ subscription }: { subscription?: { plan: string; status: string; isTrial: boolean; currentPeriodEnd: string | null } }) {
  const { toast } = useToast();
  const plan = subscription?.plan || "free";
  const status = subscription?.status || "active";

  const portalMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/subscription/portal");
      return res.json();
    },
    onSuccess: (data) => {
      if (data.url) window.location.href = data.url;
    },
    onError: () => {
      toast({ title: "Error", description: "No se pudo abrir el portal de facturación", variant: "destructive" });
    },
  });

  const planInfo: Record<string, { name: string; color: string; icon: typeof Crown; features: string[] }> = {
    free: {
      name: "Gratis",
      color: "text-muted-foreground",
      icon: Zap,
      features: ["Perfil básico", "Recibir solicitudes", "Chat con clientes"],
    },
    pro: {
      name: "Pro",
      color: "text-blue-600 dark:text-blue-400",
      icon: Star,
      features: ["Badge Pro", "Prioridad en resultados", "Estadísticas de visitas", "Soporte prioritario"],
    },
    premium: {
      name: "Premium",
      color: "text-amber-600 dark:text-amber-400",
      icon: Crown,
      features: ["Badge Premium dorado", "Máxima prioridad", "Estadísticas avanzadas", "Galería ilimitada", "Soporte VIP"],
    },
  };

  const currentPlan = planInfo[plan] || planInfo.free;
  const PlanIcon = currentPlan.icon;

  return (
    <div className="space-y-6">
      <Card className="overflow-visible">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <PlanIcon className={`h-5 w-5 ${currentPlan.color}`} />
            Plan {currentPlan.name}
          </CardTitle>
          <CardDescription>
            {subscription?.isTrial && "Período de prueba"}
            {status === "active" && !subscription?.isTrial && "Suscripción activa"}
            {status === "past_due" && "Pago pendiente"}
            {status === "canceled" && "Cancelado"}
            {!subscription && "Sin suscripción activa"}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {currentPlan.features.map((feature, i) => (
              <div key={i} className="flex items-center gap-2 text-sm">
                <CheckCircle className={`h-4 w-4 ${currentPlan.color}`} />
                <span>{feature}</span>
              </div>
            ))}
          </div>

          {subscription?.currentPeriodEnd && (
            <p className="text-sm text-muted-foreground">
              {subscription.isTrial ? "Prueba termina" : "Próxima renovación"}:{" "}
              {new Date(subscription.currentPeriodEnd).toLocaleDateString("es-MX", { day: "numeric", month: "long", year: "numeric" })}
            </p>
          )}

          <div className="flex gap-3 flex-wrap pt-2">
            {plan === "free" ? (
              <Link href="/pricing">
                <Button data-testid="button-upgrade-plan">
                  <TrendingUp className="h-4 w-4 mr-2" />
                  Mejorar plan
                </Button>
              </Link>
            ) : (
              <>
                <Button
                  variant="outline"
                  onClick={() => portalMutation.mutate()}
                  disabled={portalMutation.isPending}
                  data-testid="button-manage-subscription"
                >
                  <CreditCard className="h-4 w-4 mr-2" />
                  {portalMutation.isPending ? "Abriendo..." : "Gestionar suscripción"}
                </Button>
                <Link href="/pricing">
                  <Button variant="ghost" data-testid="button-change-plan">
                    Cambiar plan
                  </Button>
                </Link>
              </>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
