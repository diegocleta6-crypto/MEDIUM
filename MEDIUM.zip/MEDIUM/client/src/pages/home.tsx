import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Search, Clock, ArrowRight, MapPin, LayoutGrid, Briefcase, FileText } from "lucide-react";
import { Header } from "@/components/header";
import { BusinessCard } from "@/components/business-card";
import { CategoryCard } from "@/components/category-card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { useAuth } from "@/hooks/use-auth";
import { useState } from "react";
import { useLocation } from "wouter";
import type { Category, Business, ServiceRequest } from "@shared/schema";

function getStatusBadge(status: string) {
  switch (status) {
    case "completed":
      return (
        <Badge variant="default" className="bg-green-600 dark:bg-green-700 text-white border-green-600 dark:border-green-700 no-default-hover-elevate no-default-active-elevate">
          Completado
        </Badge>
      );
    case "accepted":
      return (
        <Badge variant="default" className="bg-blue-600 dark:bg-blue-700 text-white border-blue-600 dark:border-blue-700 no-default-hover-elevate no-default-active-elevate">
          Aceptado
        </Badge>
      );
    case "cancelled":
      return (
        <Badge variant="destructive" className="no-default-hover-elevate no-default-active-elevate">
          Cancelado
        </Badge>
      );
    default:
      return (
        <Badge variant="secondary" className="no-default-hover-elevate no-default-active-elevate">
          Pendiente
        </Badge>
      );
  }
}

export default function HomePage() {
  const { user } = useAuth();
  const [searchQuery, setSearchQuery] = useState("");
  const [, navigate] = useLocation();

  const { data: profile } = useQuery<{ role: string }>({
    queryKey: ["/api/profile"],
  });

  const { data: categories, isLoading: categoriesLoading } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });

  const { data: featuredBusinesses, isLoading: businessesLoading } = useQuery<(Business & { category?: Category })[]>({
    queryKey: ["/api/businesses", { featured: "true" }],
  });

  const { data: recentRequests } = useQuery<ServiceRequest[]>({
    queryKey: ["/api/requests/my"],
  });

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    navigate(`/search?q=${encodeURIComponent(searchQuery)}`);
  };

  return (
    <div className="min-h-screen bg-background">
      <Header userRole={profile?.role} />

      <main className="container px-4 py-8 space-y-10">
        <section>
          <Card className="overflow-visible border-0 bg-gradient-to-br from-primary/5 via-primary/3 to-transparent dark:from-primary/10 dark:via-primary/5 dark:to-transparent">
            <CardContent className="p-6 md:p-8">
              <div className="mb-6">
                <h1 className="text-2xl font-bold md:text-3xl" data-testid="text-greeting">
                  Bienvenido, {user?.firstName || "Usuario"}
                </h1>
                <p className="text-muted-foreground mt-2 text-base">
                  Encuentra al profesional ideal para lo que necesitas
                </p>
              </div>

              <form onSubmit={handleSearch} className="flex gap-3 max-w-xl">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    type="search"
                    placeholder="Buscar plomero, electricista, limpieza..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10"
                    data-testid="input-home-search"
                  />
                </div>
                <Button type="submit" data-testid="button-home-search">
                  <Search className="h-4 w-4 md:mr-2" />
                  <span className="hidden md:inline">Buscar</span>
                </Button>
              </form>
            </CardContent>
          </Card>
        </section>

        {recentRequests && recentRequests.length > 0 && (
          <section>
            <div className="flex items-center justify-between gap-2 mb-5">
              <div className="flex items-center gap-2">
                <FileText className="h-5 w-5 text-muted-foreground" />
                <h2 className="text-lg font-semibold">Mis solicitudes recientes</h2>
              </div>
              <Link href="/requests">
                <Button variant="ghost" size="sm" data-testid="button-view-all-requests">
                  Ver todas
                  <ArrowRight className="ml-1 h-4 w-4" />
                </Button>
              </Link>
            </div>
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {recentRequests.slice(0, 3).map((request) => (
                <Link key={request.id} href={`/requests/${request.id}`}>
                  <Card className="hover-elevate cursor-pointer overflow-visible">
                    <CardContent className="p-5">
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex-1 min-w-0">
                          <p className="font-medium truncate text-sm" data-testid={`text-request-desc-${request.id}`}>
                            {request.description}
                          </p>
                          <div className="flex items-center gap-2 mt-3 text-xs text-muted-foreground">
                            <Clock className="h-3.5 w-3.5" />
                            <span>
                              {new Date(request.createdAt!).toLocaleDateString("es-MX", {
                                day: "numeric",
                                month: "short",
                              })}
                            </span>
                          </div>
                        </div>
                        {getStatusBadge(request.status)}
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              ))}
            </div>
          </section>
        )}

        <section>
          <div className="flex items-center justify-between gap-2 mb-5">
            <div className="flex items-center gap-2">
              <LayoutGrid className="h-5 w-5 text-muted-foreground" />
              <h2 className="text-lg font-semibold">Categorias</h2>
            </div>
            <Link href="/search">
              <Button variant="ghost" size="sm" data-testid="button-view-all-categories">
                Ver todas
                <ArrowRight className="ml-1 h-4 w-4" />
              </Button>
            </Link>
          </div>

          {categoriesLoading ? (
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
              {Array.from({ length: 6 }).map((_, i) => (
                <Skeleton key={i} className="h-24 rounded-md" />
              ))}
            </div>
          ) : categories && categories.length > 0 ? (
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
              {categories.slice(0, 6).map((category) => (
                <CategoryCard key={category.id} category={category} />
              ))}
            </div>
          ) : (
            <Card className="overflow-visible">
              <CardContent className="py-16 text-center">
                <LayoutGrid className="h-14 w-14 text-muted-foreground/40 mx-auto mb-4" />
                <h3 className="font-medium text-lg mb-2">Sin categorias disponibles</h3>
                <p className="text-sm text-muted-foreground">
                  Las categorias se cargar&aacute;n pronto
                </p>
              </CardContent>
            </Card>
          )}
        </section>

        <section>
          <div className="flex items-center justify-between gap-2 mb-5">
            <div className="flex items-center gap-2">
              <Briefcase className="h-5 w-5 text-muted-foreground" />
              <h2 className="text-lg font-semibold">Negocios destacados</h2>
            </div>
            <Link href="/search">
              <Button variant="ghost" size="sm" data-testid="button-view-all-businesses">
                Ver todos
                <ArrowRight className="ml-1 h-4 w-4" />
              </Button>
            </Link>
          </div>

          {businessesLoading ? (
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {Array.from({ length: 6 }).map((_, i) => (
                <Skeleton key={i} className="h-40 rounded-md" />
              ))}
            </div>
          ) : featuredBusinesses && featuredBusinesses.length > 0 ? (
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {featuredBusinesses.slice(0, 6).map((business) => (
                <BusinessCard key={business.id} business={business} />
              ))}
            </div>
          ) : (
            <Card className="overflow-visible">
              <CardContent className="py-16 text-center">
                <MapPin className="h-14 w-14 text-muted-foreground/40 mx-auto mb-4" />
                <h3 className="font-medium text-lg mb-2">No hay negocios disponibles</h3>
                <p className="text-sm text-muted-foreground">
                  Pronto tendremos m&aacute;s profesionales en tu zona
                </p>
              </CardContent>
            </Card>
          )}
        </section>
      </main>
    </div>
  );
}
