import { Link } from "wouter";
import { Search, Shield, Star, Clock, MapPin, ArrowRight, BadgeCheck, Wrench, Zap, Sparkles, Paintbrush, Palette, Lock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { ThemeToggle } from "@/components/theme-toggle";
import { useState } from "react";
import { useLocation } from "wouter";

export default function LandingPage() {
  const [searchQuery, setSearchQuery] = useState("");
  const [, navigate] = useLocation();

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/search?q=${encodeURIComponent(searchQuery.trim())}`);
    } else {
      navigate("/search");
    }
  };

  const features = [
    {
      icon: Shield,
      title: "Profesionales Verificados",
      description: "Todos los negocios pasan por un proceso de verificación para garantizar calidad y confianza.",
    },
    {
      icon: Star,
      title: "Opiniones Reales",
      description: "Lee las experiencias de otros clientes y toma decisiones informadas.",
    },
    {
      icon: Clock,
      title: "Respuesta Rápida",
      description: "Conecta directamente con proveedores que responden en minutos.",
    },
    {
      icon: MapPin,
      title: "Servicios Locales",
      description: "Encuentra profesionales cerca de ti con geolocalización inteligente.",
    },
  ];

  const categories = [
    { name: "Plomería", icon: Wrench, count: 45 },
    { name: "Electricidad", icon: Zap, count: 38 },
    { name: "Limpieza", icon: Sparkles, count: 62 },
    { name: "Carpintería", icon: Paintbrush, count: 29 },
    { name: "Pintura", icon: Palette, count: 41 },
    { name: "Cerrajería", icon: Lock, count: 22 },
  ];

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between gap-4 px-4">
          <div className="flex items-center gap-2" data-testid="logo">
            <div className="h-8 w-8 rounded-lg bg-primary flex items-center justify-center">
              <span className="text-primary-foreground font-bold text-lg">M</span>
            </div>
            <span className="font-bold text-xl gradient-text">MEDIUM</span>
          </div>

          <nav className="hidden md:flex items-center gap-6">
            <Link href="/search">
              <span className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors cursor-pointer">
                Servicios
              </span>
            </Link>
            <Link href="/register-business">
              <span className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors cursor-pointer">
                Registrar negocio
              </span>
            </Link>
          </nav>

          <div className="flex items-center gap-3">
            <ThemeToggle />
            <a href="/api/login">
              <Button variant="outline" data-testid="button-login">
                Iniciar sesión
              </Button>
            </a>
            <a href="/api/login" className="hidden sm:block">
              <Button data-testid="button-get-started">
                Comenzar gratis
              </Button>
            </a>
          </div>
        </div>
      </header>

      <main>
        <section className="relative overflow-hidden py-24 md:py-36">
          <div className="absolute inset-0 bg-gradient-to-br from-primary/8 via-transparent to-chart-2/8" />
          <div className="absolute top-20 left-10 w-72 h-72 bg-primary/5 rounded-full blur-3xl animate-pulse" />
          <div className="absolute bottom-10 right-10 w-96 h-96 bg-chart-2/5 rounded-full blur-3xl animate-pulse" style={{ animationDelay: "2s" }} />
          <div
            className="absolute inset-0 opacity-[0.03]"
            style={{
              backgroundImage: "radial-gradient(circle at 1px 1px, currentColor 1px, transparent 0)",
              backgroundSize: "40px 40px",
            }}
          />
          <div className="container relative px-4">
            <div className="mx-auto max-w-3xl text-center">
              <div className="inline-flex items-center gap-2 rounded-full border bg-background/80 backdrop-blur px-4 py-1.5 text-sm text-muted-foreground mb-8">
                <BadgeCheck className="h-4 w-4 text-primary" />
                La plataforma #1 de servicios locales
              </div>

              <h1 className="text-4xl font-bold tracking-tight sm:text-5xl md:text-6xl lg:text-7xl">
                Encuentra profesionales de{" "}
                <span className="gradient-text">confianza</span>
              </h1>
              <p className="mt-6 text-lg text-muted-foreground md:text-xl max-w-2xl mx-auto leading-relaxed">
                Conectamos clientes con los mejores negocios de servicios locales verificados. 
                Plomería, electricidad, limpieza y más.
              </p>

              <form onSubmit={handleSearch} className="mt-12 max-w-2xl mx-auto">
                <div className="flex flex-col sm:flex-row gap-3 p-2 rounded-xl border bg-background/80 backdrop-blur shadow-lg">
                  <div className="relative flex-1">
                    <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                    <Input
                      type="search"
                      placeholder="¿Qué servicio necesitas?"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="pl-12 h-12 text-base border-0 shadow-none focus-visible:ring-0 bg-transparent"
                      data-testid="input-hero-search"
                    />
                  </div>
                  <Button type="submit" size="lg" className="h-12 px-8" data-testid="button-hero-search">
                    Buscar
                    <ArrowRight className="ml-2 h-5 w-5" />
                  </Button>
                </div>
              </form>

              <div className="mt-10 flex flex-wrap items-center justify-center gap-6 text-sm text-muted-foreground">
                <span className="flex items-center gap-1.5">
                  <BadgeCheck className="h-4 w-4 text-primary" />
                  Gratis para clientes
                </span>
                <span className="flex items-center gap-1.5">
                  <Shield className="h-4 w-4 text-primary" />
                  Profesionales verificados
                </span>
                <span className="flex items-center gap-1.5">
                  <Star className="h-4 w-4 text-primary" />
                  Opiniones reales
                </span>
              </div>
            </div>
          </div>
        </section>

        <section className="py-20 bg-card/50">
          <div className="container px-4">
            <div className="text-center mb-14">
              <h2 className="text-2xl font-bold md:text-3xl">Categorías populares</h2>
              <p className="mt-3 text-muted-foreground max-w-lg mx-auto">
                Explora los servicios más solicitados
              </p>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 max-w-5xl mx-auto">
              {categories.map((category) => (
                <Link key={category.name} href={`/search?q=${encodeURIComponent(category.name)}`}>
                  <Card className="hover-elevate active-elevate-2 cursor-pointer overflow-visible transition-all duration-200 group">
                    <CardContent className="p-5 text-center flex flex-col items-center">
                      <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center mb-3 transition-colors duration-200 group-hover:bg-primary/20">
                        <category.icon className="h-6 w-6 text-primary" />
                      </div>
                      <h3 className="font-medium text-sm">{category.name}</h3>
                      <p className="text-xs text-muted-foreground mt-1">
                        {category.count} negocios
                      </p>
                    </CardContent>
                  </Card>
                </Link>
              ))}
            </div>

            <div className="mt-10 text-center">
              <Link href="/search">
                <Button variant="outline" size="lg" data-testid="button-view-all-categories">
                  Ver todas las categorías
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
            </div>
          </div>
        </section>

        <section className="py-20">
          <div className="container px-4">
            <div className="text-center mb-14">
              <h2 className="text-2xl font-bold md:text-3xl">¿Por qué elegir MEDIUM?</h2>
              <p className="mt-3 text-muted-foreground max-w-lg mx-auto">
                La plataforma que conecta a clientes con los mejores profesionales
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-6xl mx-auto">
              {features.map((feature) => (
                <Card key={feature.title} className="overflow-visible">
                  <CardContent className="p-6">
                    <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center mb-5">
                      <feature.icon className="h-6 w-6 text-primary" />
                    </div>
                    <h3 className="font-semibold text-lg mb-2">{feature.title}</h3>
                    <p className="text-sm text-muted-foreground leading-relaxed">{feature.description}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        <section className="relative py-20 bg-primary text-primary-foreground overflow-hidden">
          <div
            className="absolute inset-0 opacity-10"
            style={{
              backgroundImage: "radial-gradient(circle at 2px 2px, currentColor 1px, transparent 0)",
              backgroundSize: "32px 32px",
            }}
          />
          <div className="absolute inset-0 bg-gradient-to-br from-transparent via-primary to-primary/80" />
          <div className="container relative px-4">
            <div className="max-w-2xl mx-auto text-center">
              <h2 className="text-2xl font-bold md:text-3xl">¿Tienes un negocio de servicios?</h2>
              <p className="mt-4 text-primary-foreground/80 text-lg leading-relaxed">
                Únete a MEDIUM y empieza a recibir clientes hoy. Proceso de registro rápido y sencillo.
              </p>
              <div className="mt-8 flex flex-col sm:flex-row gap-4 justify-center">
                <Link href="/register-business">
                  <Button 
                    size="lg" 
                    variant="secondary" 
                    className="w-full sm:w-auto"
                    data-testid="button-register-business"
                  >
                    Registrar mi negocio
                    <ArrowRight className="ml-2 h-5 w-5" />
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </section>
      </main>

      <footer className="border-t py-12">
        <div className="container px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <div className="h-7 w-7 rounded-md bg-primary flex items-center justify-center">
                  <span className="text-primary-foreground font-bold text-sm">M</span>
                </div>
                <span className="font-semibold text-lg">MEDIUM</span>
              </div>
              <p className="text-sm text-muted-foreground max-w-sm leading-relaxed">
                La plataforma que conecta clientes con profesionales de servicios locales verificados.
              </p>
            </div>

            <div className="flex flex-wrap gap-x-12 gap-y-4 md:justify-end">
              <div>
                <h4 className="font-semibold text-sm mb-3">Plataforma</h4>
                <ul className="space-y-2">
                  <li>
                    <Link href="/search">
                      <span className="text-sm text-muted-foreground hover:text-foreground transition-colors cursor-pointer">
                        Buscar servicios
                      </span>
                    </Link>
                  </li>
                  <li>
                    <Link href="/register-business">
                      <span className="text-sm text-muted-foreground hover:text-foreground transition-colors cursor-pointer">
                        Registrar negocio
                      </span>
                    </Link>
                  </li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold text-sm mb-3">Cuenta</h4>
                <ul className="space-y-2">
                  <li>
                    <a href="/api/login" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                      Iniciar sesión
                    </a>
                  </li>
                  <li>
                    <a href="/api/login" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                      Crear cuenta
                    </a>
                  </li>
                </ul>
              </div>
            </div>
          </div>

          <div className="mt-10 pt-6 border-t">
            <p className="text-sm text-muted-foreground text-center">
              © 2024 MEDIUM. Todos los derechos reservados.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
