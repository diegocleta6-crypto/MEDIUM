import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Clock, MessageSquare, ChevronRight, Inbox, CheckCircle } from "lucide-react";
import { Header } from "@/components/header";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import type { ServiceRequest, Business } from "@shared/schema";

interface RequestWithBusiness extends ServiceRequest {
  business?: Business;
}

export default function MyRequestsPage() {
  const { data: profile } = useQuery<{ role: string }>({
    queryKey: ["/api/profile"],
  });

  const { data: requests, isLoading } = useQuery<RequestWithBusiness[]>({
    queryKey: ["/api/requests/my"],
  });

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pending":
        return <Badge variant="secondary"><Clock className="h-3 w-3 mr-1" />Pendiente</Badge>;
      case "accepted":
        return <Badge variant="default"><MessageSquare className="h-3 w-3 mr-1" />Aceptado</Badge>;
      case "completed":
        return <Badge variant="default" className="bg-primary"><CheckCircle className="h-3 w-3 mr-1" />Completado</Badge>;
      case "cancelled":
        return <Badge variant="destructive">Cancelado</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Header userRole={profile?.role} />

      <main className="container px-4 py-8 animate-fade-in">
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
              <Clock className="h-5 w-5 text-primary" />
            </div>
            <h1 className="text-2xl font-bold tracking-tight">Mis solicitudes</h1>
          </div>
          <p className="text-muted-foreground ml-[52px]">
            Historial de servicios que has solicitado
          </p>
        </div>

        {isLoading ? (
          <div className="space-y-4">
            {Array.from({ length: 3 }).map((_, i) => (
              <Skeleton key={i} className="h-24 rounded-lg" />
            ))}
          </div>
        ) : requests && requests.length > 0 ? (
          <div className="space-y-4">
            {requests.map((request) => {
              const businessInitials = request.business?.name
                .split(" ")
                .map((n) => n[0])
                .join("")
                .toUpperCase()
                .slice(0, 2);

              return (
                <Link key={request.id} href={`/requests/${request.id}`}>
                  <Card className="hover-elevate cursor-pointer overflow-visible">
                    <CardContent className="p-4">
                      <div className="flex items-start gap-4">
                        <Avatar className="h-12 w-12 rounded-md flex-shrink-0">
                          <AvatarImage
                            src={request.business?.coverImage || ""}
                            alt={request.business?.name || ""}
                          />
                          <AvatarFallback className="rounded-md bg-primary/10 text-primary">
                            {businessInitials || "?"}
                          </AvatarFallback>
                        </Avatar>

                        <div className="flex-1 min-w-0">
                          <div className="flex items-start justify-between gap-2">
                            <div className="min-w-0">
                              <h3 className="font-medium truncate">
                                {request.business?.name || "Negocio"}
                              </h3>
                              <p className="text-sm text-muted-foreground line-clamp-2">
                                {request.description}
                              </p>
                            </div>
                            <div className="flex items-center gap-2 flex-shrink-0">
                              {getStatusBadge(request.status)}
                              <ChevronRight className="h-4 w-4 text-muted-foreground" />
                            </div>
                          </div>

                          <div className="flex items-center gap-4 mt-2 text-sm text-muted-foreground">
                            <span className="flex items-center gap-1">
                              <Clock className="h-3 w-3" />
                              {new Date(request.createdAt!).toLocaleDateString("es-MX", {
                                day: "numeric",
                                month: "short",
                                year: "numeric",
                              })}
                            </span>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              );
            })}
          </div>
        ) : (
          <Card className="overflow-visible">
            <CardContent className="py-16 text-center">
              <div className="mx-auto mb-5 h-16 w-16 rounded-full bg-muted/50 flex items-center justify-center">
                <Inbox className="h-8 w-8 text-muted-foreground/60" />
              </div>
              <h3 className="font-semibold text-lg mb-2">No tienes solicitudes</h3>
              <p className="text-muted-foreground mb-6">
                Busca un servicio y envía tu primera solicitud
              </p>
              <Link href="/search">
                <Button data-testid="button-search">Buscar servicios</Button>
              </Link>
            </CardContent>
          </Card>
        )}
      </main>
    </div>
  );
}
