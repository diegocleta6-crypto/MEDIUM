import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { SearchX, Home } from "lucide-react";
import { Link } from "wouter";

export default function NotFound() {
  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-background relative overflow-hidden">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,hsl(var(--primary)/0.08)_0%,transparent_70%)]" />

      <Card className="w-full max-w-md mx-4 overflow-visible relative z-10 animate-fade-in">
        <CardContent className="pt-10 pb-8 px-8 text-center">
          <div className="mx-auto mb-6 h-20 w-20 rounded-full bg-muted/50 flex items-center justify-center">
            <SearchX className="h-10 w-10 text-muted-foreground" />
          </div>

          <h1 className="text-3xl font-bold tracking-tight mb-2">404</h1>
          <p className="text-lg text-muted-foreground mb-1">
            Página no encontrada
          </p>
          <p className="text-sm text-muted-foreground mb-8">
            La página que buscas no existe o ha sido movida.
          </p>

          <Link href="/">
            <Button data-testid="button-go-home">
              <Home className="h-4 w-4 mr-2" />
              Volver al inicio
            </Button>
          </Link>
        </CardContent>
      </Card>
    </div>
  );
}
