import { Check, Crown, Star, Zap, ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/hooks/use-auth";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Link, useLocation } from "wouter";
import { Header } from "@/components/header";

const plans = [
  {
    id: "free",
    name: "Gratis",
    price: 0,
    description: "Ideal para empezar y probar la plataforma",
    icon: Zap,
    features: [
      "Perfil de negocio básico",
      "Recibir solicitudes de servicio",
      "Chat con clientes",
      "Hasta 5 fotos en galería",
    ],
    limitations: [
      "Sin badge destacado",
      "Posición estándar en resultados",
      "Sin estadísticas avanzadas",
    ],
    cta: "Plan Actual",
    popular: false,
    color: "border-border",
    badge: null,
  },
  {
    id: "pro",
    name: "Pro",
    price: 299,
    description: "Para negocios que buscan crecer y destacar",
    icon: Star,
    features: [
      "Todo lo del plan Gratis",
      "Badge Pro en tu perfil",
      "Prioridad en resultados de búsqueda",
      "Estadísticas de visitas",
      "Hasta 10 fotos en galería",
      "Soporte prioritario",
    ],
    limitations: [],
    cta: "Comenzar con Pro",
    popular: true,
    color: "border-blue-500",
    badge: "Más Popular",
  },
  {
    id: "premium",
    name: "Premium",
    price: 799,
    description: "Máxima visibilidad para negocios establecidos",
    icon: Crown,
    features: [
      "Todo lo del plan Pro",
      "Badge Premium destacado (dorado)",
      "Máxima prioridad en búsquedas",
      "Estadísticas avanzadas detalladas",
      "Galería ilimitada de fotos",
      "Perfil destacado en inicio",
      "Soporte VIP dedicado",
    ],
    limitations: [],
    cta: "Comenzar con Premium",
    popular: false,
    color: "border-amber-500",
    badge: "Máximo Poder",
  },
];

export default function PricingPage() {
  const { isAuthenticated } = useAuth();
  const { toast } = useToast();
  const [, navigate] = useLocation();

  const checkoutMutation = useMutation({
    mutationFn: async (plan: string) => {
      const res = await apiRequest("POST", "/api/subscription/checkout", { plan });
      return res.json();
    },
    onSuccess: (data) => {
      if (data.url) {
        window.location.href = data.url;
      }
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message.includes("No business")
          ? "Necesitas registrar un negocio primero"
          : "Error al procesar. Intenta de nuevo.",
        variant: "destructive",
      });
    },
  });

  const handleSelectPlan = (planId: string) => {
    if (planId === "free") return;
    if (!isAuthenticated) {
      navigate("/");
      return;
    }
    checkoutMutation.mutate(planId);
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <div className="max-w-6xl mx-auto px-4 py-12">
        <div className="mb-6">
          <Link href="/">
            <Button variant="ghost" size="sm" data-testid="link-back-home">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Volver
            </Button>
          </Link>
        </div>

        <div className="text-center mb-12">
          <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-4" data-testid="text-pricing-title">
            Planes para tu Negocio
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto" data-testid="text-pricing-subtitle">
            Elige el plan que mejor se adapte a tu negocio. Cambia o cancela en cualquier momento.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 lg:gap-8">
          {plans.map((plan) => (
            <Card
              key={plan.id}
              className={`relative flex flex-col ${plan.color} ${plan.popular ? "border-2 shadow-lg scale-[1.02]" : "border"}`}
              data-testid={`card-plan-${plan.id}`}
            >
              {plan.badge && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                  <Badge className={plan.id === "premium" ? "bg-amber-500 hover:bg-amber-600 text-white" : "bg-blue-500 hover:bg-blue-600 text-white"}>
                    {plan.badge}
                  </Badge>
                </div>
              )}

              <CardHeader className="text-center pb-4">
                <div className={`mx-auto mb-3 p-3 rounded-full ${plan.id === "premium" ? "bg-amber-100 dark:bg-amber-900/30" : plan.id === "pro" ? "bg-blue-100 dark:bg-blue-900/30" : "bg-muted"}`}>
                  <plan.icon className={`h-6 w-6 ${plan.id === "premium" ? "text-amber-600 dark:text-amber-400" : plan.id === "pro" ? "text-blue-600 dark:text-blue-400" : "text-muted-foreground"}`} />
                </div>
                <CardTitle className="text-xl">{plan.name}</CardTitle>
                <p className="text-sm text-muted-foreground">{plan.description}</p>
              </CardHeader>

              <CardContent className="flex-1 flex flex-col">
                <div className="text-center mb-6">
                  <div className="flex items-baseline justify-center gap-1">
                    <span className="text-4xl font-bold text-foreground" data-testid={`text-price-${plan.id}`}>
                      ${plan.price.toLocaleString()}
                    </span>
                    <span className="text-muted-foreground">{plan.price > 0 ? "MXN/mes" : ""}</span>
                  </div>
                </div>

                <ul className="space-y-3 flex-1 mb-6">
                  {plan.features.map((feature, i) => (
                    <li key={i} className="flex items-start gap-2 text-sm">
                      <Check className={`h-4 w-4 mt-0.5 shrink-0 ${plan.id === "premium" ? "text-amber-500" : plan.id === "pro" ? "text-blue-500" : "text-primary"}`} />
                      <span className="text-foreground">{feature}</span>
                    </li>
                  ))}
                  {plan.limitations.map((limitation, i) => (
                    <li key={`lim-${i}`} className="flex items-start gap-2 text-sm text-muted-foreground">
                      <span className="h-4 w-4 mt-0.5 shrink-0 text-center">-</span>
                      <span>{limitation}</span>
                    </li>
                  ))}
                </ul>

                <Button
                  className={`w-full ${plan.id === "premium" ? "bg-amber-500 hover:bg-amber-600 text-white" : plan.id === "pro" ? "bg-blue-500 hover:bg-blue-600 text-white" : ""}`}
                  variant={plan.id === "free" ? "outline" : "default"}
                  disabled={plan.id === "free" || checkoutMutation.isPending}
                  onClick={() => handleSelectPlan(plan.id)}
                  data-testid={`button-select-${plan.id}`}
                >
                  {checkoutMutation.isPending ? "Procesando..." : plan.cta}
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="mt-12 text-center text-sm text-muted-foreground">
          <p>Todos los planes incluyen acceso a la plataforma MEDIUM.</p>
          <p className="mt-1">Los precios están en Pesos Mexicanos (MXN) e incluyen IVA.</p>
        </div>
      </div>
    </div>
  );
}
