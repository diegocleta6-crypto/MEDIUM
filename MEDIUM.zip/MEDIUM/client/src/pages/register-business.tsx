import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation, Link } from "wouter";
import { ChevronLeft, Loader2, Building2, MapPin, Check, Image as ImageIcon } from "lucide-react";
import { Header } from "@/components/header";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage, FormDescription } from "@/components/ui/form";
import { ImageUpload } from "@/components/image-upload";
import { LocationPicker } from "@/components/location-picker";
import { useState } from "react";
import type { Category } from "@shared/schema";

const businessSchema = z.object({
  name: z.string().min(2, "El nombre debe tener al menos 2 caracteres"),
  categoryId: z.string().min(1, "Selecciona una categoría"),
  description: z.string().min(20, "La descripción debe tener al menos 20 caracteres"),
  phone: z.string().min(10, "Ingresa un teléfono válido"),
  whatsapp: z.string().optional(),
  address: z.string().min(5, "Ingresa una dirección válida"),
  services: z.string().min(3, "Ingresa al menos un servicio"),
  estimatedPrices: z.string().optional(),
});

type BusinessFormData = z.infer<typeof businessSchema>;

interface GeocodedLocation {
  latitude: number;
  longitude: number;
  displayName: string;
}

export default function RegisterBusinessPage() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading: authLoading } = useAuth();
  const [, navigate] = useLocation();
  const [coverImage, setCoverImage] = useState<string>("");
  const [gallery, setGallery] = useState<string[]>([]);
  const [geocodedLocation, setGeocodedLocation] = useState<GeocodedLocation | null>(null);

  const { data: categories } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });

  const { data: profile } = useQuery<{ role: string }>({
    queryKey: ["/api/profile"],
    enabled: isAuthenticated,
  });

  // Show loading while checking auth
  if (authLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="h-8 w-8 border-4 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  // Redirect to login if not authenticated
  if (!isAuthenticated) {
    window.location.href = "/api/login";
    return null;
  }

  // Redirect if user already has a business
  if (profile?.role === "business") {
    window.location.href = "/dashboard";
    return null;
  }

  const form = useForm<BusinessFormData>({
    resolver: zodResolver(businessSchema),
    defaultValues: {
      name: "",
      categoryId: "",
      description: "",
      phone: "",
      whatsapp: "",
      address: "",
      services: "",
      estimatedPrices: "",
    },
  });

  const handleLocationChange = (location: { latitude: number; longitude: number; displayName: string }) => {
    setGeocodedLocation(location);
    form.setValue("address", location.displayName);
  };

  const createBusinessMutation = useMutation({
    mutationFn: async (data: BusinessFormData) => {
      const servicesArray = data.services.split(",").map((s) => s.trim()).filter(Boolean);
      const res = await apiRequest("POST", "/api/businesses", {
        ...data,
        services: servicesArray,
        coverImage: coverImage || undefined,
        gallery: gallery.length > 0 ? gallery : undefined,
        latitude: geocodedLocation?.latitude,
        longitude: geocodedLocation?.longitude,
      });
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Negocio registrado",
        description: "Tu negocio ha sido creado exitosamente. Ahora puedes subir documentos para verificación.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/profile"] });
      navigate("/dashboard");
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message || "No se pudo registrar el negocio",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: BusinessFormData) => {
    if (!isAuthenticated) {
      window.location.href = "/api/login";
      return;
    }
    createBusinessMutation.mutate(data);
  };

  return (
    <div className="min-h-screen bg-background">
      <Header userRole={profile?.role} />

      <main className="container px-4 py-8 max-w-2xl animate-fade-in">
        <Link href="/">
          <Button variant="ghost" className="mb-4 -ml-2" data-testid="button-back">
            <ChevronLeft className="h-4 w-4 mr-1" />
            Volver
          </Button>
        </Link>

        <Card className="overflow-visible">
          <CardHeader>
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
                <Building2 className="h-5 w-5 text-primary" />
              </div>
              <div>
                <CardTitle className="tracking-tight">Registrar mi negocio</CardTitle>
                <CardDescription>
                  Completa la información para empezar a recibir clientes
                </CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Nombre del negocio</FormLabel>
                      <FormControl>
                        <Input
                          placeholder="Ej: Plomería García"
                          {...field}
                          data-testid="input-business-name"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="categoryId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Categoría</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger data-testid="select-category">
                            <SelectValue placeholder="Selecciona una categoría" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {categories?.map((category) => (
                            <SelectItem key={category.id} value={category.id}>
                              {category.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Descripción</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="Describe tu negocio, experiencia y los servicios que ofreces..."
                          className="min-h-24 resize-none"
                          {...field}
                          data-testid="textarea-description"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="services"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Servicios</FormLabel>
                      <FormControl>
                        <Input
                          placeholder="Ej: Reparación de fugas, Instalación, Destape de drenaje"
                          {...field}
                          data-testid="input-services"
                        />
                      </FormControl>
                      <FormDescription>Separa los servicios con comas</FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="grid gap-4 sm:grid-cols-2">
                  <FormField
                    control={form.control}
                    name="phone"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Teléfono</FormLabel>
                        <FormControl>
                          <Input
                            type="tel"
                            placeholder="55 1234 5678"
                            {...field}
                            data-testid="input-phone"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="whatsapp"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>WhatsApp (opcional)</FormLabel>
                        <FormControl>
                          <Input
                            type="tel"
                            placeholder="55 1234 5678"
                            {...field}
                            data-testid="input-whatsapp"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="address"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Ubicacion del negocio</FormLabel>
                      <FormControl>
                        <LocationPicker
                          value={geocodedLocation || undefined}
                          onChange={handleLocationChange}
                        />
                      </FormControl>
                      <input type="hidden" {...field} />
                      <FormDescription>
                        Usa tu GPS, busca la direccion o arrastra el marcador en el mapa
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="estimatedPrices"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Precios estimados (opcional)</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="Ej: Revisión: $200-$300, Reparación básica: $500-$800"
                          className="min-h-20 resize-none"
                          {...field}
                          data-testid="textarea-prices"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="space-y-6 pt-6 border-t">
                  <div>
                    <Label className="text-sm font-medium">Logo del negocio (opcional)</Label>
                    <p className="text-xs text-muted-foreground mb-3">
                      Una imagen cuadrada que identifique tu negocio
                    </p>
                    <ImageUpload
                      images={coverImage ? [coverImage] : []}
                      onImagesChange={(images) => setCoverImage(images[0] || "")}
                      maxImages={1}
                    />
                  </div>

                  <div>
                    <Label className="text-sm font-medium">Galería de trabajos (opcional)</Label>
                    <p className="text-xs text-muted-foreground mb-3">
                      Muestra hasta 5 imágenes de tus trabajos anteriores
                    </p>
                    <ImageUpload
                      images={gallery}
                      onImagesChange={setGallery}
                      maxImages={5}
                    />
                  </div>
                </div>

                <div className="pt-6 border-t">
                  <p className="text-sm text-muted-foreground mb-5">
                    Al registrar tu negocio, recibirás $100 MXN de saldo inicial para comenzar
                    a recibir solicitudes de clientes.
                  </p>

                  <Button
                    type="submit"
                    className="w-full"
                    size="lg"
                    disabled={createBusinessMutation.isPending}
                    data-testid="button-submit"
                  >
                    {createBusinessMutation.isPending ? (
                      <>
                        <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                        Registrando...
                      </>
                    ) : (
                      "Registrar negocio"
                    )}
                  </Button>
                </div>
              </form>
            </Form>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
