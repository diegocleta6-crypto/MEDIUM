import { useQuery, useMutation } from "@tanstack/react-query";
import { useRoute, Link } from "wouter";
import { ChevronLeft, Calendar, Clock, CheckCircle, XCircle, MessageSquare, Image as ImageIcon, Star } from "lucide-react";
import { Header } from "@/components/header";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Skeleton } from "@/components/ui/skeleton";
import { ChatMessages } from "@/components/chat-messages";
import { StarRating } from "@/components/star-rating";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useState } from "react";
import type { ServiceRequest, Business, User } from "@shared/schema";

interface RequestWithDetails extends ServiceRequest {
  business?: Business;
  client?: User;
  chatBlocked?: boolean;
  chatBlockedReason?: string;
}

export default function RequestDetailPage() {
  const [, params] = useRoute("/requests/:id");
  const requestId = params?.id;
  const { toast } = useToast();
  const { user } = useAuth();
  const [showReview, setShowReview] = useState(false);
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState("");

  const { data: profile } = useQuery<{ role: string }>({
    queryKey: ["/api/profile"],
  });

  const { data: request, isLoading } = useQuery<RequestWithDetails>({
    queryKey: ["/api/requests", requestId],
    enabled: !!requestId,
  });

  const updateStatusMutation = useMutation({
    mutationFn: async (status: string) => {
      const res = await apiRequest("PATCH", `/api/requests/${requestId}`, { status });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/requests", requestId] });
      toast({ title: "Estado actualizado", description: "La solicitud ha sido actualizada." });
    },
  });

  const submitReviewMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/reviews", {
        serviceRequestId: requestId,
        businessId: request?.businessId,
        rating,
        comment,
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/requests", requestId] });
      toast({ title: "Reseña enviada", description: "Gracias por tu opinión." });
      setShowReview(false);
    },
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Header userRole={profile?.role} />
        <main className="container px-4 py-6 max-w-4xl">
          <Skeleton className="h-10 w-32 mb-6" />
          <Skeleton className="h-48 rounded-lg mb-6" />
          <Skeleton className="h-96 rounded-lg" />
        </main>
      </div>
    );
  }

  if (!request) {
    return (
      <div className="min-h-screen bg-background">
        <Header userRole={profile?.role} />
        <main className="container px-4 py-16 text-center animate-fade-in">
          <div className="mx-auto mb-5 h-16 w-16 rounded-full bg-muted/50 flex items-center justify-center">
            <XCircle className="h-8 w-8 text-muted-foreground/60" />
          </div>
          <h1 className="text-2xl font-bold tracking-tight mb-3">Solicitud no encontrada</h1>
          <Link href="/my-requests">
            <Button>Ver mis solicitudes</Button>
          </Link>
        </main>
      </div>
    );
  }

  const business = request.business;
  const client = request.client;
  const isClient = request.clientId === user?.id;
  const isBusiness = business?.userId === user?.id;

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pending":
        return <Badge variant="secondary" data-testid="badge-status-pending"><Clock className="h-3 w-3 mr-1" />Pendiente</Badge>;
      case "accepted":
        return <Badge variant="default" data-testid="badge-status-accepted"><MessageSquare className="h-3 w-3 mr-1" />En proceso</Badge>;
      case "completed":
        return <Badge variant="default" className="bg-primary" data-testid="badge-status-completed"><CheckCircle className="h-3 w-3 mr-1" />Completado</Badge>;
      case "cancelled":
        return <Badge variant="destructive" data-testid="badge-status-cancelled"><XCircle className="h-3 w-3 mr-1" />Cancelado</Badge>;
      default:
        return <Badge variant="secondary" data-testid="badge-status">{status}</Badge>;
    }
  };

  const initials = (name: string) =>
    name.split(" ").map((n) => n[0]).join("").toUpperCase().slice(0, 2);

  return (
    <div className="min-h-screen bg-background">
      <Header userRole={profile?.role} />

      <main className="container px-4 py-8 max-w-4xl animate-fade-in">
        <Link href={isClient ? "/requests" : "/dashboard"}>
          <Button variant="ghost" className="mb-6 -ml-2" data-testid="button-back">
            <ChevronLeft className="h-4 w-4 mr-1" />
            {isClient ? "Mis solicitudes" : "Dashboard"}
          </Button>
        </Link>

        <div className="grid gap-6 lg:grid-cols-3">
          <div className="lg:col-span-1 space-y-4">
            <Card className="overflow-visible">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between gap-2 flex-wrap">
                  <CardTitle className="text-lg tracking-tight">Detalles</CardTitle>
                  {getStatusBadge(request.status)}
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                {business && (
                  <div className="flex items-center gap-3">
                    <Avatar className="h-10 w-10 rounded-md">
                      <AvatarImage src={business.coverImage || ""} />
                      <AvatarFallback className="rounded-md bg-primary/10 text-primary">
                        {initials(business.name)}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-medium text-sm">{business.name}</p>
                      <p className="text-xs text-muted-foreground">Negocio</p>
                    </div>
                  </div>
                )}

                {client && isBusiness && (
                  <div className="flex items-center gap-3">
                    <Avatar className="h-10 w-10">
                      <AvatarImage src={client.profileImageUrl || ""} />
                      <AvatarFallback>
                        {initials(client.firstName || "Cliente")}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-medium text-sm">{client.firstName} {client.lastName}</p>
                      <p className="text-xs text-muted-foreground">Cliente</p>
                    </div>
                  </div>
                )}

                <div className="pt-2 border-t">
                  <p className="text-sm font-medium mb-1">Descripción</p>
                  <p className="text-sm text-muted-foreground">{request.description}</p>
                </div>

                {request.desiredDate && (
                  <div className="flex items-center gap-2 text-sm">
                    <Calendar className="h-4 w-4 text-muted-foreground" />
                    <span>{new Date(request.desiredDate).toLocaleDateString("es-MX")}</span>
                  </div>
                )}

                {request.photos && request.photos.length > 0 && (
                  <div className="pt-2 border-t">
                    <p className="text-sm font-medium mb-2 flex items-center gap-1">
                      <ImageIcon className="h-4 w-4" />
                      Fotos adjuntas
                    </p>
                    <div className="flex flex-wrap gap-2">
                      {request.photos.map((photo, i) => (
                        <img
                          key={i}
                          src={photo}
                          alt={`Foto ${i + 1}`}
                          className="w-16 h-16 object-cover rounded-md border"
                          data-testid={`img-photo-${i}`}
                        />
                      ))}
                    </div>
                  </div>
                )}

                {isBusiness && request.status === "pending" && (
                  <div className="pt-2 border-t space-y-2">
                    <Button
                      className="w-full"
                      onClick={() => updateStatusMutation.mutate("accepted")}
                      disabled={updateStatusMutation.isPending}
                      data-testid="button-accept"
                    >
                      Aceptar solicitud
                    </Button>
                    <Button
                      variant="outline"
                      className="w-full"
                      onClick={() => updateStatusMutation.mutate("cancelled")}
                      disabled={updateStatusMutation.isPending}
                      data-testid="button-cancel"
                    >
                      Rechazar
                    </Button>
                  </div>
                )}

                {isBusiness && request.status === "accepted" && (
                  <div className="pt-2 border-t">
                    <Button
                      className="w-full"
                      onClick={() => updateStatusMutation.mutate("completed")}
                      disabled={updateStatusMutation.isPending}
                      data-testid="button-complete"
                    >
                      <CheckCircle className="h-4 w-4 mr-2" />
                      Marcar completado
                    </Button>
                  </div>
                )}

                {isClient && request.status === "completed" && !showReview && (
                  <div className="pt-2 border-t">
                    <Button
                      className="w-full"
                      variant="outline"
                      onClick={() => setShowReview(true)}
                      data-testid="button-show-review"
                    >
                      <Star className="h-4 w-4 mr-2" />
                      Dejar reseña
                    </Button>
                  </div>
                )}

                {showReview && (
                  <div className="pt-2 border-t space-y-3">
                    <p className="text-sm font-medium">Califica el servicio</p>
                    <div className="flex justify-center">
                      <StarRating
                        rating={rating}
                        size="lg"
                        interactive
                        onRate={setRating}
                      />
                    </div>
                    <Textarea
                      value={comment}
                      onChange={(e) => setComment(e.target.value)}
                      placeholder="Cuéntanos tu experiencia..."
                      className="resize-none"
                      data-testid="textarea-review"
                    />
                    <Button
                      className="w-full"
                      onClick={() => submitReviewMutation.mutate()}
                      disabled={submitReviewMutation.isPending}
                      data-testid="button-submit-review"
                    >
                      Enviar reseña
                    </Button>
                  </div>
                )}

                <p className="text-xs text-muted-foreground pt-2">
                  Creado: {new Date(request.createdAt!).toLocaleDateString("es-MX")}
                </p>
              </CardContent>
            </Card>
          </div>

          <div className="lg:col-span-2">
            <Card className="h-[500px] flex flex-col overflow-visible">
              <CardHeader className="pb-3 flex-shrink-0">
                <CardTitle className="text-lg tracking-tight flex items-center gap-2">
                  <MessageSquare className="h-5 w-5 text-primary" />
                  Mensajes
                </CardTitle>
              </CardHeader>
              <CardContent className="flex-1 p-0 overflow-hidden">
                <ChatMessages
                  serviceRequestId={requestId!}
                  otherPartyName={isClient ? (business?.name || "Negocio") : (client?.firstName || "Cliente")}
                  otherPartyImage={isClient ? business?.coverImage || undefined : client?.profileImageUrl || undefined}
                  isBlocked={request.chatBlocked}
                  blockedMessage={request.chatBlockedReason}
                />
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}
