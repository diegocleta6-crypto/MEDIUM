import { useQuery } from "@tanstack/react-query";
import { useLocation, useSearch } from "wouter";
import { Search, MapPin, Filter, SlidersHorizontal, X, Map, List, ChevronDown, ChevronRight, ShieldCheck, DollarSign, SearchX } from "lucide-react";
import { Header } from "@/components/header";
import { BusinessCard } from "@/components/business-card";
import { MapView } from "@/components/map-view";
import { GeolocationModal } from "@/components/geolocation-modal";
import { StarRating } from "@/components/star-rating";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import { useState, useEffect, useMemo } from "react";
import type { Category, Business } from "@shared/schema";

function AdvancedFilters({
  minRating,
  setMinRating,
  verifiedOnly,
  setVerifiedOnly,
  minPrice,
  setMinPrice,
  maxPrice,
  setMaxPrice,
  onApply,
}: {
  minRating: number;
  setMinRating: (v: number) => void;
  verifiedOnly: boolean;
  setVerifiedOnly: (v: boolean) => void;
  minPrice: string;
  setMinPrice: (v: string) => void;
  maxPrice: string;
  setMaxPrice: (v: string) => void;
  onApply: () => void;
}) {
  return (
    <div className="space-y-6">
      <div>
        <Label className="text-sm font-medium mb-2 block text-muted-foreground">Calificación mínima</Label>
        <StarRating
          rating={minRating}
          interactive
          onRate={(val) => setMinRating(val === minRating ? 0 : val)}
          size="md"
        />
        {minRating > 0 && (
          <p className="text-xs text-muted-foreground mt-1" data-testid="text-min-rating-value">
            {minRating}+ estrellas
          </p>
        )}
      </div>

      <div className="flex items-center justify-between gap-2">
        <Label htmlFor="verified-toggle" className="text-sm font-medium flex items-center gap-2 text-muted-foreground">
          <ShieldCheck className="h-4 w-4" />
          Solo verificados
        </Label>
        <Switch
          id="verified-toggle"
          checked={verifiedOnly}
          onCheckedChange={setVerifiedOnly}
          data-testid="switch-verified-only"
        />
      </div>

      <div>
        <Label className="text-sm font-medium mb-2 block flex items-center gap-2 text-muted-foreground">
          <DollarSign className="h-4 w-4" />
          Rango de precios (MXN)
        </Label>
        <div className="flex items-center gap-2">
          <Input
            type="number"
            placeholder="Mín"
            value={minPrice}
            onChange={(e) => setMinPrice(e.target.value)}
            className="flex-1"
            min={0}
            data-testid="input-min-price"
          />
          <span className="text-muted-foreground text-sm">—</span>
          <Input
            type="number"
            placeholder="Máx"
            value={maxPrice}
            onChange={(e) => setMaxPrice(e.target.value)}
            className="flex-1"
            min={0}
            data-testid="input-max-price"
          />
        </div>
      </div>

      <Button onClick={onApply} className="w-full" data-testid="button-apply-filters">
        Aplicar filtros
      </Button>
    </div>
  );
}

function CategorySidebar({
  categories,
  selectedCategory,
  onSelectCategory,
}: {
  categories: Category[];
  selectedCategory: string;
  onSelectCategory: (slug: string) => void;
}) {
  const [expandedParents, setExpandedParents] = useState<Set<string>>(new Set());

  const parentCategories = useMemo(
    () => categories.filter((c) => !c.parentId),
    [categories]
  );

  const getSubcategories = (parentId: string) =>
    categories.filter((c) => c.parentId === parentId);

  const toggleExpand = (parentId: string) => {
    setExpandedParents((prev) => {
      const next = new Set(prev);
      if (next.has(parentId)) {
        next.delete(parentId);
      } else {
        next.add(parentId);
      }
      return next;
    });
  };

  useEffect(() => {
    if (selectedCategory) {
      const selectedCat = categories.find((c) => c.slug === selectedCategory);
      if (selectedCat?.parentId) {
        setExpandedParents((prev) => {
          const next = new Set(prev);
          next.add(selectedCat.parentId!);
          return next;
        });
      }
    }
  }, [selectedCategory, categories]);

  return (
    <div className="space-y-1">
      <Button
        variant={selectedCategory === "" ? "secondary" : "ghost"}
        className="w-full justify-start"
        onClick={() => onSelectCategory("")}
        data-testid="filter-category-all"
      >
        Todas las categorías
      </Button>
      {parentCategories.map((parent) => {
        const subs = getSubcategories(parent.id);
        const isExpanded = expandedParents.has(parent.id);
        const isSelected = selectedCategory === parent.slug;

        return (
          <div key={parent.id}>
            <div className="flex items-center">
              <Button
                variant={isSelected ? "secondary" : "ghost"}
                className="flex-1 justify-start gap-2"
                onClick={() => {
                  if (subs.length > 0) {
                    toggleExpand(parent.id);
                  }
                  onSelectCategory(parent.slug);
                }}
                data-testid={`filter-category-${parent.slug}`}
              >
                {parent.icon && <span className="text-base">{parent.icon}</span>}
                <span className="truncate">{parent.name}</span>
                {subs.length > 0 && (
                  <span className="ml-auto">
                    {isExpanded ? (
                      <ChevronDown className="h-4 w-4" />
                    ) : (
                      <ChevronRight className="h-4 w-4" />
                    )}
                  </span>
                )}
              </Button>
            </div>
            {isExpanded && subs.length > 0 && (
              <div className="ml-4 space-y-1">
                {subs.map((sub) => (
                  <Button
                    key={sub.id}
                    variant={selectedCategory === sub.slug ? "secondary" : "ghost"}
                    className="w-full justify-start text-sm"
                    onClick={() => onSelectCategory(sub.slug)}
                    data-testid={`filter-category-${sub.slug}`}
                  >
                    {sub.name}
                  </Button>
                ))}
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}

export default function SearchPage() {
  const searchParams = useSearch();
  const params = new URLSearchParams(searchParams);
  const initialQuery = params.get("q") || "";
  const initialCategory = params.get("category") || "";

  const [searchQuery, setSearchQuery] = useState(initialQuery);
  const [selectedCategory, setSelectedCategory] = useState(initialCategory);
  const [sortBy, setSortBy] = useState("rating");
  const [viewMode, setViewMode] = useState<"list" | "map">("list");
  const [, navigate] = useLocation();
  const [userLocation, setUserLocation] = useState<{ latitude: number; longitude: number } | null>(() => {
    const stored = sessionStorage.getItem("user_coords");
    if (stored) {
      try {
        return JSON.parse(stored);
      } catch {
        return null;
      }
    }
    return null;
  });
  const [showLocationModal, setShowLocationModal] = useState(!sessionStorage.getItem("user_coords"));

  const [minRating, setMinRating] = useState(0);
  const [verifiedOnly, setVerifiedOnly] = useState(false);
  const [minPrice, setMinPrice] = useState("");
  const [maxPrice, setMaxPrice] = useState("");

  const [appliedMinRating, setAppliedMinRating] = useState(0);
  const [appliedVerifiedOnly, setAppliedVerifiedOnly] = useState(false);
  const [appliedMinPrice, setAppliedMinPrice] = useState("");
  const [appliedMaxPrice, setAppliedMaxPrice] = useState("");

  const applyFilters = () => {
    setAppliedMinRating(minRating);
    setAppliedVerifiedOnly(verifiedOnly);
    setAppliedMinPrice(minPrice);
    setAppliedMaxPrice(maxPrice);
  };

  const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number): number => {
    const R = 6371;
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
              Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
              Math.sin(dLon/2) * Math.sin(dLon/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    return R * c;
  };

  const { data: categories } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });

  const { data: businesses, isLoading } = useQuery<(Business & { category?: Category })[]>({
    queryKey: ["/api/businesses", {
      q: searchQuery || undefined,
      category: selectedCategory || undefined,
      sort: sortBy,
      minRating: appliedMinRating > 0 ? appliedMinRating : undefined,
      verifiedOnly: appliedVerifiedOnly || undefined,
      minPrice: appliedMinPrice ? Number(appliedMinPrice) : undefined,
      maxPrice: appliedMaxPrice ? Number(appliedMaxPrice) : undefined,
    }],
  });

  const { data: profile } = useQuery<{ role: string }>({
    queryKey: ["/api/profile"],
  });

  useEffect(() => {
    setSearchQuery(initialQuery);
    setSelectedCategory(initialCategory);
  }, [initialQuery, initialCategory]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    const newParams = new URLSearchParams();
    if (searchQuery) newParams.set("q", searchQuery);
    if (selectedCategory) newParams.set("category", selectedCategory);
    navigate(`/search?${newParams.toString()}`);
  };

  const handleSelectCategory = (slug: string) => {
    setSelectedCategory(slug);
    const newParams = new URLSearchParams();
    if (searchQuery) newParams.set("q", searchQuery);
    if (slug) newParams.set("category", slug);
    navigate(`/search?${newParams.toString()}`);
  };

  const clearFilters = () => {
    setSearchQuery("");
    setSelectedCategory("");
    setMinRating(0);
    setVerifiedOnly(false);
    setMinPrice("");
    setMaxPrice("");
    setAppliedMinRating(0);
    setAppliedVerifiedOnly(false);
    setAppliedMinPrice("");
    setAppliedMaxPrice("");
    navigate("/search");
  };

  const hasFilters = searchQuery || selectedCategory || appliedMinRating > 0 || appliedVerifiedOnly || appliedMinPrice || appliedMaxPrice;

  const sortedBusinesses = useMemo(() => {
    if (!businesses) return [];
    
    if (sortBy === "distance" && userLocation) {
      return [...businesses].sort((a, b) => {
        const distA = a.latitude && a.longitude 
          ? calculateDistance(userLocation.latitude, userLocation.longitude, Number(a.latitude), Number(a.longitude))
          : Infinity;
        const distB = b.latitude && b.longitude 
          ? calculateDistance(userLocation.latitude, userLocation.longitude, Number(b.latitude), Number(b.longitude))
          : Infinity;
        return distA - distB;
      });
    }
    
    return businesses;
  }, [businesses, sortBy, userLocation]);

  return (
    <div className="min-h-screen bg-background">
      <Header userRole={profile?.role} />

      <main className="container px-4 py-6">
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-1">
            <Search className="h-6 w-6 text-muted-foreground" />
            <h1 className="text-2xl font-bold tracking-tight">Buscar servicios</h1>
          </div>
          <p className="text-sm text-muted-foreground ml-9">
            Explora y encuentra profesionales verificados cerca de ti
          </p>
        </div>

        <GeolocationModal 
          open={showLocationModal} 
          onLocationObtained={(coords) => {
            setUserLocation(coords);
            setShowLocationModal(false);
          }} 
        />

        <div className="flex flex-col lg:flex-row gap-6">
          <aside className="hidden lg:block w-64 flex-shrink-0">
            <div className="sticky top-24 space-y-5">
              <div className="rounded-md border bg-card p-4">
                <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-3" data-testid="text-categories-title">Categorías</h3>
                {categories && (
                  <CategorySidebar
                    categories={categories}
                    selectedCategory={selectedCategory}
                    onSelectCategory={handleSelectCategory}
                  />
                )}
              </div>

              <div className="rounded-md border bg-card p-4">
                <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-3" data-testid="text-filters-title">Filtros avanzados</h3>
                <AdvancedFilters
                  minRating={minRating}
                  setMinRating={setMinRating}
                  verifiedOnly={verifiedOnly}
                  setVerifiedOnly={setVerifiedOnly}
                  minPrice={minPrice}
                  setMinPrice={setMinPrice}
                  maxPrice={maxPrice}
                  setMaxPrice={setMaxPrice}
                  onApply={applyFilters}
                />
              </div>
            </div>
          </aside>

          <div className="flex-1">
            <form onSubmit={handleSearch} className="flex gap-3 mb-6 p-3 rounded-md border bg-card lg:p-0 lg:border-0 lg:bg-transparent">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  type="search"
                  placeholder="Buscar por nombre, servicio..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                  data-testid="input-search-page"
                />
              </div>
              <Button type="submit" data-testid="button-search-submit">
                <Search className="h-4 w-4" />
              </Button>

              <Sheet>
                <SheetTrigger asChild>
                  <Button variant="outline" className="lg:hidden" data-testid="button-filters">
                    <Filter className="h-4 w-4" />
                  </Button>
                </SheetTrigger>
                <SheetContent side="right">
                  <SheetHeader>
                    <SheetTitle>Filtros</SheetTitle>
                  </SheetHeader>
                  <div className="mt-6 space-y-6">
                    <div>
                      <h4 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-3">Categoría</h4>
                      {categories && (
                        <CategorySidebar
                          categories={categories}
                          selectedCategory={selectedCategory}
                          onSelectCategory={handleSelectCategory}
                        />
                      )}
                    </div>

                    <Separator />

                    <div>
                      <h4 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-3">Filtros avanzados</h4>
                      <AdvancedFilters
                        minRating={minRating}
                        setMinRating={setMinRating}
                        verifiedOnly={verifiedOnly}
                        setVerifiedOnly={setVerifiedOnly}
                        minPrice={minPrice}
                        setMinPrice={setMinPrice}
                        maxPrice={maxPrice}
                        setMaxPrice={setMaxPrice}
                        onApply={applyFilters}
                      />
                    </div>
                  </div>
                </SheetContent>
              </Sheet>
            </form>

            <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-5 gap-3">
              <div className="flex items-center gap-2 flex-wrap">
                {hasFilters && (
                  <>
                    {searchQuery && (
                      <Badge variant="outline" className="gap-1 text-xs" data-testid="badge-filter-search">
                        Búsqueda: {searchQuery}
                        <button onClick={() => setSearchQuery("")} data-testid="button-remove-search">
                          <X className="h-3 w-3" />
                        </button>
                      </Badge>
                    )}
                    {selectedCategory && (
                      <Badge variant="outline" className="gap-1 text-xs" data-testid="badge-filter-category">
                        {categories?.find((c) => c.slug === selectedCategory)?.name}
                        <button onClick={() => handleSelectCategory("")} data-testid="button-remove-category">
                          <X className="h-3 w-3" />
                        </button>
                      </Badge>
                    )}
                    {appliedMinRating > 0 && (
                      <Badge variant="outline" className="gap-1 text-xs" data-testid="badge-filter-rating">
                        {appliedMinRating}+ estrellas
                        <button onClick={() => { setMinRating(0); setAppliedMinRating(0); }} data-testid="button-remove-rating">
                          <X className="h-3 w-3" />
                        </button>
                      </Badge>
                    )}
                    {appliedVerifiedOnly && (
                      <Badge variant="outline" className="gap-1 text-xs" data-testid="badge-filter-verified">
                        Verificados
                        <button onClick={() => { setVerifiedOnly(false); setAppliedVerifiedOnly(false); }} data-testid="button-remove-verified">
                          <X className="h-3 w-3" />
                        </button>
                      </Badge>
                    )}
                    {(appliedMinPrice || appliedMaxPrice) && (
                      <Badge variant="outline" className="gap-1 text-xs" data-testid="badge-filter-price">
                        {appliedMinPrice && appliedMaxPrice
                          ? `$${appliedMinPrice} - $${appliedMaxPrice}`
                          : appliedMinPrice
                          ? `Desde $${appliedMinPrice}`
                          : `Hasta $${appliedMaxPrice}`}
                        <button onClick={() => { setMinPrice(""); setMaxPrice(""); setAppliedMinPrice(""); setAppliedMaxPrice(""); }} data-testid="button-remove-price">
                          <X className="h-3 w-3" />
                        </button>
                      </Badge>
                    )}
                    <Button variant="ghost" size="sm" onClick={clearFilters} data-testid="button-clear-filters">
                      Limpiar filtros
                    </Button>
                  </>
                )}
              </div>

              <div className="flex items-center gap-2 flex-shrink-0">
                <div className="flex rounded-md border">
                  <Button
                    variant="ghost"
                    size="icon"
                    className={`rounded-r-none toggle-elevate ${viewMode === "list" ? "toggle-elevated" : ""}`}
                    onClick={() => setViewMode("list")}
                    data-testid="button-view-list"
                  >
                    <List className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    className={`rounded-l-none toggle-elevate ${viewMode === "map" ? "toggle-elevated" : ""}`}
                    onClick={() => setViewMode("map")}
                    data-testid="button-view-map"
                  >
                    <Map className="h-4 w-4" />
                  </Button>
                </div>
                <Select value={sortBy} onValueChange={setSortBy}>
                  <SelectTrigger className="w-40" data-testid="select-sort">
                    <SlidersHorizontal className="h-4 w-4 mr-2" />
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {userLocation && (
                      <SelectItem value="distance">Más cercanos</SelectItem>
                    )}
                    <SelectItem value="rating">Mejor valorados</SelectItem>
                    <SelectItem value="reviews">Más opiniones</SelectItem>
                    <SelectItem value="newest">Más recientes</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {viewMode === "map" ? (
              <div className="h-[60vh] min-h-[400px] rounded-lg overflow-hidden border">
                <MapView 
                  businesses={sortedBusinesses} 
                  className="w-full h-full"
                />
              </div>
            ) : isLoading ? (
              <div className="grid gap-4 md:grid-cols-2">
                {Array.from({ length: 6 }).map((_, i) => (
                  <Skeleton key={i} className="h-40 rounded-lg" />
                ))}
              </div>
            ) : sortedBusinesses.length > 0 ? (
              <div className="grid gap-4 md:grid-cols-2">
                {sortedBusinesses.map((business) => (
                  <BusinessCard key={business.id} business={business} />
                ))}
              </div>
            ) : (
              <div className="text-center py-16 px-4">
                <div className="inline-flex items-center justify-center rounded-full bg-muted p-4 mb-5">
                  <SearchX className="h-8 w-8 text-muted-foreground" />
                </div>
                <h3 className="font-semibold text-lg mb-2">No se encontraron resultados</h3>
                <p className="text-sm text-muted-foreground mb-2 max-w-md mx-auto">
                  No encontramos negocios que coincidan con tu búsqueda.
                </p>
                <p className="text-xs text-muted-foreground mb-6 max-w-md mx-auto">
                  Prueba ajustando los filtros, cambiando la categoría o usando otros términos.
                </p>
                {hasFilters && (
                  <Button variant="outline" onClick={clearFilters} data-testid="button-clear-empty">
                    Limpiar todos los filtros
                  </Button>
                )}
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}
