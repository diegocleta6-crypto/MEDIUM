import { useQuery, useMutation } from "@tanstack/react-query";
import { useRoute, useLocation, Link } from "wouter";
import { ChevronLeft, Calendar, Loader2 } from "lucide-react";
import { Header } from "@/components/header";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Skeleton } from "@/components/ui/skeleton";
import { StarRating } from "@/components/star-rating";
import { ImageUpload } from "@/components/image-upload";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import type { Business, Category } from "@shared/schema";
import { useState } from "react";

const requestSchema = z.object({
  description: z.string().min(10, "La descripción debe tener al menos 10 caracteres"),
  desiredDate: z.string().optional(),
});

type RequestFormData = z.infer<typeof requestSchema>;

export default function ServiceRequestPage() {
  const [, params] = useRoute("/request/:businessId");
  const businessId = params?.businessId;
  const { toast } = useToast();
  const { isAuthenticated } = useAuth();
  const [, navigate] = useLocation();
  const [photos, setPhotos] = useState<string[]>([]);

  const { data: business, isLoading } = useQuery<Business & { category?: Category }>({
    queryKey: [`/api/businesses/${businessId}`],
    enabled: !!businessId,
  });

  const { data: profile } = useQuery<{ role: string }>({
    queryKey: ["/api/profile"],
  });

  const form = useForm<RequestFormData>({
    resolver: zodResolver(requestSchema),
    defaultValues: {
      description: "",
      desiredDate: "",
    },
  });

  const createRequestMutation = useMutation({
    mutationFn: async (data: RequestFormData) => {
      const res = await apiRequest("POST", "/api/requests", {
        businessId,
        description: data.description,
        desiredDate: data.desiredDate ? new Date(data.desiredDate).toISOString() : null,
        photos: photos.length > 0 ? photos : undefined,
      });
      return res.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Solicitud enviada",
        description: "El negocio ha recibido tu solicitud y te contactará pronto.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/requests"] });
      navigate(`/requests/${data.id}`);
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message || "No se pudo enviar la solicitud",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: RequestFormData) => {
    if (!isAuthenticated) {
      window.location.href = "/api/login";
      return;
    }
    createRequestMutation.mutate(data);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Header userRole={profile?.role} />
        <main className="container px-4 py-6 max-w-2xl">
          <Skeleton className="h-10 w-32 mb-6" />
          <Skeleton className="h-24 rounded-lg mb-6" />
          <Skeleton className="h-64 rounded-lg" />
        </main>
      </div>
    );
  }

  if (!business) {
    return (
      <div className="min-h-screen bg-background">
        <Header userRole={profile?.role} />
        <main className="container px-4 py-12 text-center">
          <h1 className="text-2xl font-bold mb-2">Negocio no encontrado</h1>
          <Link href="/search">
            <Button>Buscar negocios</Button>
          </Link>
        </main>
      </div>
    );
  }

  const initials = business.name
    .split(" ")
    .map((n) => n[0])
    .join("")
    .toUpperCase()
    .slice(0, 2);

  return (
    <div className="min-h-screen bg-background">
      <Header userRole={profile?.role} />

      <main className="container px-4 py-6 max-w-2xl">
        <Link href={`/business/${business.slug}`}>
          <Button variant="ghost" className="mb-4 -ml-2" data-testid="button-back">
            <ChevronLeft className="h-4 w-4 mr-1" />
            Volver al perfil
          </Button>
        </Link>

        <Card className="mb-6 overflow-visible">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <Avatar className="h-12 w-12 rounded-md">
                <AvatarImage src={business.coverImage || ""} alt={business.name} />
                <AvatarFallback className="rounded-md bg-primary/10 text-primary font-semibold">
                  {initials}
                </AvatarFallback>
              </Avatar>
              <div>
                <h2 className="font-semibold">{business.name}</h2>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <span>{business.category?.name}</span>
                  <span>•</span>
                  <StarRating rating={Number(business.rating) || 0} size="sm" />
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="overflow-visible">
          <CardHeader>
            <CardTitle>Solicitar servicio</CardTitle>
            <CardDescription>
              Describe lo que necesitas y el negocio te contactará con una cotización.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <FormField
                  control={form.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>¿Qué servicio necesitas?</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="Describe detalladamente el servicio que necesitas, incluyendo la ubicación y cualquier detalle relevante..."
                          className="min-h-32 resize-none"
                          {...field}
                          data-testid="textarea-description"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="desiredDate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Fecha deseada (opcional)</FormLabel>
                      <FormControl>
                        <div className="relative">
                          <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                          <Input
                            type="date"
                            className="pl-10"
                            {...field}
                            data-testid="input-date"
                          />
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div>
                  <FormLabel>Fotos del problema (opcional)</FormLabel>
                  <p className="text-sm text-muted-foreground mb-2">
                    Agrega fotos para ayudar al negocio a entender mejor tu solicitud.
                  </p>
                  <ImageUpload
                    images={photos}
                    onImagesChange={setPhotos}
                    maxImages={5}
                    disabled={createRequestMutation.isPending}
                  />
                </div>

                <div className="pt-4 border-t">
                  <p className="text-sm text-muted-foreground mb-4">
                    Al enviar esta solicitud, el negocio recibirá tu información de contacto 
                    y podrá comunicarse contigo directamente.
                  </p>

                  <Button
                    type="submit"
                    className="w-full"
                    size="lg"
                    disabled={createRequestMutation.isPending}
                    data-testid="button-submit-request"
                  >
                    {createRequestMutation.isPending ? (
                      <>
                        <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                        Enviando...
                      </>
                    ) : (
                      "Enviar solicitud"
                    )}
                  </Button>
                </div>
              </form>
            </Form>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
