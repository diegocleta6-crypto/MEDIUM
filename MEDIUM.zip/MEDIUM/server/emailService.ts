import { Resend } from 'resend';

let connectionSettings: any;

async function getCredentials() {
  const hostname = process.env.REPLIT_CONNECTORS_HOSTNAME;
  const xReplitToken = process.env.REPL_IDENTITY 
    ? 'repl ' + process.env.REPL_IDENTITY 
    : process.env.WEB_REPL_RENEWAL 
    ? 'depl ' + process.env.WEB_REPL_RENEWAL 
    : null;

  if (!xReplitToken) {
    throw new Error('X_REPLIT_TOKEN not found for repl/depl');
  }

  connectionSettings = await fetch(
    hostname + '/api/v2/connection?include_secrets=true&connector_names=resend',
    {
      headers: {
        'Accept': 'application/json',
        'X_REPLIT_TOKEN': xReplitToken
      }
    }
  ).then(res => res.json()).then(data => data.items?.[0]);

  if (!connectionSettings || (!connectionSettings.settings.api_key)) {
    throw new Error('Resend not connected');
  }
  return {
    apiKey: connectionSettings.settings.api_key, 
    fromEmail: connectionSettings.settings.from_email || 'MEDIUM <no-reply@mediumapp.mx>'
  };
}

export async function getUncachableResendClient() {
  const { apiKey, fromEmail } = await getCredentials();
  return {
    client: new Resend(apiKey),
    fromEmail
  };
}

export interface EmailOptions {
  to: string;
  subject: string;
  html: string;
  text?: string;
}

export async function sendEmail(options: EmailOptions): Promise<boolean> {
  try {
    const { client, fromEmail } = await getUncachableResendClient();
    
    await client.emails.send({
      from: fromEmail,
      to: options.to,
      subject: options.subject,
      html: options.html,
      text: options.text,
    });
    
    console.log(`Email sent to ${options.to}: ${options.subject}`);
    return true;
  } catch (error) {
    console.error('Failed to send email:', error);
    return false;
  }
}

export async function sendNewRequestEmail(
  businessEmail: string, 
  businessName: string, 
  clientDescription: string
): Promise<void> {
  await sendEmail({
    to: businessEmail,
    subject: `Nueva solicitud de servicio - MEDIUM`,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background-color: #2a9d8f; padding: 20px; text-align: center;">
          <h1 style="color: white; margin: 0;">MEDIUM</h1>
        </div>
        <div style="padding: 20px; background-color: #f9f9f9;">
          <h2 style="color: #333;">¡Tienes una nueva solicitud!</h2>
          <p style="color: #666;">Hola ${businessName},</p>
          <p style="color: #666;">Un cliente ha enviado una solicitud de servicio:</p>
          <div style="background-color: white; padding: 15px; border-radius: 8px; margin: 15px 0;">
            <p style="color: #333; margin: 0;">"${clientDescription.substring(0, 200)}${clientDescription.length > 200 ? '...' : ''}"</p>
          </div>
          <p style="color: #666;">Se ha descontado $20 MXN de tu billetera por este lead.</p>
          <a href="https://mediumapp.mx/dashboard" style="display: inline-block; background-color: #2a9d8f; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; margin-top: 15px;">Ver solicitud</a>
        </div>
        <div style="padding: 15px; text-align: center; color: #999; font-size: 12px;">
          <p>MEDIUM - Servicios Locales Verificados</p>
        </div>
      </div>
    `,
    text: `Nueva solicitud de servicio\n\nHola ${businessName},\n\nUn cliente ha enviado una solicitud:\n"${clientDescription}"\n\nSe ha descontado $20 MXN de tu billetera.\n\nVisita tu dashboard para ver los detalles.`
  });
}

export async function sendVerificationApprovedEmail(
  businessEmail: string,
  businessName: string
): Promise<void> {
  await sendEmail({
    to: businessEmail,
    subject: `¡Tu negocio ha sido verificado! - MEDIUM`,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background-color: #2a9d8f; padding: 20px; text-align: center;">
          <h1 style="color: white; margin: 0;">MEDIUM</h1>
        </div>
        <div style="padding: 20px; background-color: #f9f9f9;">
          <h2 style="color: #333;">¡Felicidades! Tu negocio ha sido verificado</h2>
          <p style="color: #666;">Hola ${businessName},</p>
          <p style="color: #666;">Tu documentación ha sido revisada y aprobada. Ahora tu perfil muestra el sello de verificación, lo que aumentará la confianza de los clientes.</p>
          <div style="background-color: #d1fae5; padding: 15px; border-radius: 8px; margin: 15px 0; text-align: center;">
            <span style="color: #065f46; font-weight: bold;">Negocio Verificado</span>
          </div>
          <a href="https://mediumapp.mx/dashboard" style="display: inline-block; background-color: #2a9d8f; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; margin-top: 15px;">Ver mi perfil</a>
        </div>
        <div style="padding: 15px; text-align: center; color: #999; font-size: 12px;">
          <p>MEDIUM - Servicios Locales Verificados</p>
        </div>
      </div>
    `,
    text: `¡Felicidades! Tu negocio ha sido verificado\n\nHola ${businessName},\n\nTu documentación ha sido revisada y aprobada. Ahora tu perfil muestra el sello de verificación.`
  });
}

export async function sendLowBalanceEmail(
  businessEmail: string,
  businessName: string,
  currentBalance: number
): Promise<void> {
  await sendEmail({
    to: businessEmail,
    subject: `Saldo bajo en tu billetera - MEDIUM`,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background-color: #2a9d8f; padding: 20px; text-align: center;">
          <h1 style="color: white; margin: 0;">MEDIUM</h1>
        </div>
        <div style="padding: 20px; background-color: #f9f9f9;">
          <h2 style="color: #333;">Tu saldo está bajo</h2>
          <p style="color: #666;">Hola ${businessName},</p>
          <p style="color: #666;">Tu saldo actual es de <strong>$${currentBalance.toFixed(2)} MXN</strong>.</p>
          ${currentBalance <= 0 
            ? `<div style="background-color: #fef2f2; padding: 15px; border-radius: 8px; margin: 15px 0;">
                <p style="color: #dc2626; margin: 0;"><strong>¡Importante!</strong> Tu negocio está oculto en las búsquedas porque tu saldo llegó a $0. Recarga para volver a aparecer.</p>
              </div>`
            : `<p style="color: #666;">Cuando tu saldo llegue a $0, tu negocio dejará de aparecer en las búsquedas.</p>`
          }
          <a href="https://mediumapp.mx/dashboard" style="display: inline-block; background-color: #2a9d8f; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; margin-top: 15px;">Recargar saldo</a>
        </div>
        <div style="padding: 15px; text-align: center; color: #999; font-size: 12px;">
          <p>MEDIUM - Servicios Locales Verificados</p>
        </div>
      </div>
    `,
    text: `Saldo bajo en tu billetera\n\nHola ${businessName},\n\nTu saldo actual es de $${currentBalance.toFixed(2)} MXN.\n\nRecarga tu saldo para seguir recibiendo solicitudes.`
  });
}

export async function sendRequestAcceptedEmail(
  clientEmail: string,
  clientName: string,
  businessName: string,
  requestId: string
): Promise<void> {
  await sendEmail({
    to: clientEmail,
    subject: `¡${businessName} ha aceptado tu solicitud! - MEDIUM`,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background-color: #2a9d8f; padding: 20px; text-align: center;">
          <h1 style="color: white; margin: 0;">MEDIUM</h1>
        </div>
        <div style="padding: 20px; background-color: #f9f9f9;">
          <h2 style="color: #333;">¡Tu solicitud ha sido aceptada!</h2>
          <p style="color: #666;">Hola ${clientName},</p>
          <p style="color: #666;">Buenas noticias: <strong>${businessName}</strong> ha aceptado tu solicitud de servicio.</p>
          <div style="background-color: #d1fae5; padding: 15px; border-radius: 8px; margin: 15px 0; text-align: center;">
            <span style="color: #065f46; font-weight: bold;">Solicitud Aceptada</span>
          </div>
          <p style="color: #666;">El negocio se pondrá en contacto contigo para coordinar los detalles del servicio. Puedes revisar y enviar mensajes desde tu perfil.</p>
          <a href="https://mediumapp.mx/requests/${requestId}" style="display: inline-block; background-color: #2a9d8f; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; margin-top: 15px;">Ver solicitud</a>
        </div>
        <div style="padding: 15px; text-align: center; color: #999; font-size: 12px;">
          <p>MEDIUM - Servicios Locales Verificados</p>
        </div>
      </div>
    `,
    text: `¡Tu solicitud ha sido aceptada!\n\nHola ${clientName},\n\n${businessName} ha aceptado tu solicitud de servicio.\n\nVisita tu perfil para ver los detalles y continuar la conversación.`
  });
}

export async function sendServiceCompletedEmail(
  clientEmail: string,
  clientName: string,
  businessName: string,
  businessSlug: string
): Promise<void> {
  await sendEmail({
    to: clientEmail,
    subject: `¡Servicio completado! Deja tu reseña - MEDIUM`,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background-color: #2a9d8f; padding: 20px; text-align: center;">
          <h1 style="color: white; margin: 0;">MEDIUM</h1>
        </div>
        <div style="padding: 20px; background-color: #f9f9f9;">
          <h2 style="color: #333;">¡Servicio completado!</h2>
          <p style="color: #666;">Hola ${clientName},</p>
          <p style="color: #666;">Tu servicio con <strong>${businessName}</strong> ha sido marcado como completado.</p>
          <div style="background-color: #dbeafe; padding: 15px; border-radius: 8px; margin: 15px 0; text-align: center;">
            <span style="color: #1e40af; font-weight: bold;">¿Cómo fue tu experiencia?</span>
          </div>
          <p style="color: #666;">Tu opinión es muy importante. Ayuda a otros usuarios dejando una reseña sobre el servicio que recibiste.</p>
          <a href="https://mediumapp.mx/business/${businessSlug}" style="display: inline-block; background-color: #2a9d8f; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; margin-top: 15px;">Dejar reseña</a>
        </div>
        <div style="padding: 15px; text-align: center; color: #999; font-size: 12px;">
          <p>MEDIUM - Servicios Locales Verificados</p>
        </div>
      </div>
    `,
    text: `¡Servicio completado!\n\nHola ${clientName},\n\nTu servicio con ${businessName} ha sido marcado como completado.\n\n¿Cómo fue tu experiencia? Deja una reseña para ayudar a otros usuarios.`
  });
}
