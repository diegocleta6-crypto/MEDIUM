import { storage } from "./storage";
import { notifyNewNotification, notifyNewMessage, notifyNewRequest, notifyRequestStatusChange } from "./websocket";

export async function createNewRequestNotification(
  businessUserId: string,
  businessName: string,
  clientDescription: string,
  requestId: string
): Promise<void> {
  try {
    const notification = await storage.createNotification({
      userId: businessUserId,
      type: "new_request",
      title: "Nueva solicitud de servicio",
      message: clientDescription.length > 100 
        ? clientDescription.substring(0, 100) + "..." 
        : clientDescription,
      data: JSON.stringify({ requestId }),
    });

    notifyNewNotification(businessUserId, notification);
    notifyNewRequest(businessUserId, { requestId, businessName });
  } catch (error) {
    console.error("Error creating new request notification:", error);
  }
}

export async function createNewMessageNotification(
  recipientUserId: string,
  senderName: string,
  messageContent: string,
  requestId: string
): Promise<void> {
  try {
    const notification = await storage.createNotification({
      userId: recipientUserId,
      type: "new_message",
      title: `Mensaje de ${senderName}`,
      message: messageContent.length > 100 
        ? messageContent.substring(0, 100) + "..." 
        : messageContent,
      data: JSON.stringify({ requestId }),
    });

    notifyNewNotification(recipientUserId, notification);
    notifyNewMessage(recipientUserId, { requestId, senderName });
  } catch (error) {
    console.error("Error creating new message notification:", error);
  }
}

export async function createRequestAcceptedNotification(
  clientUserId: string,
  businessName: string,
  requestId: string
): Promise<void> {
  try {
    const notification = await storage.createNotification({
      userId: clientUserId,
      type: "request_accepted",
      title: "Solicitud aceptada",
      message: `${businessName} ha aceptado tu solicitud de servicio.`,
      data: JSON.stringify({ requestId }),
    });

    notifyNewNotification(clientUserId, notification);
    notifyRequestStatusChange(clientUserId, { requestId, status: "accepted", businessName });
  } catch (error) {
    console.error("Error creating request accepted notification:", error);
  }
}

export async function createServiceCompletedNotification(
  clientUserId: string,
  businessName: string,
  requestId: string
): Promise<void> {
  try {
    const notification = await storage.createNotification({
      userId: clientUserId,
      type: "service_completed",
      title: "Servicio completado",
      message: `El servicio con ${businessName} ha sido marcado como completado. Deja una resena.`,
      data: JSON.stringify({ requestId }),
    });

    notifyNewNotification(clientUserId, notification);
    notifyRequestStatusChange(clientUserId, { requestId, status: "completed", businessName });
  } catch (error) {
    console.error("Error creating service completed notification:", error);
  }
}
