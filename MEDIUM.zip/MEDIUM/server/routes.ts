import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated, registerAuthRoutes } from "./replit_integrations/auth";
import { seedDatabase } from "./seed";
import { compressImage, compressImages } from "./utils/imageCompression";


export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Setup Replit Auth
  await setupAuth(app);
  registerAuthRoutes(app);

  // Seed database on startup
  await seedDatabase();

  // Categories
  app.get("/api/categories", async (req, res) => {
    try {
      const categories = await storage.getCategories();
      res.json(categories);
    } catch (error) {
      console.error("Error fetching categories:", error);
      res.status(500).json({ message: "Error fetching categories" });
    }
  });

  // User Profile
  app.get("/api/profile", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const userEmail = req.user.claims.email;
      let profile = await storage.getUserProfile(userId);

      // Check if this email should be admin
      const adminEmail = process.env.ADMIN_EMAIL || "admin@medium.mx";
      const isAdmin = userEmail === adminEmail || userEmail === "diegocleta6@gmail.com";

      if (!profile) {
        profile = await storage.createUserProfile({ 
          userId, 
          role: isAdmin ? "admin" : "client" 
        });
      } else if (isAdmin && profile.role !== "admin") {
        // Update existing profile to admin if email matches
        profile = await storage.updateUserProfile(userId, { role: "admin" });
      }

      res.json(profile);
    } catch (error) {
      console.error("Error fetching profile:", error);
      res.status(500).json({ message: "Error fetching profile" });
    }
  });

  // Businesses
  app.get("/api/businesses", async (req, res) => {
    try {
      const { q, category, sort, featured } = req.query;

      if (featured === "true") {
        const businesses = await storage.getFeaturedBusinesses();
        return res.json(businesses);
      }

      const businesses = await storage.getBusinesses({
        query: q as string,
        categorySlug: category as string,
        sort: sort as string,
        minRating: req.query.minRating ? Number(req.query.minRating) : undefined,
        verifiedOnly: req.query.verifiedOnly === "true",
        minPrice: req.query.minPrice ? Number(req.query.minPrice) : undefined,
        maxPrice: req.query.maxPrice ? Number(req.query.maxPrice) : undefined,
      });
      res.json(businesses);
    } catch (error) {
      console.error("Error fetching businesses:", error);
      res.status(500).json({ message: "Error fetching businesses" });
    }
  });

  app.get("/api/businesses/:slugOrId", async (req, res) => {
    try {
      const { slugOrId } = req.params;
      let business = await storage.getBusinessBySlug(slugOrId);

      if (!business) {
        const byId = await storage.getBusinessById(slugOrId);
        if (byId) {
          const category = byId.categoryId
            ? await storage.getCategoryById(byId.categoryId)
            : undefined;
          business = { ...byId, category } as any;
        }
      }

      if (!business) {
        return res.status(404).json({ message: "Business not found" });
      }

      const reviews = await storage.getReviewsByBusiness(business.id);
      const planInfo = await storage.getBusinessPlan(business.id);
      res.json({ ...business, reviews, plan: planInfo.plan });
    } catch (error) {
      console.error("Error fetching business:", error);
      res.status(500).json({ message: "Error fetching business" });
    }
  });

  app.get("/api/businesses/:slugOrId/plan", async (req, res) => {
    try {
      const { slugOrId } = req.params;
      let business = await storage.getBusinessBySlug(slugOrId);
      if (!business) {
        business = await storage.getBusinessById(slugOrId) as any;
      }
      if (!business) {
        return res.status(404).json({ message: "Business not found" });
      }
      const plan = await storage.getBusinessPlan(business.id);
      res.json(plan);
    } catch (error) {
      console.error("Error fetching business plan:", error);
      res.status(500).json({ message: "Error fetching business plan" });
    }
  });

  app.post("/api/businesses", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;

      // Check if user already has a business
      const existingBusiness = await storage.getBusinessByUserId(userId);
      if (existingBusiness) {
        return res.status(400).json({ message: "User already has a business" });
      }

      // Compress images if present
      let businessData = { ...req.body, userId };
      
      if (businessData.coverImage && businessData.coverImage.startsWith('data:image/')) {
        businessData.coverImage = await compressImage(businessData.coverImage);
      }
      
      if (businessData.gallery && Array.isArray(businessData.gallery)) {
        const base64Images = businessData.gallery.filter((img: string) => img && img.startsWith('data:image/'));
        const existingUrls = businessData.gallery.filter((img: string) => img && !img.startsWith('data:image/'));
        const compressedImages = await compressImages(base64Images);
        businessData.gallery = [...existingUrls, ...compressedImages];
      }

      // Validate location is provided
      if (!businessData.latitude || !businessData.longitude) {
        if (!businessData.address) {
          return res.status(400).json({ message: "Se requiere una dirección válida para registrar el negocio" });
        }
      }

      const business = await storage.createBusiness(businessData);

      // Create wallet with initial balance
      await storage.createWallet({ businessId: business.id, balance: "500.00" });

      // Create initial transaction
      const wallet = await storage.getWalletByBusinessId(business.id);
      if (wallet) {
        await storage.createWalletTransaction({
          walletId: wallet.id,
          type: "credit",
          amount: "500.00",
          description: "Saldo inicial de bienvenida",
        });
      }

      // Update user profile to business role
      await storage.updateUserProfile(userId, { role: "business" });

      res.status(201).json(business);
    } catch (error) {
      console.error("Error creating business:", error);
      res.status(500).json({ message: "Error creating business" });
    }
  });

  app.patch("/api/business/visibility", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const business = await storage.getBusinessByUserId(userId);

      if (!business) {
        return res.status(404).json({ message: "Business not found" });
      }

      const updated = await storage.updateBusiness(business.id, {
        isVisible: req.body.isVisible,
      });

      res.json(updated);
    } catch (error) {
      console.error("Error updating visibility:", error);
      res.status(500).json({ message: "Error updating visibility" });
    }
  });

  // Pause/Resume business
  app.patch("/api/business/pause", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const business = await storage.getBusinessByUserId(userId);

      if (!business) {
        return res.status(404).json({ message: "Business not found" });
      }

      const updated = await storage.updateBusiness(business.id, {
        isPaused: !business.isPaused,
      });

      res.json(updated);
    } catch (error) {
      console.error("Error toggling pause:", error);
      res.status(500).json({ message: "Error toggling pause" });
    }
  });

  // Update business profile
  app.patch("/api/business", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const business = await storage.getBusinessByUserId(userId);

      if (!business) {
        return res.status(404).json({ message: "Business not found" });
      }

      const { name, description, phone, whatsapp, address, coverImage, gallery, services, estimatedPrices, latitude, longitude, categoryId } = req.body;

      const updateData: Record<string, any> = {};
      if (name !== undefined) updateData.name = name;
      if (description !== undefined) updateData.description = description;
      if (phone !== undefined) updateData.phone = phone;
      if (whatsapp !== undefined) updateData.whatsapp = whatsapp;
      if (address !== undefined) updateData.address = address;
      if (coverImage !== undefined) updateData.coverImage = coverImage;
      if (gallery !== undefined) updateData.gallery = gallery;
      if (services !== undefined) updateData.services = services;
      if (estimatedPrices !== undefined) updateData.estimatedPrices = estimatedPrices;
      if (latitude !== undefined) updateData.latitude = latitude;
      if (longitude !== undefined) updateData.longitude = longitude;
      if (categoryId !== undefined) updateData.categoryId = categoryId;

      const updated = await storage.updateBusiness(business.id, updateData);
      res.json(updated);
    } catch (error) {
      console.error("Error updating business:", error);
      res.status(500).json({ message: "Error updating business" });
    }
  });

  // Get own business verifications
  app.get("/api/business/verifications", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const business = await storage.getBusinessByUserId(userId);

      if (!business) {
        return res.status(404).json({ message: "Business not found" });
      }

      const verifications = await storage.getVerificationsByBusiness(business.id);
      res.json(verifications);
    } catch (error) {
      console.error("Error fetching verifications:", error);
      res.status(500).json({ message: "Error fetching verifications" });
    }
  });

  // Dashboard
  app.get("/api/dashboard", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const business = await storage.getBusinessByUserId(userId);

      if (!business) {
        return res.status(404).json({ message: "No business found" });
      }

      const wallet = await storage.getWalletByBusinessId(business.id);
      const recentTransactions = wallet ? await storage.getWalletTransactions(wallet.id) : [];
      const allRequests = await storage.getServiceRequestsByBusiness(business.id);
      const pendingRequests = allRequests.filter((r) => r.status === "pending");
      const completedRequests = allRequests.filter((r) => r.status === "completed");
      const subscription = await storage.getBusinessPlan(business.id);

      res.json({
        business,
        wallet: wallet || { balance: "0" },
        recentTransactions: recentTransactions.slice(0, 10),
        pendingRequests,
        subscription,
        stats: {
          totalRequests: allRequests.length,
          completedRequests: completedRequests.length,
          totalRevenue: 0,
        },
      });
    } catch (error) {
      console.error("Error fetching dashboard:", error);
      res.status(500).json({ message: "Error fetching dashboard" });
    }
  });

  // Service Requests
  app.get("/api/requests/my", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const requests = await storage.getServiceRequestsWithReviews(userId);
      res.json(requests);
    } catch (error) {
      console.error("Error fetching requests:", error);
      res.status(500).json({ message: "Error fetching requests" });
    }
  });

  // Chats list for authenticated users
  app.get("/api/chats", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const profile = await storage.getUserProfile(userId);
      
      let requests: any[] = [];
      
      if (profile?.role === "business") {
        const business = await storage.getBusinessByUserId(userId);
        if (business) {
          requests = await storage.getServiceRequestsByBusiness(business.id);
          // Add client info to each request
          for (const request of requests) {
            const client = await storage.getUser(request.clientId);
            request.client = client;
            const messages = await storage.getMessages(request.id);
            request.lastMessage = messages.length > 0 ? messages[messages.length - 1] : null;
          }
        }
      } else {
        requests = await storage.getServiceRequestsWithReviews(userId);
        // Add last message to each request
        for (const request of requests) {
          const messages = await storage.getMessages(request.id);
          request.lastMessage = messages.length > 0 ? messages[messages.length - 1] : null;
        }
      }
      
      // Sort by most recent message or creation date
      requests.sort((a, b) => {
        const aDate = a.lastMessage?.createdAt || a.createdAt;
        const bDate = b.lastMessage?.createdAt || b.createdAt;
        return new Date(bDate).getTime() - new Date(aDate).getTime();
      });
      
      res.json(requests);
    } catch (error) {
      console.error("Error fetching chats:", error);
      res.status(500).json({ message: "Error fetching chats" });
    }
  });

  app.post("/api/requests", isAuthenticated, async (req: any, res) => {
    try {
      const clientId = req.user.claims.sub;
      const { businessId, description, desiredDate } = req.body;

      const business = await storage.getBusinessById(businessId);
      if (!business) {
        return res.status(404).json({ message: "Business not found" });
      }

      if (!business.isActive || business.isBlocked) {
        return res.status(400).json({ message: "Business is not available" });
      }

      const request = await storage.createServiceRequest({
        clientId,
        businessId,
        description,
        desiredDate: desiredDate ? new Date(desiredDate) : null,
        leadCost: "0.00",
        status: "pending",
      });

      try {
        const { sendNewRequestEmail } = await import("./emailService");
        const { createNewRequestNotification } = await import("./notificationService");
        
        const user = await storage.getUser(business.userId);
        if (user?.email) {
          await sendNewRequestEmail(user.email, business.name, description);
        }
        
        await createNewRequestNotification(business.userId, business.name, description, request.id);
      } catch (emailError) {
        console.log("Email/notification error, continuing:", emailError);
      }

      res.status(201).json(request);
    } catch (error) {
      console.error("Error creating request:", error);
      res.status(500).json({ message: "Error creating request" });
    }
  });

  app.patch("/api/requests/:id", isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      const { status } = req.body;

      const request = await storage.getServiceRequest(id);
      if (!request) {
        return res.status(404).json({ message: "Request not found" });
      }

      const updated = await storage.updateServiceRequest(id, { status });

      // Send email and in-app notifications based on status change
      if (status === "accepted" || status === "completed") {
        try {
          const { sendRequestAcceptedEmail, sendServiceCompletedEmail } = await import("./emailService.js");
          const { createRequestAcceptedNotification, createServiceCompletedNotification } = await import("./notificationService.js");
          
          // Get client info
          const client = await storage.getUser(request.clientId);
          const business = await storage.getBusinessById(request.businessId);
          
          if (client && business) {
            const clientName = client.firstName || "Cliente";
            
            if (status === "accepted") {
              if (client.email) {
                await sendRequestAcceptedEmail(client.email, clientName, business.name, id);
              }
              await createRequestAcceptedNotification(request.clientId, business.name, id);
            } else if (status === "completed") {
              if (client.email) {
                await sendServiceCompletedEmail(client.email, clientName, business.name, business.slug);
              }
              await createServiceCompletedNotification(request.clientId, business.name, id);
            }
          }
        } catch (emailError) {
          console.error("Failed to send status notification:", emailError);
          // Don't fail the request if email/notification fails
        }
      }

      res.json(updated);
    } catch (error) {
      console.error("Error updating request:", error);
      res.status(500).json({ message: "Error updating request" });
    }
  });

  // Get single request with details
  app.get("/api/requests/:id", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { id } = req.params;
      
      const request = await storage.getServiceRequestWithDetails(id);
      if (!request) {
        return res.status(404).json({ message: "Request not found" });
      }

      // Check if user is client or business owner
      const business = request.business;
      if (request.clientId !== userId && business?.userId !== userId) {
        return res.status(403).json({ message: "Forbidden" });
      }

      let chatBlocked = false;
      let chatBlockedReason = "";
      if (business) {
        if (business.isPaused) {
          chatBlocked = true;
          chatBlockedReason = "El negocio está pausado temporalmente.";
        }
        if (business.isBlocked) {
          chatBlocked = true;
          chatBlockedReason = "El negocio no está disponible.";
        }
      }

      res.json({ ...request, chatBlocked, chatBlockedReason });
    } catch (error) {
      console.error("Error fetching request:", error);
      res.status(500).json({ message: "Error fetching request" });
    }
  });

  // Messages
  app.get("/api/messages/:serviceRequestId", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { serviceRequestId } = req.params;

      const request = await storage.getServiceRequest(serviceRequestId);
      if (!request) {
        return res.status(404).json({ message: "Request not found" });
      }

      const business = await storage.getBusinessById(request.businessId);
      if (request.clientId !== userId && business?.userId !== userId) {
        return res.status(403).json({ message: "Forbidden" });
      }

      const messages = await storage.getMessages(serviceRequestId);
      res.json(messages);
    } catch (error) {
      console.error("Error fetching messages:", error);
      res.status(500).json({ message: "Error fetching messages" });
    }
  });

  app.post("/api/messages", isAuthenticated, async (req: any, res) => {
    try {
      const senderId = req.user.claims.sub;
      const { serviceRequestId, content, images } = req.body;

      const request = await storage.getServiceRequest(serviceRequestId);
      if (!request) {
        return res.status(404).json({ message: "Request not found" });
      }

      const business = await storage.getBusinessById(request.businessId);
      if (request.clientId !== senderId && business?.userId !== senderId) {
        return res.status(403).json({ message: "Forbidden" });
      }

      // Validate images - only allow data:image/* URLs, max 5MB each, max 3 images
      let validatedImages: string[] | null = null;
      if (images && Array.isArray(images) && images.length > 0) {
        const MAX_SIZE = 5 * 1024 * 1024; // 5MB in bytes (base64 is ~1.37x larger than binary)
        const MAX_BASE64_SIZE = Math.ceil(MAX_SIZE * 1.37);
        
        const filteredImages = images
          .slice(0, 3)
          .filter((img: unknown): img is string => {
            if (typeof img !== 'string') return false;
            // Only allow data:image/* URLs (not SVG to prevent XSS)
            if (!img.startsWith('data:image/') || img.includes('svg')) return false;
            // Check size (base64 string length)
            if (img.length > MAX_BASE64_SIZE) return false;
            return true;
          });
        
        // Compress valid images
        if (filteredImages.length > 0) {
          validatedImages = await compressImages(filteredImages);
        }
      }

      const message = await storage.createMessage({
        serviceRequestId,
        senderId,
        content,
        images: validatedImages,
      });

      // Send notification to the other party
      try {
        const { createNewMessageNotification } = await import("./notificationService.js");
        const sender = await storage.getUser(senderId);
        const senderName = sender?.firstName || "Usuario";
        
        // Determine recipient (if sender is client, notify business owner; otherwise notify client)
        const recipientId = senderId === request.clientId ? business?.userId : request.clientId;
        
        if (recipientId) {
          await createNewMessageNotification(recipientId, senderName, content, serviceRequestId);
        }
      } catch (notifError) {
        console.error("Failed to send message notification:", notifError);
      }

      res.status(201).json(message);
    } catch (error) {
      console.error("Error creating message:", error);
      res.status(500).json({ message: "Error creating message" });
    }
  });

  // Reviews
  // Rate limiting map for reviews (IP -> timestamp array)
  const reviewRateLimits = new Map<string, number[]>();
  const REVIEW_RATE_LIMIT = 5; // Max reviews per hour per IP
  const REVIEW_RATE_WINDOW = 60 * 60 * 1000; // 1 hour

  app.post("/api/reviews", isAuthenticated, async (req: any, res) => {
    try {
      const clientId = req.user.claims.sub;
      const { serviceRequestId, businessId, rating, comment } = req.body;
      const clientIp = req.headers["x-forwarded-for"]?.split(",")[0]?.trim() || req.socket.remoteAddress || "unknown";

      // Rate limiting check
      const now = Date.now();
      const timestamps = reviewRateLimits.get(clientIp) || [];
      const recentTimestamps = timestamps.filter(t => now - t < REVIEW_RATE_WINDOW);
      
      if (recentTimestamps.length >= REVIEW_RATE_LIMIT) {
        return res.status(429).json({ message: "Has enviado muchas resenas. Intenta mas tarde." });
      }

      // Check if service request exists and is completed
      const serviceRequest = await storage.getServiceRequest(serviceRequestId);
      if (!serviceRequest || serviceRequest.status !== "completed") {
        return res.status(400).json({ message: "Solo puedes dejar resena en servicios completados." });
      }

      // Check for suspicious activity (new account with multiple reviews in short time)
      const clientProfile = await storage.getUserProfile(clientId);
      const userReviews = await storage.getReviewsByClient(clientId);
      
      let isSuspicious = false;
      let suspiciousReason = null;
      
      // Flag if user posts multiple reviews quickly (suspicious pattern)
      if (userReviews.length >= 3) {
        const recentReviews = userReviews.filter(r => {
          const reviewAge = r.createdAt ? Date.now() - new Date(r.createdAt).getTime() : Infinity;
          return reviewAge < 7 * 24 * 60 * 60 * 1000; // Within last 7 days
        });
        
        if (recentReviews.length >= 3) {
          isSuspicious = true;
          suspiciousReason = "Multiples resenas en poco tiempo";
        }
      }

      // Auto-verify if the service was completed AND user is not reported
      const userIsReported = clientProfile?.isBlocked || false;
      const isVerified = serviceRequest.status === "completed" && !userIsReported;

      const review = await storage.createReview({
        serviceRequestId,
        clientId,
        businessId,
        rating,
        comment,
        isVerified,
        isSuspicious,
        suspiciousReason,
        ipAddress: clientIp,
      });

      // Update rate limit
      recentTimestamps.push(now);
      reviewRateLimits.set(clientIp, recentTimestamps);

      res.status(201).json(review);
    } catch (error) {
      console.error("Error creating review:", error);
      res.status(500).json({ message: "Error creating review" });
    }
  });

  // Update review
  app.patch("/api/reviews/:reviewId", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { reviewId } = req.params;
      const { rating, comment } = req.body;

      const review = await storage.getReviewById(reviewId);
      if (!review) {
        return res.status(404).json({ message: "Review not found" });
      }

      if (review.clientId !== userId) {
        return res.status(403).json({ message: "Forbidden" });
      }

      const updated = await storage.updateReview(reviewId, { rating, comment });
      res.json(updated);
    } catch (error) {
      console.error("Error updating review:", error);
      res.status(500).json({ message: "Error updating review" });
    }
  });

  // Delete review
  app.delete("/api/reviews/:reviewId", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { reviewId } = req.params;

      const review = await storage.getReviewById(reviewId);
      if (!review) {
        return res.status(404).json({ message: "Review not found" });
      }

      if (review.clientId !== userId) {
        return res.status(403).json({ message: "Forbidden" });
      }

      await storage.deleteReview(reviewId, userId);
      res.json({ message: "Review deleted" });
    } catch (error) {
      console.error("Error deleting review:", error);
      res.status(500).json({ message: "Error deleting review" });
    }
  });

  // Business Services
  app.get("/api/businesses/:businessId/services", async (req, res) => {
    try {
      const { businessId } = req.params;
      const services = await storage.getBusinessServices(businessId);
      res.json(services);
    } catch (error) {
      console.error("Error fetching services:", error);
      res.status(500).json({ message: "Error fetching services" });
    }
  });

  app.post("/api/business-services", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const business = await storage.getBusinessByUserId(userId);
      
      if (!business) {
        return res.status(404).json({ message: "Business not found" });
      }

      const { name, description, minPrice, maxPrice } = req.body;
      
      // Validate prices
      if (minPrice !== undefined && (minPrice <= 0 || isNaN(minPrice))) {
        return res.status(400).json({ message: "El precio mínimo debe ser mayor a 0" });
      }
      if (maxPrice !== undefined && (maxPrice <= 0 || isNaN(maxPrice))) {
        return res.status(400).json({ message: "El precio máximo debe ser mayor a 0" });
      }
      if (minPrice && maxPrice && Number(minPrice) > Number(maxPrice)) {
        return res.status(400).json({ message: "El precio mínimo no puede ser mayor al máximo" });
      }

      const service = await storage.createBusinessService({
        businessId: business.id,
        name,
        description,
        minPrice,
        maxPrice,
      });

      res.status(201).json(service);
    } catch (error) {
      console.error("Error creating service:", error);
      res.status(500).json({ message: "Error creating service" });
    }
  });

  app.patch("/api/business-services/:id", isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      const userId = req.user.claims.sub;
      const business = await storage.getBusinessByUserId(userId);
      
      if (!business) {
        return res.status(404).json({ message: "Business not found" });
      }

      const service = await storage.getBusinessServiceById(id);
      if (!service || service.businessId !== business.id) {
        return res.status(403).json({ message: "Unauthorized to update this service" });
      }

      const { name, description, minPrice, maxPrice } = req.body;
      const updated = await storage.updateBusinessService(id, { name, description, minPrice, maxPrice });
      res.json(updated);
    } catch (error) {
      console.error("Error updating service:", error);
      res.status(500).json({ message: "Error updating service" });
    }
  });

  app.delete("/api/business-services/:id", isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      const userId = req.user.claims.sub;
      const business = await storage.getBusinessByUserId(userId);
      
      if (!business) {
        return res.status(404).json({ message: "Business not found" });
      }

      const service = await storage.getBusinessServiceById(id);
      if (!service || service.businessId !== business.id) {
        return res.status(403).json({ message: "Unauthorized to delete this service" });
      }

      await storage.deleteBusinessService(id);
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting service:", error);
      res.status(500).json({ message: "Error deleting service" });
    }
  });

  // Geocoding - Convert address to coordinates
  app.post("/api/geocode", async (req, res) => {
    try {
      const { address } = req.body;
      if (!address) {
        return res.status(400).json({ message: "Address is required" });
      }

      // Use Nominatim (OpenStreetMap) for geocoding - free and no API key required
      const response = await fetch(
        `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(address)}&countrycodes=mx&limit=1`,
        {
          headers: {
            "User-Agent": "MEDIUM-Marketplace/1.0",
          },
        }
      );

      if (!response.ok) {
        return res.status(500).json({ message: "Geocoding service error" });
      }

      const results = await response.json();
      if (results.length === 0) {
        return res.status(404).json({ message: "Address not found" });
      }

      res.json({
        latitude: parseFloat(results[0].lat),
        longitude: parseFloat(results[0].lon),
        displayName: results[0].display_name,
      });
    } catch (error) {
      console.error("Error geocoding:", error);
      res.status(500).json({ message: "Error geocoding address" });
    }
  });

  // Verifications
  app.post("/api/verifications", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const business = await storage.getBusinessByUserId(userId);

      if (!business) {
        return res.status(404).json({ message: "Business not found" });
      }

      const verification = await storage.createVerification({
        businessId: business.id,
        documentType: req.body.documentType,
        documentUrl: req.body.documentUrl,
      });

      res.status(201).json(verification);
    } catch (error) {
      console.error("Error creating verification:", error);
      res.status(500).json({ message: "Error creating verification" });
    }
  });

  // Wallet Recharge - Create Stripe Checkout Session
  app.post("/api/wallet/recharge", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { amount } = req.body;

      const business = await storage.getBusinessByUserId(userId);
      if (!business) {
        return res.status(404).json({ message: "Business not found" });
      }

      const wallet = await storage.getWalletByBusinessId(business.id);
      if (!wallet) {
        return res.status(404).json({ message: "Wallet not found" });
      }

      // Try to use Stripe for real payments
      try {
        const { getUncachableStripeClient } = await import("./stripeClient");
        const stripe = await getUncachableStripeClient();

        const baseUrl = `https://${process.env.REPLIT_DOMAINS?.split(',')[0] || 'localhost:5000'}`;
        
        const session = await stripe.checkout.sessions.create({
          payment_method_types: ['card'],
          line_items: [{
            price_data: {
              currency: 'mxn',
              product_data: {
                name: `Recarga de saldo MEDIUM`,
                description: `Recarga de $${amount} MXN a tu billetera`,
              },
              unit_amount: amount * 100, // Stripe uses cents
            },
            quantity: 1,
          }],
          mode: 'payment',
          success_url: `${baseUrl}/dashboard?recharge=pending`,
          cancel_url: `${baseUrl}/dashboard?recharge=cancelled`,
          metadata: {
            walletId: wallet.id,
            businessId: business.id,
            amount: String(amount),
          },
        });

        res.json({ url: session.url });
      } catch (stripeError: any) {
        // Only allow simulated payments in development when Stripe is not configured
        if (process.env.NODE_ENV !== "production" && stripeError.message.includes("connection not found")) {
          console.log("DEV MODE: Stripe not configured, simulating payment");
          
          await storage.updateWalletBalance(wallet.id, amount);
          await storage.createWalletTransaction({
            walletId: wallet.id,
            type: "credit",
            amount: String(amount),
            description: `Recarga de saldo (dev) - $${amount} MXN`,
          });

          if (!business.isVisible) {
            await storage.updateBusiness(business.id, { isVisible: true });
          }

          res.json({ success: true, newBalance: Number(wallet.balance) + amount, simulated: true });
        } else {
          console.error("Stripe error:", stripeError.message);
          res.status(500).json({ message: "Error connecting to payment provider" });
        }
      }
    } catch (error) {
      console.error("Error recharging wallet:", error);
      res.status(500).json({ message: "Error processing payment" });
    }
  });


  // Admin routes
  app.get("/api/admin/stats", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const profile = await storage.getUserProfile(userId);

      if (!profile || profile.role !== "admin") {
        return res.status(403).json({ message: "Forbidden" });
      }

      const stats = await storage.getAdminStats();
      res.json(stats);
    } catch (error) {
      console.error("Error fetching admin stats:", error);
      res.status(500).json({ message: "Error fetching stats" });
    }
  });

  app.get("/api/admin/verifications", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const profile = await storage.getUserProfile(userId);

      if (!profile || profile.role !== "admin") {
        return res.status(403).json({ message: "Forbidden" });
      }

      const verifications = await storage.getPendingVerifications();
      res.json(verifications);
    } catch (error) {
      console.error("Error fetching verifications:", error);
      res.status(500).json({ message: "Error fetching verifications" });
    }
  });

  app.patch("/api/admin/verifications/:id", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const profile = await storage.getUserProfile(userId);

      if (!profile || profile.role !== "admin") {
        return res.status(403).json({ message: "Forbidden" });
      }

      const { id } = req.params;
      const { status, reviewNote } = req.body;

      const verification = await storage.updateVerification(id, {
        status,
        reviewNote,
        reviewedBy: userId,
        reviewedAt: new Date(),
      });

      if (status === "approved" && verification) {
        try {
          const verifications = await storage.getVerificationsByBusiness(verification.businessId);
          const allApproved = verifications.every((v) => v.status === "approved");
          
          if (allApproved && verifications.length >= 2) {
            const business = await storage.getBusinessById(verification.businessId);
            if (business) {
              const user = await storage.getUser(business.userId);
              if (user?.email) {
                const { sendVerificationApprovedEmail } = await import("./emailService");
                await sendVerificationApprovedEmail(user.email, business.name);
              }
            }
          }
        } catch (emailError) {
          console.log("Email not configured, skipping notification");
        }
      }

      res.json(verification);
    } catch (error) {
      console.error("Error updating verification:", error);
      res.status(500).json({ message: "Error updating verification" });
    }
  });

  app.get("/api/admin/transactions", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const profile = await storage.getUserProfile(userId);

      if (!profile || profile.role !== "admin") {
        return res.status(403).json({ message: "Forbidden" });
      }

      const transactions = await storage.getAllWalletTransactions();
      res.json(transactions);
    } catch (error) {
      console.error("Error fetching transactions:", error);
      res.status(500).json({ message: "Error fetching transactions" });
    }
  });

  app.get("/api/admin/businesses", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const profile = await storage.getUserProfile(userId);

      if (!profile || profile.role !== "admin") {
        return res.status(403).json({ message: "Forbidden" });
      }

      const businesses = await storage.getAllBusinesses();
      res.json(businesses);
    } catch (error) {
      console.error("Error fetching businesses:", error);
      res.status(500).json({ message: "Error fetching businesses" });
    }
  });

  app.patch("/api/admin/businesses/:id", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const profile = await storage.getUserProfile(userId);

      if (!profile || profile.role !== "admin") {
        return res.status(403).json({ message: "Forbidden" });
      }

      const { id } = req.params;
      const business = await storage.updateBusiness(id, req.body);
      res.json(business);
    } catch (error) {
      console.error("Error updating business:", error);
      res.status(500).json({ message: "Error updating business" });
    }
  });

  app.get("/api/admin/users", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const profile = await storage.getUserProfile(userId);

      if (!profile || profile.role !== "admin") {
        return res.status(403).json({ message: "Forbidden" });
      }

      const users = await storage.getAllUsers();
      res.json(users);
    } catch (error) {
      console.error("Error fetching users:", error);
      res.status(500).json({ message: "Error fetching users" });
    }
  });

  // Admin manual wallet recharge
  app.post("/api/admin/wallet/recharge", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const profile = await storage.getUserProfile(userId);

      if (!profile || profile.role !== "admin") {
        return res.status(403).json({ message: "Forbidden" });
      }

      const { businessId, amount, description } = req.body;
      
      if (!businessId || !amount || amount <= 0) {
        return res.status(400).json({ message: "Invalid request" });
      }

      const wallet = await storage.getWalletByBusinessId(businessId);
      if (!wallet) {
        return res.status(404).json({ message: "Wallet not found" });
      }

      await storage.updateWalletBalance(wallet.id, amount);
      await storage.createWalletTransaction({
        walletId: wallet.id,
        type: "credit",
        amount: String(amount),
        description: description || `Recarga manual por admin - $${amount} MXN`,
      });

      const updatedWallet = await storage.getWalletByBusinessId(businessId);
      res.json({ success: true, newBalance: updatedWallet?.balance });
    } catch (error) {
      console.error("Error recharging wallet:", error);
      res.status(500).json({ message: "Error processing recharge" });
    }
  });

  // Notifications
  app.get("/api/notifications", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const notifications = await storage.getNotifications(userId);
      const unreadCount = await storage.getUnreadNotificationCount(userId);
      res.json({ notifications, unreadCount });
    } catch (error) {
      console.error("Error fetching notifications:", error);
      res.status(500).json({ message: "Error fetching notifications" });
    }
  });

  app.post("/api/notifications/:id/read", isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      await storage.markNotificationRead(id);
      res.json({ success: true });
    } catch (error) {
      console.error("Error marking notification read:", error);
      res.status(500).json({ message: "Error marking notification read" });
    }
  });

  app.post("/api/notifications/read-all", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      await storage.markAllNotificationsRead(userId);
      res.json({ success: true });
    } catch (error) {
      console.error("Error marking all notifications read:", error);
      res.status(500).json({ message: "Error marking notifications read" });
    }
  });

  // Review management
  app.patch("/api/reviews/:id", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { id } = req.params;
      const review = await storage.getReviewById(id);
      
      if (!review) {
        return res.status(404).json({ message: "Review not found" });
      }
      
      if (review.clientId !== userId) {
        return res.status(403).json({ message: "Unauthorized" });
      }
      
      const { rating, comment } = req.body;
      if (rating !== undefined && (rating < 1 || rating > 5)) {
        return res.status(400).json({ message: "Rating must be between 1 and 5" });
      }
      
      const updated = await storage.updateReview(id, { rating, comment });
      res.json(updated);
    } catch (error) {
      console.error("Error updating review:", error);
      res.status(500).json({ message: "Error updating review" });
    }
  });

  app.delete("/api/reviews/:id", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { id } = req.params;
      const review = await storage.getReviewById(id);
      
      if (!review) {
        return res.status(404).json({ message: "Review not found" });
      }
      
      if (review.clientId !== userId) {
        return res.status(403).json({ message: "Unauthorized" });
      }
      
      await storage.deleteReview(id, userId);
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting review:", error);
      res.status(500).json({ message: "Error deleting review" });
    }
  });

  app.post("/api/reviews/:id/report", isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      const { reason } = req.body;
      const review = await storage.getReviewById(id);
      
      if (!review) {
        return res.status(404).json({ message: "Review not found" });
      }
      
      await storage.updateReview(id, { isReported: true, reportReason: reason });
      res.json({ success: true });
    } catch (error) {
      console.error("Error reporting review:", error);
      res.status(500).json({ message: "Error reporting review" });
    }
  });

  // Business visibility toggle
  app.post("/api/business/toggle-pause", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const business = await storage.getBusinessByUserId(userId);
      
      if (!business) {
        return res.status(404).json({ message: "Business not found" });
      }
      
      const { isPaused } = req.body;
      const updated = await storage.toggleBusinessPaused(business.id, isPaused);
      res.json(updated);
    } catch (error) {
      console.error("Error toggling business pause:", error);
      res.status(500).json({ message: "Error toggling business visibility" });
    }
  });

  // View counter increment
  app.post("/api/businesses/:slug/view", async (req, res) => {
    try {
      const { slug } = req.params;
      const business = await storage.getBusinessBySlug(slug);
      
      if (!business) {
        return res.status(404).json({ message: "Business not found" });
      }
      
      await storage.incrementBusinessViews(business.id);
      res.json({ success: true });
    } catch (error) {
      console.error("Error incrementing views:", error);
      res.status(500).json({ message: "Error incrementing views" });
    }
  });

  // Admin - Block/Unblock users
  app.post("/api/admin/users/:userId/block", isAuthenticated, async (req: any, res) => {
    try {
      const adminId = req.user.claims.sub;
      const profile = await storage.getUserProfile(adminId);
      
      if (!profile || profile.role !== "admin") {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      const { userId } = req.params;
      const { reason } = req.body;
      await storage.blockUser(userId, reason || "Bloqueado por administrador");
      res.json({ success: true });
    } catch (error) {
      console.error("Error blocking user:", error);
      res.status(500).json({ message: "Error blocking user" });
    }
  });

  app.post("/api/admin/users/:userId/unblock", isAuthenticated, async (req: any, res) => {
    try {
      const adminId = req.user.claims.sub;
      const profile = await storage.getUserProfile(adminId);
      
      if (!profile || profile.role !== "admin") {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      const { userId } = req.params;
      await storage.unblockUser(userId);
      res.json({ success: true });
    } catch (error) {
      console.error("Error unblocking user:", error);
      res.status(500).json({ message: "Error unblocking user" });
    }
  });

  // Admin - Block/Unblock businesses
  app.post("/api/admin/businesses/:id/block", isAuthenticated, async (req: any, res) => {
    try {
      const adminId = req.user.claims.sub;
      const profile = await storage.getUserProfile(adminId);
      
      if (!profile || profile.role !== "admin") {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      const { id } = req.params;
      const { reason } = req.body;
      await storage.blockBusiness(id, reason || "Bloqueado por administrador");
      res.json({ success: true });
    } catch (error) {
      console.error("Error blocking business:", error);
      res.status(500).json({ message: "Error blocking business" });
    }
  });

  app.post("/api/admin/businesses/:id/unblock", isAuthenticated, async (req: any, res) => {
    try {
      const adminId = req.user.claims.sub;
      const profile = await storage.getUserProfile(adminId);
      
      if (!profile || profile.role !== "admin") {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      const { id } = req.params;
      await storage.unblockBusiness(id);
      res.json({ success: true });
    } catch (error) {
      console.error("Error unblocking business:", error);
      res.status(500).json({ message: "Error unblocking business" });
    }
  });

  // Admin - Delete business
  app.delete("/api/admin/businesses/:id", isAuthenticated, async (req: any, res) => {
    try {
      const adminId = req.user.claims.sub;
      const profile = await storage.getUserProfile(adminId);
      
      if (!profile || profile.role !== "admin") {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      const { id } = req.params;
      await storage.deleteBusiness(id);
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting business:", error);
      res.status(500).json({ message: "Error deleting business" });
    }
  });

  // Admin - Reported reviews
  app.get("/api/admin/reviews/reported", isAuthenticated, async (req: any, res) => {
    try {
      const adminId = req.user.claims.sub;
      const profile = await storage.getUserProfile(adminId);
      
      if (!profile || profile.role !== "admin") {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      const reportedReviews = await storage.getReportedReviews();
      res.json(reportedReviews);
    } catch (error) {
      console.error("Error fetching reported reviews:", error);
      res.status(500).json({ message: "Error fetching reported reviews" });
    }
  });

  // Suspicious reviews for admin
  app.get("/api/admin/reviews/suspicious", isAuthenticated, async (req: any, res) => {
    try {
      const adminId = req.user.claims.sub;
      const profile = await storage.getUserProfile(adminId);
      
      if (!profile || profile.role !== "admin") {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      const suspiciousReviews = await storage.getSuspiciousReviews();
      res.json(suspiciousReviews);
    } catch (error) {
      console.error("Error fetching suspicious reviews:", error);
      res.status(500).json({ message: "Error fetching suspicious reviews" });
    }
  });

  // Admin - Delete review (mark as deleted)
  app.delete("/api/admin/reviews/:id", isAuthenticated, async (req: any, res) => {
    try {
      const adminId = req.user.claims.sub;
      const profile = await storage.getUserProfile(adminId);
      
      if (!profile || profile.role !== "admin") {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      const { id } = req.params;
      await storage.deleteReview(id, adminId);
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting review:", error);
      res.status(500).json({ message: "Error deleting review" });
    }
  });

  // Profile update
  app.patch("/api/profile", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { displayName, avatarUrl, phone, whatsapp, address } = req.body;
      
      let processedAvatar = avatarUrl;
      if (avatarUrl && avatarUrl.startsWith('data:image/')) {
        processedAvatar = await compressImage(avatarUrl);
      }
      
      const profile = await storage.updateUserProfile(userId, {
        displayName,
        avatarUrl: processedAvatar,
        phone,
        whatsapp,
        address,
      });
      res.json(profile);
    } catch (error) {
      console.error("Error updating profile:", error);
      res.status(500).json({ message: "Error updating profile" });
    }
  });

  // Favorites
  app.get("/api/favorites", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const favorites = await storage.getFavoritesByUser(userId);
      res.json(favorites);
    } catch (error) {
      console.error("Error fetching favorites:", error);
      res.status(500).json({ message: "Error fetching favorites" });
    }
  });

  app.get("/api/favorites/check/:businessId", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { businessId } = req.params;
      const isFav = await storage.isFavorite(userId, businessId);
      res.json({ isFavorite: isFav });
    } catch (error) {
      console.error("Error checking favorite:", error);
      res.status(500).json({ message: "Error checking favorite" });
    }
  });

  app.post("/api/favorites/:businessId", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { businessId } = req.params;
      await storage.addFavorite(userId, businessId);
      res.json({ success: true });
    } catch (error) {
      console.error("Error adding favorite:", error);
      res.status(500).json({ message: "Error adding favorite" });
    }
  });

  app.delete("/api/favorites/:businessId", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { businessId } = req.params;
      await storage.removeFavorite(userId, businessId);
      res.json({ success: true });
    } catch (error) {
      console.error("Error removing favorite:", error);
      res.status(500).json({ message: "Error removing favorite" });
    }
  });

  // Reports
  app.post("/api/reports", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { type, businessId, serviceRequestId, messageId, reason, details } = req.body;
      
      if (!type || !reason) {
        return res.status(400).json({ message: "Tipo y razón son requeridos" });
      }
      
      if (type === "business" && businessId) {
        const biz = await storage.getBusinessById(businessId);
        if (!biz) {
          return res.status(404).json({ message: "Negocio no encontrado" });
        }
      }
      
      const report = await storage.createReport({
        reporterId: userId,
        type,
        businessId: businessId || null,
        serviceRequestId: serviceRequestId || null,
        messageId: messageId || null,
        reason,
        details: details || null,
      });
      res.json(report);
    } catch (error) {
      console.error("Error creating report:", error);
      res.status(500).json({ message: "Error creating report" });
    }
  });

  // Admin Reports
  app.get("/api/admin/reports", isAuthenticated, async (req: any, res) => {
    try {
      const adminId = req.user.claims.sub;
      const profile = await storage.getUserProfile(adminId);
      if (!profile || profile.role !== "admin") {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      const status = req.query.status as string;
      const reports = status ? await storage.getReportsByStatus(status) : await storage.getReports();
      res.json(reports);
    } catch (error) {
      console.error("Error fetching reports:", error);
      res.status(500).json({ message: "Error fetching reports" });
    }
  });

  app.patch("/api/admin/reports/:id", isAuthenticated, async (req: any, res) => {
    try {
      const adminId = req.user.claims.sub;
      const profile = await storage.getUserProfile(adminId);
      if (!profile || profile.role !== "admin") {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      const { id } = req.params;
      const { status, reviewNote } = req.body;
      const report = await storage.updateReport(id, {
        status,
        reviewNote,
        reviewedBy: adminId,
        reviewedAt: new Date(),
      });
      res.json(report);
    } catch (error) {
      console.error("Error updating report:", error);
      res.status(500).json({ message: "Error updating report" });
    }
  });

  // Subscription management
  app.get("/api/subscription", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const business = await storage.getBusinessByUserId(userId);
      if (!business) {
        return res.status(404).json({ message: "No business found" });
      }
      const plan = await storage.getBusinessPlan(business.id);
      const subscription = await storage.getBusinessSubscription(business.id);
      res.json({ ...plan, subscription });
    } catch (error) {
      console.error("Error fetching subscription:", error);
      res.status(500).json({ message: "Error fetching subscription" });
    }
  });

  app.post("/api/subscription/checkout", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { plan } = req.body;

      if (!["pro", "premium"].includes(plan)) {
        return res.status(400).json({ message: "Plan no válido" });
      }

      const business = await storage.getBusinessByUserId(userId);
      if (!business) {
        return res.status(404).json({ message: "No business found" });
      }

      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      const { getUncachableStripeClient } = await import("./stripeClient");
      const stripe = await getUncachableStripeClient();

      let existingSub = await storage.getBusinessSubscription(business.id);
      let customerId = existingSub?.stripeCustomerId;

      if (!customerId) {
        const customer = await stripe.customers.create({
          email: user.email || undefined,
          metadata: { businessId: business.id, userId },
        });
        customerId = customer.id;
      }

      const priceMap: Record<string, number> = {
        pro: 29900,
        premium: 79900,
      };

      const session = await stripe.checkout.sessions.create({
        customer: customerId,
        payment_method_types: ["card"],
        line_items: [{
          price_data: {
            currency: "mxn",
            product_data: {
              name: `Plan ${plan.charAt(0).toUpperCase() + plan.slice(1)} - MEDIUM`,
              description: plan === "premium" ? "Máxima visibilidad, badge destacado, prioridad en resultados" : "Mayor visibilidad, estadísticas básicas, más leads",
            },
            unit_amount: priceMap[plan],
            recurring: { interval: "month" },
          },
          quantity: 1,
        }],
        mode: "subscription",
        success_url: `${req.protocol}://${req.get("host")}/dashboard?subscription=success`,
        cancel_url: `${req.protocol}://${req.get("host")}/pricing?subscription=cancelled`,
        metadata: { businessId: business.id, userId, plan },
      });

      res.json({ url: session.url });
    } catch (error) {
      console.error("Error creating checkout session:", error);
      res.status(500).json({ message: "Error creating checkout session" });
    }
  });

  app.post("/api/subscription/portal", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const business = await storage.getBusinessByUserId(userId);
      if (!business) {
        return res.status(404).json({ message: "No business found" });
      }

      const subscription = await storage.getBusinessSubscription(business.id);
      if (!subscription?.stripeCustomerId) {
        return res.status(400).json({ message: "No subscription found" });
      }

      const { getUncachableStripeClient } = await import("./stripeClient");
      const stripe = await getUncachableStripeClient();

      const session = await stripe.billingPortal.sessions.create({
        customer: subscription.stripeCustomerId,
        return_url: `${req.protocol}://${req.get("host")}/dashboard`,
      });

      res.json({ url: session.url });
    } catch (error) {
      console.error("Error creating portal session:", error);
      res.status(500).json({ message: "Error creating portal session" });
    }
  });

  app.post("/api/subscription/trial", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { plan } = req.body;

      if (!["pro", "premium"].includes(plan)) {
        return res.status(400).json({ message: "Plan no válido" });
      }

      const business = await storage.getBusinessByUserId(userId);
      if (!business) {
        return res.status(404).json({ message: "No business found" });
      }

      const existingSub = await storage.getBusinessSubscription(business.id);
      if (existingSub && existingSub.plan !== "free") {
        return res.status(400).json({ message: "Ya tienes un plan activo" });
      }

      const trialEnd = new Date();
      trialEnd.setDate(trialEnd.getDate() + 30);

      if (existingSub) {
        await storage.updateBusinessSubscription(existingSub.id, {
          plan,
          status: "trial",
          currentPeriodEnd: trialEnd,
        });
      } else {
        await storage.createBusinessSubscription({
          businessId: business.id,
          plan,
          status: "trial",
          currentPeriodEnd: trialEnd,
        });
      }

      res.json({ success: true, plan, trialEnd });
    } catch (error) {
      console.error("Error starting trial:", error);
      res.status(500).json({ message: "Error starting trial" });
    }
  });

  // Service Request Status Update
  app.patch("/api/requests/:id/status", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { id } = req.params;
      const { status } = req.body;
      
      const validStatuses = ["pending", "in_progress", "completed", "cancelled"];
      if (!validStatuses.includes(status)) {
        return res.status(400).json({ message: "Estado no válido" });
      }
      
      const request = await storage.getServiceRequest(id);
      if (!request) {
        return res.status(404).json({ message: "Solicitud no encontrada" });
      }
      
      const business = await storage.getBusinessByUserId(userId);
      if (!business || business.id !== request.businessId) {
        const profile = await storage.getUserProfile(userId);
        if (request.clientId !== userId && profile?.role !== "admin") {
          return res.status(403).json({ message: "No autorizado" });
        }
        if (request.clientId === userId && status !== "cancelled") {
          return res.status(403).json({ message: "Solo puedes cancelar la solicitud" });
        }
      }
      
      const updated = await storage.updateServiceRequest(id, { status });
      res.json(updated);
    } catch (error) {
      console.error("Error updating request status:", error);
      res.status(500).json({ message: "Error updating request status" });
    }
  });

  // Dashboard Chart Data
  app.get("/api/dashboard/charts", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const business = await storage.getBusinessByUserId(userId);
      if (!business) {
        return res.status(404).json({ message: "No business found" });
      }
      
      const chartData = await storage.getDashboardChartData(business.id);
      res.json(chartData);
    } catch (error) {
      console.error("Error fetching chart data:", error);
      res.status(500).json({ message: "Error fetching chart data" });
    }
  });

  return httpServer;
}
