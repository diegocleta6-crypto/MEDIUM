import { db } from "./db";
import { categories, businesses, wallets, walletTransactions, reviews, userProfiles } from "@shared/schema";
import { users } from "@shared/models/auth";
import { sql } from "drizzle-orm";

const parentCategories = [
  { name: "Hogar", slug: "hogar", icon: "home", description: "Servicios para el hogar y mantenimiento" },
  { name: "Vehículos", slug: "vehiculos", icon: "car", description: "Servicios automotrices y mecánicos" },
  { name: "Salud y Belleza", slug: "salud-belleza", icon: "heart", description: "Cuidado personal, salud y estética" },
  { name: "Tecnología", slug: "tecnologia", icon: "monitor", description: "Servicios de tecnología y soporte técnico" },
  { name: "Eventos", slug: "eventos", icon: "party-popper", description: "Organización y servicios para eventos" },
  { name: "Educación", slug: "educacion", icon: "graduation-cap", description: "Clases, tutorías y capacitación" },
];

const subcategoriesMap: Record<string, { name: string; slug: string; icon: string; description: string }[]> = {
  hogar: [
    { name: "Plomería", slug: "plomeria", icon: "wrench", description: "Reparación y mantenimiento de tuberías, instalación de sanitarios" },
    { name: "Electricidad", slug: "electricidad", icon: "zap", description: "Instalaciones eléctricas, reparaciones, iluminación" },
    { name: "Limpieza", slug: "limpieza", icon: "sparkles", description: "Limpieza de hogares, oficinas y espacios comerciales" },
    { name: "Pintura", slug: "pintura", icon: "paintbrush", description: "Pintura interior y exterior, acabados decorativos" },
    { name: "Carpintería", slug: "carpinteria", icon: "home", description: "Muebles a medida, reparaciones de madera" },
    { name: "Cerrajería", slug: "cerrajeria", icon: "briefcase", description: "Apertura de cerraduras, instalación de chapas" },
    { name: "Jardinería", slug: "jardineria", icon: "scissors", description: "Mantenimiento de jardines, podas, diseño paisajístico" },
    { name: "Mudanzas", slug: "mudanzas", icon: "truck", description: "Fletes, mudanzas locales y foráneas" },
    { name: "Impermeabilización", slug: "impermeabilizacion", icon: "umbrella", description: "Impermeabilización de techos y muros" },
    { name: "Herrería", slug: "herreria", icon: "shield", description: "Fabricación e instalación de estructuras metálicas" },
  ],
  vehiculos: [
    { name: "Mecánica general", slug: "mecanica-general", icon: "wrench", description: "Reparación y mantenimiento de vehículos" },
    { name: "Hojalatería y pintura", slug: "hojalateria-pintura", icon: "paintbrush", description: "Reparación de carrocería y pintura automotriz" },
    { name: "Electromecánica", slug: "electromecanica", icon: "zap", description: "Sistemas eléctricos automotrices" },
    { name: "Grúas y remolques", slug: "gruas-remolques", icon: "truck", description: "Servicio de grúa y remolque" },
  ],
  "salud-belleza": [
    { name: "Estética", slug: "estetica", icon: "scissors", description: "Cortes, peinados, tintes y tratamientos capilares" },
    { name: "Masajes", slug: "masajes", icon: "heart", description: "Masajes terapéuticos y relajantes" },
    { name: "Enfermería a domicilio", slug: "enfermeria", icon: "heart", description: "Cuidado de pacientes en casa" },
    { name: "Nutrición", slug: "nutricion", icon: "apple", description: "Planes alimenticios y consultas nutricionales" },
  ],
  tecnologia: [
    { name: "Reparación de computadoras", slug: "reparacion-computadoras", icon: "monitor", description: "Mantenimiento y reparación de PCs y laptops" },
    { name: "Reparación de celulares", slug: "reparacion-celulares", icon: "smartphone", description: "Reparación de pantallas, baterías y más" },
    { name: "Redes e internet", slug: "redes-internet", icon: "wifi", description: "Instalación y configuración de redes" },
    { name: "Desarrollo web", slug: "desarrollo-web", icon: "code", description: "Creación de páginas web y aplicaciones" },
  ],
  eventos: [
    { name: "Fotografía", slug: "fotografia", icon: "camera", description: "Fotografía profesional para eventos" },
    { name: "Catering", slug: "catering", icon: "utensils", description: "Servicio de alimentos y bebidas para eventos" },
    { name: "Música y DJ", slug: "musica-dj", icon: "music", description: "Entretenimiento musical para fiestas" },
    { name: "Decoración", slug: "decoracion-eventos", icon: "party-popper", description: "Decoración y ambientación de eventos" },
  ],
  educacion: [
    { name: "Clases de idiomas", slug: "clases-idiomas", icon: "book-open", description: "Inglés, francés y otros idiomas" },
    { name: "Tutorías escolares", slug: "tutorias", icon: "graduation-cap", description: "Apoyo en materias escolares" },
    { name: "Clases de música", slug: "clases-musica", icon: "music", description: "Piano, guitarra y otros instrumentos" },
    { name: "Capacitación empresarial", slug: "capacitacion", icon: "briefcase", description: "Cursos y talleres para empresas" },
  ],
};

const seedBusinesses = [
  {
    name: "Plomería Express CDMX",
    categorySlug: "plomeria",
    description: "Somos especialistas en plomería con más de 15 años de experiencia. Ofrecemos servicio 24/7 para emergencias. Trabajo garantizado y precios justos.",
    phone: "5512345678",
    whatsapp: "5512345678",
    address: "Zona Metropolitana CDMX",
    latitude: "19.4326",
    longitude: "-99.1332",
    services: ["Destape de drenaje", "Reparación de fugas", "Instalación de boiler", "Cambio de llaves"],
    estimatedPrices: "Revisión: $200-$300\nDestape básico: $350-$500\nReparación de fuga: $400-$800",
    rating: "4.8",
    reviewCount: 47,
    isVerified: true,
    isActive: true,
    isVisible: true,
  },
  {
    name: "ElectroSoluciones",
    categorySlug: "electricidad",
    description: "Electricistas certificados. Instalaciones residenciales y comerciales. Trabajamos con los mejores materiales del mercado.",
    phone: "5523456789",
    whatsapp: "5523456789",
    address: "Polanco, Miguel Hidalgo",
    latitude: "19.4342",
    longitude: "-99.1935",
    services: ["Instalación de apagadores", "Centro de carga", "Cableado estructurado", "Iluminación LED"],
    estimatedPrices: "Instalación de contacto: $250-$400\nCambio de centro de carga: $2,500-$4,000",
    rating: "4.6",
    reviewCount: 32,
    isVerified: true,
    isActive: true,
    isVisible: true,
  },
  {
    name: "Limpieza Total",
    categorySlug: "limpieza",
    description: "Servicio profesional de limpieza para hogares y oficinas. Personal capacitado y productos de primera calidad.",
    phone: "5534567890",
    whatsapp: "5534567890",
    address: "Del Valle, Benito Juárez",
    latitude: "19.3745",
    longitude: "-99.1756",
    services: ["Limpieza profunda", "Limpieza regular", "Limpieza post-obra", "Lavado de alfombras"],
    estimatedPrices: "Departamento chico: $600-$900\nCasa mediana: $1,000-$1,500\nOficina: desde $800",
    rating: "4.9",
    reviewCount: 89,
    isVerified: true,
    isActive: true,
    isVisible: true,
  },
  {
    name: "Pinturas Don José",
    categorySlug: "pintura",
    description: "Más de 20 años pintando hogares felices. Pintura interior, exterior, y acabados especiales como texturizado y esgrafiado.",
    phone: "5545678901",
    whatsapp: "5545678901",
    address: "Coyoacán, CDMX",
    latitude: "19.3500",
    longitude: "-99.1617",
    services: ["Pintura interior", "Pintura exterior", "Texturizado", "Impermeabilización"],
    estimatedPrices: "Cuarto sencillo: $1,500-$2,500\nCasa completa: desde $8,000\nImpermeabilización: $80/m²",
    rating: "4.7",
    reviewCount: 56,
    isVerified: true,
    isActive: true,
    isVisible: true,
  },
  {
    name: "Carpintería Moderna",
    categorySlug: "carpinteria",
    description: "Fabricamos muebles a la medida con diseños modernos y materiales de alta calidad. Closets, cocinas integrales y más.",
    phone: "5556789012",
    whatsapp: "5556789012",
    address: "Naucalpan, Estado de México",
    latitude: "19.4753",
    longitude: "-99.2394",
    services: ["Closets", "Cocinas integrales", "Muebles de baño", "Libreros"],
    estimatedPrices: "Closet 2m: desde $15,000\nCocina integral: desde $35,000\nLibrero: desde $8,000",
    rating: "4.5",
    reviewCount: 28,
    isVerified: false,
    isActive: true,
    isVisible: true,
  },
];

export async function seedDatabase() {
  try {
    console.log("Checking if seed data already exists...");

    const existingCategories = await db.select().from(categories);
    if (existingCategories.length > 0) {
      console.log("Seed data already exists, skipping...");
      return;
    }

    console.log("Seeding parent categories...");
    const insertedParents = await db.insert(categories).values(parentCategories).returning();
    console.log(`Inserted ${insertedParents.length} parent categories`);

    console.log("Seeding subcategories...");
    const allSubcategories: any[] = [];
    for (const parent of insertedParents) {
      const subs = subcategoriesMap[parent.slug];
      if (subs) {
        for (const sub of subs) {
          allSubcategories.push({ ...sub, parentId: parent.id });
        }
      }
    }
    const insertedSubs = await db.insert(categories).values(allSubcategories).returning();
    console.log(`Inserted ${insertedSubs.length} subcategories`);

    const allCategories = [...insertedParents, ...insertedSubs];

    console.log("Creating demo user...");
    const [demoUser] = await db
      .insert(users)
      .values({
        id: "demo-user-001",
        email: "demo@medium.mx",
        firstName: "Demo",
        lastName: "Business",
      })
      .onConflictDoNothing()
      .returning();

    if (demoUser) {
      console.log("Demo user created");

      await db.insert(userProfiles).values({
        userId: demoUser.id,
        role: "business",
        phone: "5512345678",
      }).onConflictDoNothing();

      console.log("Creating admin user...");
      const adminEmail = process.env.ADMIN_EMAIL || "admin@medium.mx";
      const [adminUser] = await db
        .insert(users)
        .values({
          id: "admin-user-001",
          email: adminEmail,
          firstName: "Admin",
          lastName: "MEDIUM",
        })
        .onConflictDoNothing()
        .returning();

      if (adminUser) {
        await db.insert(userProfiles).values({
          userId: adminUser.id,
          role: "admin",
          phone: "5500000000",
        }).onConflictDoNothing();
        console.log(`Admin user created with email: ${adminEmail}`);
      }

      console.log("Seeding businesses...");
      for (const bizData of seedBusinesses) {
        const category = allCategories.find((c) => c.slug === bizData.categorySlug);
        if (!category) continue;

        const slug = bizData.name
          .toLowerCase()
          .normalize("NFD")
          .replace(/[\u0300-\u036f]/g, "")
          .replace(/[^a-z0-9]+/g, "-")
          .replace(/(^-|-$)/g, "");

        const [business] = await db
          .insert(businesses)
          .values({
            userId: demoUser.id,
            name: bizData.name,
            slug,
            categoryId: category.id,
            description: bizData.description,
            phone: bizData.phone,
            whatsapp: bizData.whatsapp,
            address: bizData.address,
            latitude: bizData.latitude,
            longitude: bizData.longitude,
            services: bizData.services,
            estimatedPrices: bizData.estimatedPrices,
            rating: bizData.rating,
            reviewCount: bizData.reviewCount,
            isVerified: bizData.isVerified,
            isActive: bizData.isActive,
            isVisible: bizData.isVisible,
          })
          .returning();

        const [wallet] = await db
          .insert(wallets)
          .values({
            businessId: business.id,
            balance: "500.00",
          })
          .returning();

        await db.insert(walletTransactions).values({
          walletId: wallet.id,
          type: "credit",
          amount: "500.00",
          description: "Saldo inicial de bienvenida",
        });

        console.log(`Created business: ${business.name}`);
      }
    }

    console.log("Seed completed successfully!");
  } catch (error) {
    console.error("Error seeding database:", error);
  }
}
