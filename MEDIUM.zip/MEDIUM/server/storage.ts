import {
  users,
  categories,
  userProfiles,
  businesses,
  wallets,
  walletTransactions,
  serviceRequests,
  messages,
  reviews,
  verifications,
  businessServices,
  notifications,
  favorites,
  reports,
  businessSubscriptions,
  type Category,
  type InsertCategory,
  type UserProfile,
  type InsertUserProfile,
  type Business,
  type InsertBusiness,
  type Wallet,
  type InsertWallet,
  type WalletTransaction,
  type InsertWalletTransaction,
  type ServiceRequest,
  type InsertServiceRequest,
  type Message,
  type InsertMessage,
  type Review,
  type InsertReview,
  type Verification,
  type InsertVerification,
  type BusinessService,
  type InsertBusinessService,
  type Notification,
  type InsertNotification,
  type Favorite,
  type InsertFavorite,
  type Report,
  type InsertReport,
  type BusinessSubscription,
  type InsertBusinessSubscription,
} from "@shared/schema";
import type { User } from "@shared/models/auth";
import { db } from "./db";
import { eq, and, or, ilike, desc, sql, asc, gte, lte, inArray } from "drizzle-orm";

export interface IStorage {
  // Categories
  getCategories(): Promise<Category[]>;
  getCategoryById(id: string): Promise<Category | undefined>;
  getCategoryBySlug(slug: string): Promise<Category | undefined>;
  createCategory(category: InsertCategory): Promise<Category>;

  // Users
  getUser(userId: string): Promise<User | undefined>;

  // User Profiles
  getUserProfile(userId: string): Promise<UserProfile | undefined>;
  createUserProfile(profile: InsertUserProfile): Promise<UserProfile>;
  updateUserProfile(userId: string, data: Partial<UserProfile>): Promise<UserProfile | undefined>;

  // Businesses
  getBusinessById(id: string): Promise<Business | undefined>;
  getBusinessBySlug(slug: string): Promise<(Business & { category?: Category }) | undefined>;
  getBusinessByUserId(userId: string): Promise<Business | undefined>;
  getBusinesses(filters?: { categorySlug?: string; query?: string; sort?: string; minRating?: number; verifiedOnly?: boolean; minPrice?: number; maxPrice?: number }): Promise<(Business & { category?: Category })[]>;
  getFeaturedBusinesses(): Promise<(Business & { category?: Category })[]>;
  createBusiness(business: InsertBusiness): Promise<Business>;
  updateBusiness(id: string, data: Partial<Business>): Promise<Business | undefined>;

  // Wallets
  getWalletByBusinessId(businessId: string): Promise<Wallet | undefined>;
  createWallet(wallet: InsertWallet): Promise<Wallet>;
  updateWalletBalance(walletId: string, amount: number): Promise<Wallet | undefined>;
  getWalletTransactions(walletId: string): Promise<WalletTransaction[]>;
  createWalletTransaction(transaction: InsertWalletTransaction): Promise<WalletTransaction>;

  // Service Requests
  getServiceRequest(id: string): Promise<ServiceRequest | undefined>;
  getServiceRequestWithDetails(id: string): Promise<(ServiceRequest & { business?: Business; client?: User }) | undefined>;
  getServiceRequestsByClient(clientId: string): Promise<(ServiceRequest & { business?: Business })[]>;
  getServiceRequestsByBusiness(businessId: string): Promise<ServiceRequest[]>;
  createServiceRequest(request: InsertServiceRequest): Promise<ServiceRequest>;
  updateServiceRequest(id: string, data: Partial<ServiceRequest>): Promise<ServiceRequest | undefined>;
  createServiceRequestAtomic(request: InsertServiceRequest, walletId: string, leadCost: number): Promise<{ request: ServiceRequest; newBalance: number; businessHidden: boolean }>;

  // Messages
  getMessages(serviceRequestId: string): Promise<Message[]>;
  createMessage(message: InsertMessage): Promise<Message>;

  // Reviews
  getReviewsByBusiness(businessId: string): Promise<(Review & { client?: User })[]>;
  getReviewsByClient(clientId: string): Promise<Review[]>;
  createReview(review: InsertReview): Promise<Review>;

  // Verifications
  getVerificationsByBusiness(businessId: string): Promise<Verification[]>;
  getPendingVerifications(): Promise<(Verification & { business?: Business })[]>;
  createVerification(verification: InsertVerification): Promise<Verification>;
  updateVerification(id: string, data: Partial<Verification>): Promise<Verification | undefined>;

  // Admin
  getAllUsers(): Promise<(User & { role?: string; isBlocked?: boolean })[]>;
  getAllBusinesses(): Promise<Business[]>;
  getAllWalletTransactions(): Promise<(WalletTransaction & { wallet?: Wallet; business?: Business })[]>;
  getAdminStats(): Promise<{
    totalUsers: number;
    totalBusinesses: number;
    totalRequests: number;
    totalRevenue: number;
    pendingVerifications: number;
  }>;

  // Business Services
  getBusinessServices(businessId: string): Promise<BusinessService[]>;
  createBusinessService(service: InsertBusinessService): Promise<BusinessService>;
  getBusinessServiceById(id: string): Promise<BusinessService | undefined>;
  updateBusinessService(id: string, data: Partial<BusinessService>): Promise<BusinessService | undefined>;
  deleteBusinessService(id: string): Promise<void>;

  // My Requests with Reviews
  getServiceRequestsWithReviews(clientId: string): Promise<(ServiceRequest & { business?: Business; review?: Review })[]>;

  // Review management
  getReviewById(id: string): Promise<Review | undefined>;
  updateReview(id: string, data: Partial<Review>): Promise<Review | undefined>;
  deleteReview(id: string, deletedBy: string): Promise<void>;
  getReportedReviews(): Promise<(Review & { business?: Business; client?: User })[]>;
  getSuspiciousReviews(): Promise<(Review & { business?: Business; client?: User })[]>;

  // Notifications
  getNotifications(userId: string): Promise<Notification[]>;
  createNotification(notification: InsertNotification): Promise<Notification>;
  markNotificationRead(id: string): Promise<void>;
  markAllNotificationsRead(userId: string): Promise<void>;
  getUnreadNotificationCount(userId: string): Promise<number>;

  // Admin user/business management
  blockUser(userId: string, reason: string): Promise<void>;
  unblockUser(userId: string): Promise<void>;
  blockBusiness(businessId: string, reason: string): Promise<void>;
  unblockBusiness(businessId: string): Promise<void>;
  deleteBusiness(businessId: string): Promise<void>;
  adminRechargeWallet(walletId: string, amount: number, description: string): Promise<WalletTransaction>;

  // Business visibility
  toggleBusinessPaused(businessId: string, isPaused: boolean): Promise<Business | undefined>;
  incrementBusinessViews(businessId: string): Promise<void>;

  // Favorites
  getFavoritesByUser(userId: string): Promise<(Favorite & { business?: Business & { category?: Category } })[]>;
  addFavorite(userId: string, businessId: string): Promise<Favorite>;
  removeFavorite(userId: string, businessId: string): Promise<void>;
  isFavorite(userId: string, businessId: string): Promise<boolean>;

  // Reports
  createReport(report: InsertReport): Promise<Report>;
  getReports(): Promise<(Report & { reporter?: User; business?: Business })[]>;
  updateReport(id: string, data: Partial<Report>): Promise<Report | undefined>;
  getReportsByStatus(status: string): Promise<(Report & { reporter?: User; business?: Business })[]>;

  // Dashboard Charts
  getDashboardChartData(businessId: string): Promise<{ weeklyLeads: { week: string; count: number }[]; weeklyRevenue: { week: string; amount: number }[] }>;

  // Business Subscriptions
  getBusinessSubscription(businessId: string): Promise<BusinessSubscription | undefined>;
  getBusinessSubscriptionByStripeId(stripeSubscriptionId: string): Promise<BusinessSubscription | undefined>;
  createBusinessSubscription(sub: InsertBusinessSubscription): Promise<BusinessSubscription>;
  updateBusinessSubscription(id: string, data: Partial<BusinessSubscription>): Promise<BusinessSubscription | undefined>;
  getBusinessPlan(businessId: string): Promise<{ plan: string; status: string; isTrial: boolean; currentPeriodEnd: Date | null }>;
}

function generateSlug(name: string): string {
  return name
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "")
    + "-" + Math.random().toString(36).substring(2, 7);
}

export class DatabaseStorage implements IStorage {
  // Categories
  async getCategories(): Promise<Category[]> {
    return db.select().from(categories).orderBy(asc(categories.name));
  }

  async getCategoryById(id: string): Promise<Category | undefined> {
    const [category] = await db.select().from(categories).where(eq(categories.id, id));
    return category;
  }

  async getCategoryBySlug(slug: string): Promise<Category | undefined> {
    const [category] = await db.select().from(categories).where(eq(categories.slug, slug));
    return category;
  }

  async createCategory(category: InsertCategory): Promise<Category> {
    const [newCategory] = await db.insert(categories).values(category).returning();
    return newCategory;
  }

  // Users
  async getUser(userId: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, userId));
    return user;
  }

  // User Profiles
  async getUserProfile(userId: string): Promise<UserProfile | undefined> {
    const [profile] = await db.select().from(userProfiles).where(eq(userProfiles.userId, userId));
    return profile;
  }

  async createUserProfile(profile: InsertUserProfile): Promise<UserProfile> {
    const [newProfile] = await db.insert(userProfiles).values(profile).returning();
    return newProfile;
  }

  async updateUserProfile(userId: string, data: Partial<UserProfile>): Promise<UserProfile | undefined> {
    const [profile] = await db
      .update(userProfiles)
      .set(data)
      .where(eq(userProfiles.userId, userId))
      .returning();
    return profile;
  }

  // Businesses
  async getBusinessById(id: string): Promise<Business | undefined> {
    const [business] = await db.select().from(businesses).where(eq(businesses.id, id));
    return business;
  }

  async getBusinessBySlug(slug: string): Promise<(Business & { category?: Category }) | undefined> {
    const result = await db
      .select({
        business: businesses,
        category: categories,
      })
      .from(businesses)
      .leftJoin(categories, eq(businesses.categoryId, categories.id))
      .where(eq(businesses.slug, slug));

    if (result.length === 0) return undefined;
    return { ...result[0].business, category: result[0].category || undefined };
  }

  async getBusinessByUserId(userId: string): Promise<Business | undefined> {
    const [business] = await db.select().from(businesses).where(eq(businesses.userId, userId));
    return business;
  }

  async getBusinesses(filters?: { categorySlug?: string; query?: string; sort?: string; minRating?: number; verifiedOnly?: boolean; minPrice?: number; maxPrice?: number }): Promise<(Business & { category?: Category; plan?: string })[]> {
    const results = await db
      .select({
        business: businesses,
        category: categories,
        subscription: businessSubscriptions,
      })
      .from(businesses)
      .leftJoin(categories, eq(businesses.categoryId, categories.id))
      .leftJoin(businessSubscriptions, eq(businesses.id, businessSubscriptions.businessId))
      .where(and(eq(businesses.isActive, true), eq(businesses.isVisible, true)));

    let filtered = results.map((r) => ({
      ...r.business,
      category: r.category || undefined,
      plan: r.subscription?.plan || "free",
    }));

    if (filters?.categorySlug) {
      filtered = filtered.filter((b) => b.category?.slug === filters.categorySlug);
    }

    if (filters?.query) {
      const q = filters.query.toLowerCase();
      filtered = filtered.filter(
        (b) =>
          b.name.toLowerCase().includes(q) ||
          b.description?.toLowerCase().includes(q) ||
          b.category?.name.toLowerCase().includes(q) ||
          b.services?.some((s) => s.toLowerCase().includes(q))
      );
    }

    if (filters?.minRating) {
      filtered = filtered.filter((b) => Number(b.rating) >= filters.minRating!);
    }

    if (filters?.verifiedOnly) {
      filtered = filtered.filter((b) => b.isVerified);
    }

    if (filters?.minPrice !== undefined || filters?.maxPrice !== undefined) {
      const businessIds = filtered.map((b) => b.id);
      if (businessIds.length > 0) {
        const conditions = [
          inArray(businessServices.businessId, businessIds),
          eq(businessServices.isActive, true),
        ];
        if (filters.minPrice !== undefined) {
          conditions.push(gte(businessServices.minPrice, String(filters.minPrice)));
        }
        if (filters.maxPrice !== undefined) {
          conditions.push(lte(businessServices.minPrice, String(filters.maxPrice)));
        }
        const matchingServices = await db
          .select({ businessId: businessServices.businessId })
          .from(businessServices)
          .where(and(...conditions));
        const matchingIds = new Set(matchingServices.map((s) => s.businessId));
        filtered = filtered.filter((b) => matchingIds.has(b.id));
      }
    }

    const planPriority: Record<string, number> = { premium: 3, pro: 2, free: 1 };

    if (filters?.sort === "reviews") {
      filtered.sort((a, b) => (planPriority[b.plan || "free"] || 1) - (planPriority[a.plan || "free"] || 1) || b.reviewCount - a.reviewCount);
    } else if (filters?.sort === "newest") {
      filtered.sort((a, b) => (planPriority[b.plan || "free"] || 1) - (planPriority[a.plan || "free"] || 1) || new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime());
    } else {
      filtered.sort((a, b) => (planPriority[b.plan || "free"] || 1) - (planPriority[a.plan || "free"] || 1) || Number(b.rating) - Number(a.rating));
    }

    return filtered;
  }

  async getFeaturedBusinesses(): Promise<(Business & { category?: Category; plan?: string })[]> {
    const results = await db
      .select({
        business: businesses,
        category: categories,
        subscription: businessSubscriptions,
      })
      .from(businesses)
      .leftJoin(categories, eq(businesses.categoryId, categories.id))
      .leftJoin(businessSubscriptions, eq(businesses.id, businessSubscriptions.businessId))
      .where(and(eq(businesses.isActive, true), eq(businesses.isVisible, true)))
      .orderBy(desc(businesses.rating))
      .limit(12);

    const planPriority: Record<string, number> = { premium: 3, pro: 2, free: 1 };
    const mapped = results.map((r) => ({
      ...r.business,
      category: r.category || undefined,
      plan: r.subscription?.plan || "free",
    }));

    mapped.sort((a, b) => (planPriority[b.plan || "free"] || 1) - (planPriority[a.plan || "free"] || 1) || Number(b.rating) - Number(a.rating));
    return mapped;
  }

  async createBusiness(business: InsertBusiness): Promise<Business> {
    const slug = generateSlug(business.name);
    const [newBusiness] = await db
      .insert(businesses)
      .values({ ...business, slug })
      .returning();
    return newBusiness;
  }

  async updateBusiness(id: string, data: Partial<Business>): Promise<Business | undefined> {
    const [business] = await db.update(businesses).set(data).where(eq(businesses.id, id)).returning();
    return business;
  }

  // Wallets
  async getWalletByBusinessId(businessId: string): Promise<Wallet | undefined> {
    const [wallet] = await db.select().from(wallets).where(eq(wallets.businessId, businessId));
    return wallet;
  }

  async createWallet(wallet: InsertWallet): Promise<Wallet> {
    const [newWallet] = await db.insert(wallets).values(wallet).returning();
    return newWallet;
  }

  async updateWalletBalance(walletId: string, amount: number): Promise<Wallet | undefined> {
    const [wallet] = await db
      .update(wallets)
      .set({ balance: sql`${wallets.balance} + ${amount}` })
      .where(eq(wallets.id, walletId))
      .returning();
    return wallet;
  }

  async getWalletTransactions(walletId: string): Promise<WalletTransaction[]> {
    return db
      .select()
      .from(walletTransactions)
      .where(eq(walletTransactions.walletId, walletId))
      .orderBy(desc(walletTransactions.createdAt));
  }

  async createWalletTransaction(transaction: InsertWalletTransaction): Promise<WalletTransaction> {
    const [newTransaction] = await db.insert(walletTransactions).values(transaction).returning();
    return newTransaction;
  }

  // Service Requests
  async getServiceRequest(id: string): Promise<ServiceRequest | undefined> {
    const [request] = await db.select().from(serviceRequests).where(eq(serviceRequests.id, id));
    return request;
  }

  async getServiceRequestWithDetails(id: string): Promise<(ServiceRequest & { business?: Business; client?: User }) | undefined> {
    const results = await db
      .select({
        request: serviceRequests,
        business: businesses,
        client: users,
      })
      .from(serviceRequests)
      .leftJoin(businesses, eq(serviceRequests.businessId, businesses.id))
      .leftJoin(users, eq(serviceRequests.clientId, users.id))
      .where(eq(serviceRequests.id, id));

    if (results.length === 0) return undefined;

    const r = results[0];
    return {
      ...r.request,
      business: r.business || undefined,
      client: r.client || undefined,
    };
  }

  async getServiceRequestsByClient(clientId: string): Promise<(ServiceRequest & { business?: Business })[]> {
    const results = await db
      .select({
        request: serviceRequests,
        business: businesses,
      })
      .from(serviceRequests)
      .leftJoin(businesses, eq(serviceRequests.businessId, businesses.id))
      .where(eq(serviceRequests.clientId, clientId))
      .orderBy(desc(serviceRequests.createdAt));

    return results.map((r) => ({
      ...r.request,
      business: r.business || undefined,
    }));
  }

  async getServiceRequestsByBusiness(businessId: string): Promise<ServiceRequest[]> {
    return db
      .select()
      .from(serviceRequests)
      .where(eq(serviceRequests.businessId, businessId))
      .orderBy(desc(serviceRequests.createdAt));
  }

  async createServiceRequest(request: InsertServiceRequest): Promise<ServiceRequest> {
    const [newRequest] = await db.insert(serviceRequests).values(request).returning();
    return newRequest;
  }

  async updateServiceRequest(id: string, data: Partial<ServiceRequest>): Promise<ServiceRequest | undefined> {
    const [request] = await db
      .update(serviceRequests)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(serviceRequests.id, id))
      .returning();
    return request;
  }

  async createServiceRequestAtomic(
    request: InsertServiceRequest, 
    walletId: string, 
    leadCost: number
  ): Promise<{ request: ServiceRequest; newBalance: number; businessHidden: boolean }> {
    return await db.transaction(async (tx) => {
      const [newRequest] = await tx.insert(serviceRequests).values({
        ...request,
        isPaid: true,
      }).returning();

      await tx
        .update(wallets)
        .set({ balance: sql`${wallets.balance} - ${leadCost}` })
        .where(eq(wallets.id, walletId));

      await tx.insert(walletTransactions).values({
        walletId,
        type: "debit",
        amount: String(leadCost),
        description: `Lead: ${request.description?.substring(0, 50) || 'Nueva solicitud'}...`,
        referenceId: newRequest.id,
      });

      const [updatedWallet] = await tx
        .select()
        .from(wallets)
        .where(eq(wallets.id, walletId));

      const newBalance = Number(updatedWallet.balance);
      let businessHidden = false;

      if (newBalance <= 0) {
        await tx
          .update(businesses)
          .set({ isVisible: false })
          .where(eq(businesses.id, request.businessId));
        businessHidden = true;
      }

      return { request: newRequest, newBalance, businessHidden };
    });
  }

  // Messages
  async getMessages(serviceRequestId: string): Promise<Message[]> {
    return db
      .select()
      .from(messages)
      .where(eq(messages.serviceRequestId, serviceRequestId))
      .orderBy(asc(messages.createdAt));
  }

  async createMessage(message: InsertMessage): Promise<Message> {
    const [newMessage] = await db.insert(messages).values(message).returning();
    return newMessage;
  }

  // Reviews
  async getReviewsByBusiness(businessId: string): Promise<(Review & { client?: User })[]> {
    const results = await db
      .select({
        review: reviews,
        client: users,
      })
      .from(reviews)
      .leftJoin(users, eq(reviews.clientId, users.id))
      .where(eq(reviews.businessId, businessId))
      .orderBy(desc(reviews.createdAt));

    return results.map((r) => ({
      ...r.review,
      client: r.client || undefined,
    }));
  }

  async getReviewsByClient(clientId: string): Promise<Review[]> {
    return await db
      .select()
      .from(reviews)
      .where(eq(reviews.clientId, clientId))
      .orderBy(desc(reviews.createdAt));
  }

  async createReview(review: InsertReview): Promise<Review> {
    const [newReview] = await db.insert(reviews).values(review).returning();

    // Update business rating
    const businessReviews = await db
      .select({ rating: reviews.rating })
      .from(reviews)
      .where(eq(reviews.businessId, review.businessId));

    const avgRating = businessReviews.reduce((sum, r) => sum + r.rating, 0) / businessReviews.length;

    await db
      .update(businesses)
      .set({
        rating: avgRating.toFixed(1),
        reviewCount: businessReviews.length,
      })
      .where(eq(businesses.id, review.businessId));

    return newReview;
  }

  // Verifications
  async getVerificationsByBusiness(businessId: string): Promise<Verification[]> {
    return db.select().from(verifications).where(eq(verifications.businessId, businessId));
  }

  async getPendingVerifications(): Promise<(Verification & { business?: Business })[]> {
    const results = await db
      .select({
        verification: verifications,
        business: businesses,
      })
      .from(verifications)
      .leftJoin(businesses, eq(verifications.businessId, businesses.id))
      .where(eq(verifications.status, "pending"))
      .orderBy(asc(verifications.createdAt));

    return results.map((r) => ({
      ...r.verification,
      business: r.business || undefined,
    }));
  }

  async createVerification(verification: InsertVerification): Promise<Verification> {
    const [newVerification] = await db.insert(verifications).values(verification).returning();
    return newVerification;
  }

  async updateVerification(id: string, data: Partial<Verification>): Promise<Verification | undefined> {
    const [verification] = await db
      .update(verifications)
      .set(data)
      .where(eq(verifications.id, id))
      .returning();

    // If approved, update business verification status
    if (data.status === "approved") {
      const ver = await db.select().from(verifications).where(eq(verifications.id, id));
      if (ver[0]) {
        const allVerifications = await db
          .select()
          .from(verifications)
          .where(eq(verifications.businessId, ver[0].businessId));

        const allApproved = allVerifications.every((v) => v.status === "approved");
        if (allApproved && allVerifications.length >= 2) {
          await db.update(businesses).set({ isVerified: true }).where(eq(businesses.id, ver[0].businessId));
        }
      }
    }

    return verification;
  }

  // Admin
  async getAllUsers(): Promise<(User & { role?: string; isBlocked?: boolean })[]> {
    const results = await db
      .select({
        user: users,
        profile: userProfiles,
      })
      .from(users)
      .leftJoin(userProfiles, eq(users.id, userProfiles.userId))
      .orderBy(desc(users.createdAt));
    
    return results.map((r) => ({
      ...r.user,
      role: r.profile?.role || "client",
      isBlocked: r.profile?.isBlocked || false,
    }));
  }

  async getAllBusinesses(): Promise<Business[]> {
    return db.select().from(businesses).orderBy(desc(businesses.createdAt));
  }

  async getAllWalletTransactions(): Promise<(WalletTransaction & { wallet?: Wallet; business?: Business })[]> {
    const results = await db
      .select({
        transaction: walletTransactions,
        wallet: wallets,
        business: businesses,
      })
      .from(walletTransactions)
      .leftJoin(wallets, eq(walletTransactions.walletId, wallets.id))
      .leftJoin(businesses, eq(wallets.businessId, businesses.id))
      .orderBy(desc(walletTransactions.createdAt))
      .limit(100);

    return results.map((r) => ({
      ...r.transaction,
      wallet: r.wallet || undefined,
      business: r.business || undefined,
    }));
  }

  async getAdminStats(): Promise<{
    totalUsers: number;
    totalBusinesses: number;
    totalRequests: number;
    totalRevenue: number;
    pendingVerifications: number;
  }> {
    const [usersCount] = await db.select({ count: sql<number>`count(*)` }).from(users);
    const [businessesCount] = await db.select({ count: sql<number>`count(*)` }).from(businesses);
    const [requestsCount] = await db.select({ count: sql<number>`count(*)` }).from(serviceRequests);
    const [pendingVerCount] = await db
      .select({ count: sql<number>`count(*)` })
      .from(verifications)
      .where(eq(verifications.status, "pending"));

    const [revenueResult] = await db
      .select({ total: sql<number>`COALESCE(SUM(CAST(amount AS DECIMAL)), 0)` })
      .from(walletTransactions)
      .where(eq(walletTransactions.type, "credit"));

    return {
      totalUsers: Number(usersCount.count),
      totalBusinesses: Number(businessesCount.count),
      totalRequests: Number(requestsCount.count),
      totalRevenue: Number(revenueResult.total) || 0,
      pendingVerifications: Number(pendingVerCount.count),
    };
  }

  // Business Services
  async getBusinessServices(businessId: string): Promise<BusinessService[]> {
    return await db
      .select()
      .from(businessServices)
      .where(and(
        eq(businessServices.businessId, businessId),
        eq(businessServices.isActive, true)
      ))
      .orderBy(asc(businessServices.name));
  }

  async createBusinessService(service: InsertBusinessService): Promise<BusinessService> {
    const [newService] = await db.insert(businessServices).values(service).returning();
    return newService;
  }

  async getBusinessServiceById(id: string): Promise<BusinessService | undefined> {
    const [service] = await db
      .select()
      .from(businessServices)
      .where(eq(businessServices.id, id));
    return service;
  }

  async updateBusinessService(id: string, data: Partial<BusinessService>): Promise<BusinessService | undefined> {
    const [updated] = await db
      .update(businessServices)
      .set(data)
      .where(eq(businessServices.id, id))
      .returning();
    return updated;
  }

  async deleteBusinessService(id: string): Promise<void> {
    await db.update(businessServices).set({ isActive: false }).where(eq(businessServices.id, id));
  }

  // My Requests with Reviews
  async getServiceRequestsWithReviews(clientId: string): Promise<(ServiceRequest & { business?: Business; review?: Review })[]> {
    const results = await db
      .select({
        request: serviceRequests,
        business: businesses,
        review: reviews,
      })
      .from(serviceRequests)
      .leftJoin(businesses, eq(serviceRequests.businessId, businesses.id))
      .leftJoin(reviews, eq(serviceRequests.id, reviews.serviceRequestId))
      .where(eq(serviceRequests.clientId, clientId))
      .orderBy(desc(serviceRequests.createdAt));

    return results.map((r) => ({
      ...r.request,
      business: r.business || undefined,
      review: r.review || undefined,
    }));
  }

  // Review management
  async getReviewById(id: string): Promise<Review | undefined> {
    const [review] = await db.select().from(reviews).where(eq(reviews.id, id));
    return review;
  }

  async updateReview(id: string, data: Partial<Review>): Promise<Review | undefined> {
    const [updated] = await db
      .update(reviews)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(reviews.id, id))
      .returning();
    return updated;
  }

  async deleteReview(id: string, deletedBy: string): Promise<void> {
    await db.update(reviews).set({ isDeleted: true, deletedBy }).where(eq(reviews.id, id));
  }

  async getReportedReviews(): Promise<(Review & { business?: Business; client?: User })[]> {
    const results = await db
      .select({ review: reviews, business: businesses, client: users })
      .from(reviews)
      .leftJoin(businesses, eq(reviews.businessId, businesses.id))
      .leftJoin(users, eq(reviews.clientId, users.id))
      .where(and(eq(reviews.isReported, true), eq(reviews.isDeleted, false)))
      .orderBy(desc(reviews.createdAt));
    
    return results.map((r) => ({
      ...r.review,
      business: r.business || undefined,
      client: r.client || undefined,
    }));
  }

  async getSuspiciousReviews(): Promise<(Review & { business?: Business; client?: User })[]> {
    const results = await db
      .select({ review: reviews, business: businesses, client: users })
      .from(reviews)
      .leftJoin(businesses, eq(reviews.businessId, businesses.id))
      .leftJoin(users, eq(reviews.clientId, users.id))
      .where(and(eq(reviews.isSuspicious, true), eq(reviews.isDeleted, false)))
      .orderBy(desc(reviews.createdAt));
    
    return results.map((r) => ({
      ...r.review,
      business: r.business || undefined,
      client: r.client || undefined,
    }));
  }

  // Notifications
  async getNotifications(userId: string): Promise<Notification[]> {
    return db
      .select()
      .from(notifications)
      .where(eq(notifications.userId, userId))
      .orderBy(desc(notifications.createdAt))
      .limit(50);
  }

  async createNotification(notification: InsertNotification): Promise<Notification> {
    const [newNotification] = await db.insert(notifications).values(notification).returning();
    return newNotification;
  }

  async markNotificationRead(id: string): Promise<void> {
    await db.update(notifications).set({ isRead: true }).where(eq(notifications.id, id));
  }

  async markAllNotificationsRead(userId: string): Promise<void> {
    await db.update(notifications).set({ isRead: true }).where(eq(notifications.userId, userId));
  }

  async getUnreadNotificationCount(userId: string): Promise<number> {
    const result = await db
      .select({ count: sql<number>`count(*)` })
      .from(notifications)
      .where(and(eq(notifications.userId, userId), eq(notifications.isRead, false)));
    return Number(result[0]?.count || 0);
  }

  // Admin user/business management
  async blockUser(userId: string, reason: string): Promise<void> {
    await db.update(userProfiles).set({ 
      isBlocked: true, 
      blockedReason: reason, 
      blockedAt: new Date() 
    }).where(eq(userProfiles.userId, userId));
  }

  async unblockUser(userId: string): Promise<void> {
    await db.update(userProfiles).set({ 
      isBlocked: false, 
      blockedReason: null, 
      blockedAt: null 
    }).where(eq(userProfiles.userId, userId));
  }

  async blockBusiness(businessId: string, reason: string): Promise<void> {
    await db.update(businesses).set({ 
      isBlocked: true, 
      blockedReason: reason,
      isVisible: false
    }).where(eq(businesses.id, businessId));
  }

  async unblockBusiness(businessId: string): Promise<void> {
    await db.update(businesses).set({ 
      isBlocked: false, 
      blockedReason: null,
      isVisible: true
    }).where(eq(businesses.id, businessId));
  }

  async deleteBusiness(businessId: string): Promise<void> {
    await db.update(businesses).set({ isActive: false, isVisible: false }).where(eq(businesses.id, businessId));
  }

  async adminRechargeWallet(walletId: string, amount: number, description: string): Promise<WalletTransaction> {
    const [wallet] = await db.select().from(wallets).where(eq(wallets.id, walletId));
    if (!wallet) throw new Error("Wallet not found");

    const newBalance = Number(wallet.balance) + amount;
    await db.update(wallets).set({ balance: String(newBalance) }).where(eq(wallets.id, walletId));

    const [transaction] = await db.insert(walletTransactions).values({
      walletId,
      type: "credit",
      amount: String(amount),
      description: description || "Recarga manual por admin",
    }).returning();

    // If business was hidden due to low balance, make visible again
    const [business] = await db.select().from(businesses).where(eq(businesses.id, wallet.businessId));
    if (business && !business.isVisible && !business.isBlocked && newBalance > 0) {
      await db.update(businesses).set({ isVisible: true }).where(eq(businesses.id, wallet.businessId));
    }

    return transaction;
  }

  // Business visibility
  async toggleBusinessPaused(businessId: string, isPaused: boolean): Promise<Business | undefined> {
    const [updated] = await db
      .update(businesses)
      .set({ isPaused, isVisible: !isPaused })
      .where(eq(businesses.id, businessId))
      .returning();
    return updated;
  }

  async incrementBusinessViews(businessId: string): Promise<void> {
    await db.update(businesses).set({ 
      viewCount: sql`${businesses.viewCount} + 1` 
    }).where(eq(businesses.id, businessId));
  }

  // Favorites
  async getFavoritesByUser(userId: string): Promise<(Favorite & { business?: Business & { category?: Category } })[]> {
    const results = await db
      .select({
        favorite: favorites,
        business: businesses,
        category: categories,
      })
      .from(favorites)
      .leftJoin(businesses, eq(favorites.businessId, businesses.id))
      .leftJoin(categories, eq(businesses.categoryId, categories.id))
      .where(eq(favorites.userId, userId))
      .orderBy(desc(favorites.createdAt));

    return results.map((r) => ({
      ...r.favorite,
      business: r.business ? { ...r.business, category: r.category || undefined } : undefined,
    }));
  }

  async addFavorite(userId: string, businessId: string): Promise<Favorite> {
    const [fav] = await db.insert(favorites).values({ userId, businessId }).returning();
    return fav;
  }

  async removeFavorite(userId: string, businessId: string): Promise<void> {
    await db.delete(favorites).where(and(eq(favorites.userId, userId), eq(favorites.businessId, businessId)));
  }

  async isFavorite(userId: string, businessId: string): Promise<boolean> {
    const result = await db
      .select({ id: favorites.id })
      .from(favorites)
      .where(and(eq(favorites.userId, userId), eq(favorites.businessId, businessId)));
    return result.length > 0;
  }

  // Reports
  async createReport(report: InsertReport): Promise<Report> {
    const [newReport] = await db.insert(reports).values(report).returning();
    return newReport;
  }

  async getReports(): Promise<(Report & { reporter?: User; business?: Business })[]> {
    const results = await db
      .select({
        report: reports,
        reporter: users,
        business: businesses,
      })
      .from(reports)
      .leftJoin(users, eq(reports.reporterId, users.id))
      .leftJoin(businesses, eq(reports.businessId, businesses.id))
      .orderBy(desc(reports.createdAt));

    return results.map((r) => ({
      ...r.report,
      reporter: r.reporter || undefined,
      business: r.business || undefined,
    }));
  }

  async updateReport(id: string, data: Partial<Report>): Promise<Report | undefined> {
    const [updated] = await db
      .update(reports)
      .set(data)
      .where(eq(reports.id, id))
      .returning();
    return updated;
  }

  async getReportsByStatus(status: string): Promise<(Report & { reporter?: User; business?: Business })[]> {
    const results = await db
      .select({
        report: reports,
        reporter: users,
        business: businesses,
      })
      .from(reports)
      .leftJoin(users, eq(reports.reporterId, users.id))
      .leftJoin(businesses, eq(reports.businessId, businesses.id))
      .where(eq(reports.status, status))
      .orderBy(desc(reports.createdAt));

    return results.map((r) => ({
      ...r.report,
      reporter: r.reporter || undefined,
      business: r.business || undefined,
    }));
  }

  // Dashboard Charts
  async getDashboardChartData(businessId: string): Promise<{ weeklyLeads: { week: string; count: number }[]; weeklyRevenue: { week: string; amount: number }[] }> {
    const weeklyLeadsResult = await db.execute(sql`
      SELECT date_trunc('week', created_at)::text AS week, COUNT(*)::int AS count
      FROM service_requests
      WHERE business_id = ${businessId}
        AND created_at >= NOW() - INTERVAL '8 weeks'
      GROUP BY date_trunc('week', created_at)
      ORDER BY week ASC
    `);

    const wallet = await this.getWalletByBusinessId(businessId);
    let weeklyRevenueRows: any[] = [];
    if (wallet) {
      const revenueResult = await db.execute(sql`
        SELECT date_trunc('week', created_at)::text AS week, COALESCE(SUM(CAST(amount AS DECIMAL)), 0)::float AS amount
        FROM wallet_transactions
        WHERE wallet_id = ${wallet.id}
          AND created_at >= NOW() - INTERVAL '8 weeks'
        GROUP BY date_trunc('week', created_at)
        ORDER BY week ASC
      `);
      weeklyRevenueRows = (revenueResult as unknown as any[]);
    }

    return {
      weeklyLeads: (weeklyLeadsResult as unknown as any[]).map((r: any) => ({ week: r.week, count: Number(r.count) })),
      weeklyRevenue: weeklyRevenueRows.map((r: any) => ({ week: r.week, amount: Number(r.amount) })),
    };
  }

  async getBusinessSubscription(businessId: string): Promise<BusinessSubscription | undefined> {
    const [sub] = await db.select().from(businessSubscriptions).where(eq(businessSubscriptions.businessId, businessId));
    return sub;
  }

  async getBusinessSubscriptionByStripeId(stripeSubscriptionId: string): Promise<BusinessSubscription | undefined> {
    const [sub] = await db.select().from(businessSubscriptions).where(eq(businessSubscriptions.stripeSubscriptionId, stripeSubscriptionId));
    return sub;
  }

  async createBusinessSubscription(sub: InsertBusinessSubscription): Promise<BusinessSubscription> {
    const [newSub] = await db.insert(businessSubscriptions).values(sub).returning();
    return newSub;
  }

  async updateBusinessSubscription(id: string, data: Partial<BusinessSubscription>): Promise<BusinessSubscription | undefined> {
    const [updated] = await db.update(businessSubscriptions).set(data).where(eq(businessSubscriptions.id, id)).returning();
    return updated;
  }

  async getBusinessPlan(businessId: string): Promise<{ plan: string; status: string; isTrial: boolean; currentPeriodEnd: Date | null }> {
    const sub = await this.getBusinessSubscription(businessId);
    if (!sub) {
      return { plan: "free", status: "active", isTrial: false, currentPeriodEnd: null };
    }
    return {
      plan: sub.plan,
      status: sub.status,
      isTrial: sub.status === "trial",
      currentPeriodEnd: sub.currentPeriodEnd,
    };
  }
}

export const storage = new DatabaseStorage();
