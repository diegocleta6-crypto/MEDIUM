import sharp from "sharp";

const MAX_WIDTH = 1200;
const MAX_HEIGHT = 1200;
const QUALITY = 80;

export async function compressImage(base64Image: string): Promise<string> {
  try {
    const matches = base64Image.match(/^data:image\/(\w+);base64,(.+)$/);
    if (!matches) {
      return base64Image;
    }

    const format = matches[1].toLowerCase();
    const data = matches[2];
    const buffer = Buffer.from(data, "base64");

    if (format === "svg" || format === "svg+xml") {
      return base64Image;
    }

    let sharpInstance = sharp(buffer);
    const metadata = await sharpInstance.metadata();

    if (metadata.width && metadata.height) {
      if (metadata.width > MAX_WIDTH || metadata.height > MAX_HEIGHT) {
        sharpInstance = sharpInstance.resize(MAX_WIDTH, MAX_HEIGHT, {
          fit: "inside",
          withoutEnlargement: true,
        });
      }
    }

    let outputBuffer: Buffer;
    let outputMime: string;

    if (format === "png") {
      outputBuffer = await sharpInstance.png({ quality: QUALITY }).toBuffer();
      outputMime = "image/png";
    } else if (format === "webp") {
      outputBuffer = await sharpInstance.webp({ quality: QUALITY }).toBuffer();
      outputMime = "image/webp";
    } else {
      outputBuffer = await sharpInstance.jpeg({ quality: QUALITY }).toBuffer();
      outputMime = "image/jpeg";
    }

    const compressedBase64 = outputBuffer.toString("base64");
    return `data:${outputMime};base64,${compressedBase64}`;
  } catch (error) {
    console.error("Error compressing image:", error);
    return base64Image;
  }
}

export async function compressImages(images: string[]): Promise<string[]> {
  const compressed = await Promise.all(images.map(compressImage));
  return compressed;
}
