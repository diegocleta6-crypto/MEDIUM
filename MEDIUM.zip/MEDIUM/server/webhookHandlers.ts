import { storage } from "./storage";

export async function handleStripeWebhook(event: any): Promise<void> {
  console.log(`Processing Stripe webhook event: ${event.type}`);

  switch (event.type) {
    case 'checkout.session.completed': {
      const session = event.data.object;
      const metadata = session.metadata || {};

      if (session.mode === 'subscription') {
        const { businessId, plan } = metadata;
        if (businessId && plan) {
          const existingSub = await storage.getBusinessSubscription(businessId);
          const subData = {
            plan,
            status: "active" as const,
            stripeSubscriptionId: session.subscription,
            stripeCustomerId: session.customer,
            currentPeriodEnd: null as Date | null,
          };

          if (existingSub) {
            await storage.updateBusinessSubscription(existingSub.id, subData);
          } else {
            await storage.createBusinessSubscription({
              businessId,
              ...subData,
            });
          }
          console.log(`Business ${businessId} subscribed to ${plan} plan`);
        }
      } else {
        const { walletId, businessId, amount } = metadata;
        if (walletId && amount) {
          await storage.updateWalletBalance(walletId, Number(amount));
          await storage.createWalletTransaction({
            walletId,
            type: "credit",
            amount,
            description: `Recarga de saldo - $${amount} MXN`,
            stripePaymentId: session.payment_intent || session.id,
          });
          console.log(`Wallet ${walletId} recharged with $${amount} MXN via Stripe`);
        }
      }
      break;
    }

    case 'customer.subscription.updated': {
      const subscription = event.data.object;
      const sub = await storage.getBusinessSubscriptionByStripeId(subscription.id);
      if (sub) {
        const status = subscription.status === 'active' ? 'active' :
          subscription.status === 'past_due' ? 'past_due' :
          subscription.status === 'canceled' ? 'canceled' : sub.status;

        await storage.updateBusinessSubscription(sub.id, {
          status,
          currentPeriodEnd: subscription.current_period_end
            ? new Date(subscription.current_period_end * 1000)
            : null,
        });
        console.log(`Subscription ${subscription.id} updated to ${status}`);
      }
      break;
    }

    case 'customer.subscription.deleted': {
      const subscription = event.data.object;
      const sub = await storage.getBusinessSubscriptionByStripeId(subscription.id);
      if (sub) {
        await storage.updateBusinessSubscription(sub.id, {
          plan: "free",
          status: "canceled",
          stripeSubscriptionId: null,
          currentPeriodEnd: null,
        });
        console.log(`Subscription ${subscription.id} canceled, reverted to free`);
      }
      break;
    }

    case 'invoice.payment_succeeded': {
      const invoice = event.data.object;
      if (invoice.subscription) {
        const sub = await storage.getBusinessSubscriptionByStripeId(invoice.subscription);
        if (sub) {
          await storage.updateBusinessSubscription(sub.id, {
            status: "active",
            currentPeriodEnd: invoice.lines?.data?.[0]?.period?.end
              ? new Date(invoice.lines.data[0].period.end * 1000)
              : sub.currentPeriodEnd,
          });
        }
      }
      break;
    }

    case 'invoice.payment_failed': {
      const invoice = event.data.object;
      if (invoice.subscription) {
        const sub = await storage.getBusinessSubscriptionByStripeId(invoice.subscription);
        if (sub) {
          await storage.updateBusinessSubscription(sub.id, { status: "past_due" });
          console.log(`Subscription ${invoice.subscription} payment failed, status: past_due`);
        }
      }
      break;
    }

    case 'payment_intent.succeeded': {
      console.log("Payment intent succeeded:", event.data.object.id);
      break;
    }

    case 'payment_intent.payment_failed': {
      console.log("Payment failed:", event.data.object.id);
      break;
    }

    default:
      console.log(`Unhandled event type: ${event.type}`);
  }
}
