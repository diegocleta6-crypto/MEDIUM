import { WebSocketServer, WebSocket } from "ws";
import type { Server } from "http";

interface ConnectedClient {
  ws: WebSocket;
  userId: string;
  isAlive: boolean;
}

const clients = new Map<string, ConnectedClient[]>();

export function setupWebSocket(server: Server) {
  const wss = new WebSocketServer({ server, path: "/ws" });

  const heartbeatInterval = setInterval(() => {
    clients.forEach((userClients, userId) => {
      userClients.forEach((client, index) => {
        if (!client.isAlive) {
          client.ws.terminate();
          userClients.splice(index, 1);
          return;
        }
        client.isAlive = false;
        client.ws.ping();
      });
      if (userClients.length === 0) {
        clients.delete(userId);
      }
    });
  }, 30000);

  wss.on("connection", (ws, req) => {
    const url = new URL(req.url || "", `http://${req.headers.host}`);
    const userId = url.searchParams.get("userId");

    if (!userId) {
      ws.close(1008, "User ID required");
      return;
    }

    const client: ConnectedClient = { ws, userId, isAlive: true };
    
    if (!clients.has(userId)) {
      clients.set(userId, []);
    }
    clients.get(userId)!.push(client);

    console.log(`WebSocket connected: user ${userId}`);

    ws.on("pong", () => {
      client.isAlive = true;
    });

    ws.on("message", (data) => {
      try {
        const message = JSON.parse(data.toString());
        handleMessage(userId, message);
      } catch (error) {
        console.error("WebSocket message error:", error);
      }
    });

    ws.on("close", () => {
      const userClients = clients.get(userId);
      if (userClients) {
        const index = userClients.indexOf(client);
        if (index > -1) {
          userClients.splice(index, 1);
        }
        if (userClients.length === 0) {
          clients.delete(userId);
        }
      }
      console.log(`WebSocket disconnected: user ${userId}`);
    });

    ws.on("error", (error) => {
      console.error(`WebSocket error for user ${userId}:`, error);
    });
  });

  wss.on("close", () => {
    clearInterval(heartbeatInterval);
  });

  return wss;
}

function handleMessage(userId: string, message: any) {
  switch (message.type) {
    case "typing":
      broadcastToRequest(message.requestId, {
        type: "typing",
        userId,
        requestId: message.requestId,
      }, userId);
      break;
    case "stop_typing":
      broadcastToRequest(message.requestId, {
        type: "stop_typing",
        userId,
        requestId: message.requestId,
      }, userId);
      break;
    default:
      break;
  }
}

export function sendToUser(userId: string, data: any) {
  const userClients = clients.get(userId);
  if (userClients) {
    const message = JSON.stringify(data);
    userClients.forEach((client) => {
      if (client.ws.readyState === WebSocket.OPEN) {
        client.ws.send(message);
      }
    });
  }
}

export function broadcastToRequest(requestId: string, data: any, excludeUserId?: string) {
  const message = JSON.stringify(data);
  clients.forEach((userClients, userId) => {
    if (excludeUserId && userId === excludeUserId) return;
    userClients.forEach((client) => {
      if (client.ws.readyState === WebSocket.OPEN) {
        client.ws.send(message);
      }
    });
  });
}

export function notifyNewRequest(businessUserId: string, requestData: any) {
  sendToUser(businessUserId, {
    type: "new_request",
    ...requestData,
  });
}

export function notifyNewMessage(recipientUserId: string, messageData: any) {
  sendToUser(recipientUserId, {
    type: "new_message",
    ...messageData,
  });
}

export function notifyRequestStatusChange(userId: string, statusData: any) {
  sendToUser(userId, {
    type: "request_status",
    ...statusData,
  });
}

export function notifyNewNotification(userId: string, notification: any) {
  sendToUser(userId, {
    type: "notification",
    notification,
  });
}
